/*
 * :ui — 画面。★Windows と Android で同じ 1 つ（DD-L2-othello §7z.5）。
 * 判定を持たない。受け取った一式を描き、触られたことを出来事にして送るだけ。
 */
plugins {
    kotlin("multiplatform")
    id("com.android.library")
    id("org.jetbrains.compose")
}

kotlin {
    androidTarget()
    jvm("desktop")
    jvmToolchain(17)

    sourceSets {
        val commonMain by getting {
            dependencies {
                implementation(project(":shared"))
                implementation(compose.runtime)
                implementation(compose.foundation)
                implementation(compose.material)
                implementation(compose.ui)
            }
        }
        val androidMain by getting
        val desktopMain by getting
    }
}

android {
    namespace = "othello.ui"
    compileSdk = 34
    defaultConfig { minSdk = 26 }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
