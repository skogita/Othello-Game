package othello.ui

import othello.Command
import othello.View

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * わきの補助情報とボタンを描く。
 *
 * 設計: DD-L4-othello-play §9 ／ 出すものは DD-L1-othello §5.2
 * 判定を持たない。★**無い値は「—」と出す。0 と書かない。**
 */

@Composable
fun OthelloSidePanel(
    view: View,
    onPass: () -> Unit,
    onUndo: () -> Unit,
    onNewGame: () -> Unit,
    onReplay: () -> Unit,
    onImport: () -> Unit,
    onDump: () -> Unit,
    onHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    // ★幅の上限を持つ。窓が広いと名前と値が離れ、右上に寄って見える（BUG-42）
    Column(modifier.widthIn(max = 320.dp).padding(8.dp)) {
        Line("手番", if (view.turn == "B") "黒" else "白")
        Line("黒", view.stones.b.toString())
        Line("白", view.stones.w.toString())
        Line("手数", view.moves.toString())
        val last = view.last
        Line("直前の手", if (last == null) "—" else last.square)
        Line("裏返った石", if (last == null) "—" else last.flipped.toString() + " 枚")
        Line("置ける升", if (!view.counted) "—" else view.hintCount.toString() + " か所")
        // ★どちらの場合も書く。★説明の中に段の数字を出さない（DD-L1-othello §5.2）
        // ★強さは白黒ごとに 1 行ずつ。計算機の側だけ出す（CR-12）
        val bl = view.blackLevel
        val wl = view.whiteLevel
        if (bl != null) Line("強さ（黒）", strength(bl, view))
        if (wl != null) Line("強さ（白）", strength(wl, view))
        Buttons(view, onPass, onUndo, onNewGame, onReplay, onImport, onDump, onHelp)
        if (view.message != "") Text(view.message, Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun Line(name: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(name, Modifier.weight(1f))
        Text(value)
    }
}

@Composable
private fun Buttons(
    view: View,
    onPass: () -> Unit,
    onUndo: () -> Unit,
    onNewGame: () -> Unit,
    onReplay: () -> Unit,
    onImport: () -> Unit,
    onDump: () -> Unit,
    onHelp: () -> Unit
) {
    Row(Modifier.padding(top = 8.dp)) {
        Button(onClick = onPass, enabled = view.pressable.canPass) { Text("パス") }
        Button(
            onClick = onUndo,
            enabled = view.pressable.canUndo,
            modifier = Modifier.padding(start = 8.dp)
        ) { Text("待った") }
    }
    // ★いつでも押せる。押せるかどうかを画面が判断しない（DD-L4-othello-play §9）
    Button(onClick = onNewGame, modifier = Modifier.padding(top = 8.dp)) { Text("新しい対局") }
    // ★「新しい対局」の下に「再生」、その下に「取り込み」（DD-L1-othello §5.5b）
    Button(onClick = onReplay, modifier = Modifier.padding(top = 8.dp)) { Text("再生") }
    Button(onClick = onImport, modifier = Modifier.padding(top = 8.dp)) { Text("取り込み") }
    // ★その下に「DB を書き出す」（CR-13 の 13-5）
    Button(onClick = onDump, modifier = Modifier.padding(top = 8.dp)) { Text("DB を書き出す") }
    // ★いちばん下に「ヘルプ」（F-12・RF-64／DD-L4-othello-bridge §4b）。いつでも押せる
    Button(onClick = onHelp, modifier = Modifier.padding(top = 8.dp)) { Text("ヘルプ") }
}

/** 段の出し方。★段 5 は「記録から選べたか」を添える（DD-L1-othello §5.2）。 */
private fun strength(level: Int, view: View): String = level.toString() + " 段" + when {
    level != 5 -> ""
    view.picked -> "（記録 " + view.pickedGames.toString() + " 局から選んだ）"
    else -> "（記録が無いので決め打ち）"
}
