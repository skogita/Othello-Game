package othello.ui

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import othello.Command
import othello.View

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.material.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * 3 つを並べ、触られたことを共通へ渡す。
 *
 * 設計: DD-L4-othello-play §9
 * ★判定を一切持たない。押せるかどうかも、何を出すかも、受け取った一式が決めている。
 * ★一式は 1 回の問い合わせで全部まとめて受け取る（DD-L2-othello §3.4）。
 */

// ★★**一式の器は、共通のものをそのまま使う。**画面の側に写しを作らない——
// 写しを作ると、共通で欄を 1 つ増やしたときに、**画面側の写しだけが古くなる**。

/** 画面が上へ渡す出来事。 */
// ★★**抽象でなく合成**（C 規約・DD-L4-othello-ui §2b）——
// ★**入れ替えたいのは「振る舞い」ではなく「渡し先」**。
data class OthelloTouch(
    val onSquare: (square: String) -> Unit,
    val onPass: () -> Unit,
    val onUndo: () -> Unit,

    /** ★新しい対局。選び直しの窓へ戻る（DD-L1-othello §6.5c）。いつでも押せる。 */
    val onNewGame: () -> Unit,

    /** ★計算機の 1 手。一式が「次も計算機の番」と言ったら、間を置いてから送る（CR-6）。 */
    val onMachineStep: () -> Unit,

    /** ★再生する対局の一覧を取る（CR-10）。窓を開く前に送る。 */
    val onReplayList: () -> Unit,

    /** ★選ばれた対局の再生を始める（CR-10）。 */
    val onReplayPick: (gameId: Int) -> Unit,

    /** ★再生の次の 1 手。★自動で流れる——間を置くのは画面（CR-10 の 10-2）。 */
    val onReplayNext: () -> Unit,

    /** ★置き場に在る記録を DB へ入れる（CR-9）。 */
    val onImport: () -> Unit,

    /** ★DB の中身を、置き場のファイルへ書き出す（CR-13 の 13-5）。 */
    val onDump: () -> Unit,

    /** ★ヘルプを開く（F-12・RF-64）。対局中でも押せる。 */
    val onHelp: () -> Unit,

    /** ★ヘルプを閉じる。★押す前の場面へそのまま戻る（何も戻す作業をしない）。 */
    val onCloseHelp: () -> Unit,
    /** ★名前は任意（CR-9 の 9-2）。空なら日時が名前になる。 */
    val onStart: (black: String, white: String, blackLevel: Int, whiteLevel: Int, name: String) -> Unit,
    val onCancelSetup: () -> Unit
)

@Composable
fun OthelloScreen(view: View?, choosing: Boolean, touch: OthelloTouch,
                  modifier: Modifier = Modifier) {
    // ★「対局が無い」と「選び直し中」を兼ねない（DD-L3-othello の口）。兼ねると、やめても同じ窓が出る
    if (choosing) {
        // ★やめられるかは渡す。画面は判断しない（DD-L4-othello-bridge §4）
        OthelloSetupDialog(touch.onStart, touch.onCancelSetup, view != null)
    }
    if (view == null) return
    // ★次も計算機の番なら、間を置いてから「計算機の 1 手」を送る（CR-6）。
    //   間を置くのは画面の側であり、共通は時計を見ない（DD-L2-othello §7z.2b）。
    // ★別の筋で送る。画面の筋のまま呼ぶと画面が止まり、Android では「応答しません」が出る
    //   （DD-L1-othello §5.2b・DD-L3-othello §7.1b の 8）
    var thinking by remember { mutableStateOf(false) }
    // ★窓を出しているかは画面が持つ。一覧が空でも窓は開く（「まだ記録がありません」を出すため）
    var picking by remember { mutableStateOf(false) }
    // ★再生は自動で流れる（CR-10 の 10-2）。押しても進まない
    LaunchedEffect(view.moves, view.replaying) {
        if (view.replaying) {
            delay(700)
            touch.onReplayNext()
        }
    }
    if (picking) OthelloReplayDialog(view.games,
        { id -> picking = false; touch.onReplayPick(id) }, { picking = false })
    // ★開いているかは一式が言う（画面は持たない）。閉じたら、押す前の場面がそのまま残っている
    if (view.help) OthelloHelpScreen(touch.onCloseHelp)
    LaunchedEffect(view.moves, view.machineToMove) {
        if (view.machineToMove) {
            delay(600)
            thinking = true
            withContext(Dispatchers.Default) { touch.onMachineStep() }
            thinking = false
        }
    }
    Row(modifier.fillMaxSize().padding(8.dp)) {
        // ★盤は中身の大きさで置く。窓の幅で割らない（DD-L4-othello-bridge §4）
        // ★わきの分を先に取り分ける。盤の列を「中身の大きさ」にすると、
        //   グラフが窓いっぱいに広がったときに、わきが画面の外へ押し出される
        Column(Modifier.weight(1f)) {
            // ★盤とグラフで高さを分け合う。重ねない（DD-L1-othello §5.2c）
            OthelloBoardView(view, touch.onSquare, Modifier.weight(3f))
            // ★幅は盤に合わせる。窓いっぱいに広げると、わきが押し出される
            OthelloGraphView(view.trend, Modifier.weight(1f))
        }
        // ★わきは盤の隣に置く。空きを作らない
        Column(Modifier.width(340.dp)) {
            OthelloSidePanel(view, touch.onPass, touch.onUndo, touch.onNewGame,
                { touch.onReplayList(); picking = true }, touch.onImport, touch.onDump,
                touch.onHelp)
            // ★考えているあいだ、そう出す（DD-L3-othello §7.1b の 8b）
            if (thinking) Text("考えています")
        }
    }
}
