package othello.ui

import othello.Command
import othello.View

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.AlertDialog
import androidx.compose.material.Button
import androidx.compose.material.DropdownMenu
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.RadioButton
import androidx.compose.material.Text
import androidx.compose.foundation.layout.width
import androidx.compose.material.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * 対局を始める前の設定の窓。強さはポップアップで選ぶ。
 *
 * 設計: DD-L4-othello-play §9 ／ 何を選ぶかは DD-L1-othello §5.4
 * 判定を持たない。選ばれた語をそのまま共通へ渡す。★既定は 黒＝人・白＝計算機・強さは真ん中。
 * ★深くしないために、部品ごとに関数へ切り出してある（規約はネスト 4 まで）。
 */

@Composable
fun OthelloSetupDialog(onStart: (String, String, Int, Int, String) -> Unit, onCancel: () -> Unit,
                       canCancel: Boolean) {
    var black by remember { mutableStateOf("human") }
    var white by remember { mutableStateOf("machine") }
    // ★段は白黒ごとに選ぶ（CR-12）
    var blackLevel by remember { mutableStateOf(3) }
    var whiteLevel by remember { mutableStateOf(3) }
    // ★対局の名前。任意——空なら日時が名前になる（CR-9 の 9-2）
    var name by remember { mutableStateOf("") }
    AlertDialog(
        // ★戻る先が無ければ、窓の外を触っても閉じない（DD-L1-othello §5.5）
        onDismissRequest = { if (canCancel) onCancel() },
        title = { Text("対局を始める") },
        text = { SetupBody(black, white, blackLevel, whiteLevel, { black = it }, { white = it },
            { blackLevel = it }, { whiteLevel = it }, name, { name = it }) },
        confirmButton = { Button(onClick = { onStart(black, white, blackLevel, whiteLevel, name) }) { Text("始める") } },
        dismissButton = {
            Button(onClick = onCancel, enabled = canCancel) { Text("やめる") }
        }
    )
}

@Composable
private fun SetupBody(
    black: String,
    white: String,
    blackLevel: Int,
    whiteLevel: Int,
    onBlack: (String) -> Unit,
    onWhite: (String) -> Unit,
    onBlackLevel: (Int) -> Unit,
    onWhiteLevel: (Int) -> Unit,
    name: String,
    onName: (String) -> Unit
) {
    Column {
        // ★段は、その側の行のすぐ下に置く（黒の段は黒の下・白の段は白の下）
        Side("先手（黒）", black, onBlack)
        if (black == "machine") LevelPicker("　強さ（黒）", blackLevel, onBlackLevel)
        Side("後手（白）", white, onWhite)
        if (white == "machine") LevelPicker("　強さ（白）", whiteLevel, onWhiteLevel)
        // ★名前は任意。空のまま始められる（CR-9 の 9-2）
        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("名前（任意）", Modifier.weight(1f))
            TextField(value = name, onValueChange = onName, singleLine = true,
                placeholder = { Text("空なら日時") }, modifier = Modifier.width(220.dp))
        }
    }
}

@Composable
private fun Side(name: String, chosen: String, onChoose: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(name, Modifier.weight(1f))
        RadioButton(selected = chosen == "human", onClick = { onChoose("human") })
        Text("人", Modifier.padding(end = 8.dp))
        RadioButton(selected = chosen == "machine", onClick = { onChoose("machine") })
        Text("計算機")
    }
}

@Composable
private fun LevelPicker(name: String, level: Int, onChoose: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(name, Modifier.weight(1f))
        Text(level.toString() + " 段", Modifier.clickable { open = true })
        LevelMenu(open, { open = false }, onChoose)
    }
}

@Composable
private fun LevelMenu(open: Boolean, onClose: () -> Unit, onChoose: (Int) -> Unit) {
    DropdownMenu(expanded = open, onDismissRequest = onClose) {
        for (one in 1..6) {
            LevelItem(one, onChoose, onClose)
        }
    }
}

@Composable
private fun LevelItem(one: Int, onChoose: (Int) -> Unit, onClose: () -> Unit) {
    DropdownMenuItem(onClick = { onChoose(one); onClose() }) { Text(one.toString() + " 段") }
}
