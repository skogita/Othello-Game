package othello.ui

import othello.Command
import othello.View

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.delay
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * 盤・座標・石・薄い丸を描く。
 *
 * 設計: DD-L4-othello-play §9
 * 判定を持たない。受け取った一式のとおりに描き、押された升の名前を上へ渡すだけ。
 */

private val GREEN = Color(0xFF2E7D32)
private val LINE = Color(0xFF1B5E20)
private val HINT = Color(0x55FFFFFF)
private const val COLS = "abcdefgh"

@Composable
fun OthelloBoardView(view: View, onSquare: (String) -> Unit, modifier: Modifier = Modifier) {
    // ★今回裏返った升を、1 枚ずつ見せる（CR-6）。盤の中身はもう新しい——見た目だけが追いつく。
    //   ★めくり終わりを待たない。次の手はいつでも受け付ける（DD-L1-othello §6.4）。
    var shown by remember(view.moves) { mutableStateOf(0) }
    LaunchedEffect(view.moves) {
        shown = 0
        for (i in view.flipped.indices) {
            delay(120)
            shown = i + 1
        }
    }
    val turning = view.flipped.drop(shown).toSet()
    // ★文字も格子も、同じ入れ物の中で正方形に保つ（DD-L4-othello-bridge §4）。
    //   格子だけを正方形にすると、文字の行だけが窓の幅いっぱいに伸びる（BUG-41）
    Column(modifier.aspectRatio(1f)) {
        Row {
            Text(" ", Modifier.size(16.dp))
            for (col in 0..7) Text(COLS[col].toString(), Modifier.weight(1f))
        }
        Row(Modifier.weight(1f)) {
            Column(Modifier.size(16.dp).fillMaxHeight()) {
                for (row in 1..8) Text(row.toString(), Modifier.weight(1f))
            }
            BoardGrid(view, onSquare, Modifier.weight(1f), turning)
        }
    }
}

@Composable
private fun BoardGrid(
    view: View,
    onSquare: (String) -> Unit,
    modifier: Modifier,
    turning: Set<String>
) {
    Column(modifier.fillMaxSize().background(GREEN)) {
        for (row in 0..7) {
            BoardRow(view, row, onSquare, Modifier.weight(1f), turning)
        }
    }
}

/** まだめくっていない升の、前の色。★見た目だけの話で、盤の中身ではない。 */
private fun flip(stone: Char): Char = if (stone == 'B') 'W' else if (stone == 'W') 'B' else stone

@Composable
private fun BoardRow(
    view: View,
    row: Int,
    onSquare: (String) -> Unit,
    modifier: Modifier,
    turning: Set<String>
) {
    Row(modifier.fillMaxWidth()) {
        for (col in 0..7) {
            val square = "" + COLS[col] + (row + 1)
            Square(
                if (turning.contains(square)) flip(view.board[row][col]) else view.board[row][col],
                view.hints.contains(square),
                view.pressable.squares.contains(square),
                { onSquare(square) },
                Modifier.weight(1f).fillMaxSize()
            )
        }
    }
}

@Composable
private fun Square(
    stone: Char,
    hinted: Boolean,
    pressable: Boolean,
    onPress: () -> Unit,
    modifier: Modifier
) {
    Box(
        modifier.padding(1.dp).background(LINE).clickable(enabled = pressable) { onPress() },
        contentAlignment = Alignment.Center
    ) {
        if (stone == 'B') Stone(Color.Black)
        if (stone == 'W') Stone(Color.White)
        if (stone == '.' && hinted) Box(Modifier.size(12.dp).clip(CircleShape).background(HINT))
    }
}

@Composable
private fun Stone(color: Color) {
    Box(Modifier.padding(4.dp).fillMaxSize().clip(CircleShape).background(color))
}
