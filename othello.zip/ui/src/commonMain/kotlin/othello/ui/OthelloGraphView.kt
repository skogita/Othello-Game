package othello.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import othello.Trend

/** ★盤は 64 升、置いてある 4 つを除いて 60 手が上限（DD-L4-othello-graph §4）。 */
private const val LAST = 60

/**
 * 形勢の線グラフ（CR-8）。盤の下に、黒と白で 1 本ずつ。
 *
 * 設計: DD-L4-othello-graph §4
 * ★判定を持たない。受け取った並びを描くだけ。
 * ★線の色は赤と青。★終端の丸が「どちらの側か」を表す（黒丸・白丸）。
 * ★横軸は 0 手から 60 手で固定。★線は 1 手ごとに右へ伸びていく（引き伸ばさない）。
 * ★縦と横の軸を出す。★白丸は黒の縁の中を白で塗る（縁が無いと背景に隠れる）。
 */
@Composable
fun OthelloGraphView(trend: Trend, modifier: Modifier = Modifier) {
    // ★点が 1 つ以下なら線が引けない。空なら計算機が居ない対局（DD-L4-othello-graph §4）
    if (trend.black.size < 2) return
    val all = trend.black + trend.white
    val top = all.max()
    val bottom = all.min()
    val span = if (top == bottom) 1 else top - bottom
    Canvas(modifier.fillMaxSize().padding(start = 20.dp, top = 8.dp, bottom = 16.dp, end = 8.dp)) {
        // ★軸。線より細く、薄い色で（DD-L4-othello-graph §4）
        val axis = Color(0xFF888888)
        drawLine(axis, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = 1.5f)
        drawLine(axis, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = 1.5f)
        // ★横軸は 60 手で固定。並びの長さで引き伸ばさない（DD-L4-othello-graph §4）
        val stepX = size.width / LAST
        fun at(values: List<Int>, i: Int) = Offset(stepX * i,
            size.height * (1f - (values[i] - bottom).toFloat() / span))
        fun line(values: List<Int>, color: Color, fill: Color) {
            for (i in 0 until values.size - 1) {
                drawLine(color, at(values, i), at(values, i + 1), strokeWidth = 3f)
            }
            // ★終端の丸で、どちらの側かを表す。黒の縁の中を塗る
            val end = at(values, values.size - 1)
            drawCircle(Color(0xFF000000), radius = 8f, center = end)
            drawCircle(fill, radius = 5.5f, center = end)
        }
        line(trend.black, Color(0xFFD32F2F), Color(0xFF000000))
        line(trend.white, Color(0xFF1976D2), Color(0xFFFFFFFF))
    }
}
