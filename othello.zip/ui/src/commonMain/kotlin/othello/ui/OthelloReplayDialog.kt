package othello.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.AlertDialog
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import othello.GameHead

/**
 * 再生する対局を選ぶ窓（CR-10 ／ DD-L3-othello の受け皿）。
 *
 * ★判定も、問い合わせも持たない——一覧は一式に載って来る。
 * ★選ばれた番号を上へ渡すだけ。
 */
@Composable
fun OthelloReplayDialog(games: List<GameHead>, onPick: (Int) -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("再生する対局を選ぶ") },
        text = {
            // ★1 本も無ければ、選ぶものが無いと出す（DD-L1-othello §5.5b）
            if (games.isEmpty()) Text("まだ記録がありません")
            else LazyColumn(Modifier.fillMaxWidth().heightIn(max = 360.dp)) {
                items(games) { one ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Button(onClick = { onPick(one.id) }, modifier = Modifier.fillMaxWidth()) {
                            Text(label(one))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onCancel) { Text("やめる") } }
    )
}

/** ★時刻と名前で見分ける（CR-10）。段と勝敗も添える。 */
private fun label(one: GameHead): String {
    val black = one.black + side(one.blackLevel)
    val white = one.white + side(one.whiteLevel)
    val won = if (one.winner == "B") "黒勝ち" else if (one.winner == "W") "白勝ち" else "引き分け"
    return one.name + " ｜ " + black + " 対 " + white + " ｜ " + won
}

private fun side(level: Int?): String = if (level == null) "（人）" else "（段 " + level + "）"
