package othello.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.AlertDialog
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.material.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import othello.OthelloHelp

/**
 * ヘルプの画面（F-12 ／ RF-64 ／ DD-L3-othello の受け皿）。
 *
 * ★文言を持たない——本文は `OthelloHelp` が持つ（同じ文言を 2 か所に書かない）。
 * ★判定を持たない——閉じられたことを上へ渡すだけ。
 * ★並べ替えない——受け取った順がそのまま画面の順である。
 */
@Composable
fun OthelloHelpScreen(onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("ヘルプ") },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                items(OthelloHelp.sections()) { one ->
                    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                        Text(one.title, style = MaterialTheme.typography.subtitle1)
                        one.body.forEach { line ->
                            Text(line, Modifier.padding(top = 2.dp))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("閉じる") } },
    )
}
