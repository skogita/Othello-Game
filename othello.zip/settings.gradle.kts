/*
 * オセロ — Gradle の構成（DD-L2-othello §7z.5）
 *   :shared  — 共通。盤の規則・進行・打ち手・記録・境の窓口。画面を知らない
 *   :ui      — 画面。両方の環境で同じもの
 *   :desktop — Windows の口。起こし方と、置き場の伝え方だけ
 *   :android — Android の口。同上
 * ★両方を同時に組む（§7z.4）。片方だけ組んで進めない
 */
pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "othello"
include(":shared", ":ui", ":desktop", ":android")
