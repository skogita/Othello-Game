package othello.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import othello.OthelloDb
import othello.OthelloDbKeep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import othello.Command
import othello.Handled
import othello.OthelloBridge
import othello.OthelloPlace
import othello.OthelloSetup
import othello.OthelloState
import othello.Setup
import othello.ui.OthelloScreen
import othello.ui.OthelloTouch

/**
 * Android の口。★起こし方と、置き場の伝え方だけを持つ（DD-L2-othello §7z.5）。
 *
 * ★環境が用意した置き場（アプリ専用の場所）を伝えるだけで、書けるかどうかは尋ねない
 * （DD-L2-othello §7z.2c）。判断も組み立ても置かない。
 */
class OthelloHost : ComponentActivity() {

    onCreate = { savedInstanceState ->
        super.onCreate(savedInstanceState)
        val root = OthelloPlace.logRoot("othello", "", filesDir.path)
        setContent { OthelloApp(root) }
        },
}

@Composable
private fun OthelloApp(root: String) {
    var setup by remember { mutableStateOf<Setup?>(null) }
    // ★窓口が返した器を、そのまま 1 つ持つ（DD-L2-othello §7z.2b2）。
    //   状態と一式を別々に持つと、片方だけ入れ替えられてしまう。
    var held by remember { mutableStateOf<Handled?>(null) }
    // ★選び直しの窓を出しているか。対局の有無とは別に持つ（DD-L3-othello の口）
    var choosing by remember { mutableStateOf(true) }
    // ★起動のたびに 1 回、置き場の記録を DB へ戻す（DD-L3-othello-db §4.2 の 4）
    //   ★本数は利用者に見せない。★別の筋でやる——画面の筋でやると「応答しません」が出る
    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { OthelloDbKeep.importFolder(OthelloDb.openDb(root), root) }
    }

    fun send(event: Command) {
        val now = setup
        val last = held
        if (now == null || last == null) return
        held = OthelloBridge.handle(last.state, now, event, root)
    }

    // ★★**器で渡す**（★抽象でなく合成・DD-L4-othello-ui §2b）
    val touch = OthelloTouch(
        onSquare = { square -> send(Command("square", square)) },
        onPass = { send(Command("pass", "")) },
        onUndo = { send(Command("undo", "")) },

        onStart = { black, white, blackLevel, whiteLevel, name ->
            val made = OthelloSetup.newSetup(black, white, blackLevel, whiteLevel, root, "")
            // ★★器の中では早い戻りが書けない——★**作れたときだけ進む**（DD-L4-othello-ui §2b）
            if (made.black != "") {
                setup = made
                held = OthelloBridge.handle(OthelloState.newState(), made, Command("start", ""), root)
                choosing = false
            }
                },

        // ★計算機の 1 手（CR-6）。間を置くのは画面で、口はそのまま窓口へ送る
        onMachineStep = { send(Command("machine", "")) },

        // ★再生・取り込みも窓口へ送る（DD-L4-othello-bridge §3.1）。口は DB を直に呼ばない
        onReplayList = { send(Command("games", "")) },
        onReplayPick = { gameId -> send(Command("replay", gameId.toString())) },
        onReplayNext = { send(Command("next", "")) },
        onImport = { send(Command("import", "")) },
        onDump = { send(Command("dump", "")) },

        // ★ヘルプも窓口へ送る（F-12・RF-64）。★口は印を持たない——持つと共通側と食い違う
        onHelp = { send(Command("help", "")) },
        onCloseHelp = { send(Command("closeHelp", "")) },

        // ★持っている器を捨て、選び直しの窓を出す（DD-L2-othello §7z.2b1）
        // ★選び直しの窓へ戻るだけ。★対局は捨てない——やめたときの戻る先になる
        onNewGame = {
            choosing = true
                },

        // ★やめたのは選び直しであって、対局ではない。対局が無ければ戻る先が無い
        onCancelSetup = {
            if (held != null) choosing = false
                },)
    OthelloScreen(held?.view, choosing, touch)
}
