/*
 * :android — Android の口（DD-L2-othello §7z.5）
 * ★起こし方と、置き場の伝え方だけを持つ。
 */
plugins {
    id("com.android.application")
    kotlin("android")
    id("org.jetbrains.compose")
}

// ★包みの名前は、何のアプリかを言うこと（DD-L2-othello §7z.3a）
base { archivesName.set("othello") }

android {
    namespace = "othello.android"
    compileSdk = 34
    defaultConfig {
        // ★アプリを一意に指す札。仮の札（com.example）を配らない
        applicationId = "othello.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
    }
    buildTypes { debug { isDebuggable = true } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":shared"))
    implementation(project(":ui"))
    implementation(compose.runtime)
    implementation(compose.foundation)
    implementation(compose.material)
    implementation("androidx.activity:activity-compose:1.9.0")
}
