/*
 * オセロ — 版はこの環境の在庫に合わせる（実測 2026-08-12）。
 * ★同じ環境の別のアプリ（android_stocks）が同じ版で動いている。
 */
plugins {
    kotlin("jvm") version "1.9.22" apply false
    kotlin("android") version "1.9.22" apply false
    kotlin("multiplatform") version "1.9.22" apply false
    id("org.jetbrains.compose") version "1.6.11" apply false
    id("com.android.application") version "8.5.2" apply false
    id("com.android.library") version "8.5.2" apply false
}

allprojects {
    group = "com.example.othello"
    version = "0.1.0"
}
