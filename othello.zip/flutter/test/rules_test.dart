// 盤の規則の検算。★**設計書の「試験材料」をそのまま撃つ**。
// 出所: DD-L4-othello-rules §3.2 / §3.3 / §4.3 / §5.2 / §5.3 / §6.2 / §6.3
//
// ★**登録しない**（owner 指示 2026-08-23）。手元で走らせて確かめるだけの検算である。
import 'package:flutter_test/flutter_test.dart';
import 'package:othello_flutter/othello_board.dart';
import 'package:othello_flutter/othello_rules.dart';
import 'package:othello_flutter/othello_scan.dart';
import 'package:othello_flutter/othello_square.dart';
import 'package:othello_flutter/types.dart';

const List<String> start = <String>[
  '........',
  '........',
  '........',
  '...WB...',
  '...BW...',
  '........',
  '........',
  '........',
];

void main() {
  group('OthelloSquare:squareToRc — §3.2 の材料', () {
    test('盤の外=False の入力 f5 → 行と列 (4, 5)', () {
      expect(OthelloSquare.squareToRc('f5'), const Step(4, 5));
    });
    test('盤の外=True の入力 z9 → 範囲の外 (-1, -1)', () {
      expect(OthelloSquare.squareToRc('z9'), const Step(-1, -1));
    });
  });

  group('OthelloSquare:rcToSquare — §3.3 の材料', () {
    test('盤の外=False の入力 row=4, col=5 → 升の名前 f5', () {
      expect(OthelloSquare.rcToSquare(4, 5), 'f5');
    });
    test('盤の外=True の入力 row=9, col=0 → 空', () {
      expect(OthelloSquare.rcToSquare(9, 0), '');
    });
  });

  group('OthelloSquare:allSquares — §3.4 の宣言', () {
    test('先頭は a1、64 升そろう', () {
      final all = OthelloSquare.allSquares();
      expect(all.length, 64);
      expect(all[0], 'a1');
    });
  });

  group('OthelloBoard:initialBoard — §4.2 の宣言', () {
    test('[3] に WB を含む', () {
      expect(OthelloBoard.initialBoard()[3].contains('WB'), isTrue);
    });
  });

  group('OthelloBoard:copyBoard — §4.3 の材料', () {
    test('中央の行が空=True → [3] は ........', () {
      final empty = List<String>.filled(8, '........');
      expect(OthelloBoard.copyBoard(empty)[3], '........');
    });
    test('中央の行が空=False → [3] は WB を含む', () {
      expect(OthelloBoard.copyBoard(start)[3].contains('WB'), isTrue);
    });
    test('受け取った盤に触らない — 写した先は別の並び', () {
      final copy = OthelloBoard.copyBoard(start);
      expect(identical(copy, start), isFalse);
    });
  });

  group('OthelloScan:scanLine — §5.2 の材料', () {
    test('その向きで挟めない=False（row=2, col=3, 下向き, B）→ [d4]', () {
      expect(
        OthelloScan.scanLine(start, 2, 3, const Step(1, 0), 'B'),
        <String>['d4'],
      );
    });
    test('その向きで挟めない=True（row=0, col=0, 下向き, B）→ []', () {
      expect(
        OthelloScan.scanLine(start, 0, 0, const Step(1, 0), 'B'),
        <String>[],
      );
    });
  });

  group('OthelloScan:flips — §5.3 の材料', () {
    test('どの向きでも挟めない=False（d3, B）→ [d4]', () {
      expect(OthelloScan.flips(start, 'd3', 'B'), <String>['d4']);
    });
    test('升に石が在る=True（d4, B）→ []', () {
      expect(OthelloScan.flips(start, 'd4', 'B'), <String>[]);
    });
    test('どの向きでも挟めない=True（a1, B）→ []', () {
      expect(OthelloScan.flips(start, 'a1', 'B'), <String>[]);
    });
    test('升が盤の外=True（z9, B）→ []', () {
      expect(OthelloScan.flips(start, 'z9', 'B'), <String>[]);
    });
  });

  group('OthelloRules:legalMoves — §6.2 の材料', () {
    test('どの升も挟めない=False（初期配置, B）→ moves に d3 を含む', () {
      final got = OthelloRules.legalMoves(start, 'B');
      expect(got.counted, isTrue);
      expect(got.moves.contains('d3'), isTrue);
    });
    test('どの升も挟めない=True（全部黒, W）→ moves は []', () {
      final full = List<String>.filled(8, 'BBBBBBBB');
      final got = OthelloRules.legalMoves(full, 'W');
      expect(got.counted, isTrue);
      expect(got.moves, <String>[]);
    });
  });

  group('OthelloRules:applyMove — §6.3 の材料', () {
    test('裏返る升が無い=False（d3, B）→ [3] は BB を含む', () {
      expect(
        OthelloRules.applyMove(start, 'd3', 'B')[3].contains('BB'),
        isTrue,
      );
    });
    test('裏返る升が無い=True（a1, B）→ 盤は変わらない（[3] は WB）', () {
      expect(
        OthelloRules.applyMove(start, 'a1', 'B')[3].contains('WB'),
        isTrue,
      );
    });
  });

  group('OthelloRules:isOver — §6.4', () {
    test('初期配置は終わっていない', () {
      expect(OthelloRules.isOver(start), isFalse);
    });
    test('全部黒なら両者とも置けない＝終わり', () {
      expect(OthelloRules.isOver(List<String>.filled(8, 'BBBBBBBB')), isTrue);
    });
  });
}
