// 対局の進行の検算。★**設計書の挙動宣言をそのまま撃つ**。
// 出所: DD-L4-othello-play §3.2〜3.4 / §4.2〜4.4 / §5.2 / §6.2 / §6.3
//
// ★**登録しない**（owner 指示 2026-08-23）。
import 'package:flutter_test/flutter_test.dart';
import 'package:othello_flutter/othello_game.dart';
import 'package:othello_flutter/othello_setup.dart';
import 'package:othello_flutter/othello_state.dart';
import 'package:othello_flutter/othello_undo.dart';
import 'package:othello_flutter/othello_view.dart';
import 'package:othello_flutter/types.dart';

void main() {
  group('OthelloState:newState — §3.2', () {
    test('turn は B', () {
      expect(OthelloState.newState().turn, 'B');
    });
  });

  group('OthelloState:countStones — §3.3', () {
    test('盤に石が無い → どちらも 0 枚', () {
      final got = OthelloState.countStones(List<String>.filled(8, '........'));
      expect(got.black, 0);
      expect(got.white, 0);
    });
    test('初期配置 → 黒 2 枚', () {
      expect(OthelloState.countStones(OthelloState.newState().board).black, 2);
    });
  });

  group('OthelloState:lastMoveInfo — §3.4', () {
    test('履歴が空 → 無し（★0 を入れない）', () {
      expect(OthelloState.lastMoveInfo(<Entry>[]), isNull);
    });
    test('1 手指した後 → square は d3', () {
      final played = OthelloGame.play(OthelloState.newState(), 'd3');
      expect(OthelloState.lastMoveInfo(played.state!.history)!.square, 'd3');
    });
  });

  group('OthelloGame:play — §4.2', () {
    test('裏返る升が無い（a1）→ 受理しない', () {
      expect(OthelloGame.play(OthelloState.newState(), 'a1').ok, isFalse);
    });
    test('裏返る升が有る（d3）→ 受理した', () {
      expect(OthelloGame.play(OthelloState.newState(), 'd3').ok, isTrue);
    });
    test('受理したら手番が移り、手数が 1 になる', () {
      final got = OthelloGame.play(OthelloState.newState(), 'd3').state!;
      expect(got.turn, 'W');
      expect(got.moves, 1);
    });
    test('★受理したら連続パスは 0 に戻る（§4.2 の 5 の後半）', () {
      final start = OthelloState.newState();
      final dirty = GameState(start.board, start.turn, 3, 1, start.history);
      expect(OthelloGame.play(dirty, 'd3').state!.passes, 0);
    });
  });

  group('OthelloGame:beforeState — §4.3', () {
    test('黒の番 → 置く前の状態の turn は B', () {
      expect(OthelloGame.beforeState(OthelloState.newState()).turn, 'B');
    });
    test('白の番 → 白の置く前', () {
      final w = OthelloGame.play(OthelloState.newState(), 'd3').state!;
      expect(OthelloGame.beforeState(w).turn, 'W');
    });
  });

  group('OthelloGame:passTurn — §4.4', () {
    test('置ける升がある → 受理しない（★押された瞬間にもう一度数える）', () {
      expect(OthelloGame.passTurn(OthelloState.newState()).ok, isFalse);
    });
    test('置ける升が無い → 受理した', () {
      final full = List<String>.filled(8, 'BBBBBBBB');
      final stuck = GameState(full, 'W', 0, 0, <Entry>[]);
      expect(OthelloGame.passTurn(stuck).ok, isTrue);
    });
  });

  group('OthelloUndo:undo — §5.2', () {
    test('履歴が空 → 受理しない', () {
      final setup = OthelloSetup.newSetup('human', 'human', 0, 0);
      expect(OthelloUndo.undo(OthelloState.newState(), setup).ok, isFalse);
    });
    test('1 手戻すと、置く前の盤と手番に戻る', () {
      final setup = OthelloSetup.newSetup('human', 'human', 0, 0);
      final after = OthelloGame.play(OthelloState.newState(), 'd3').state!;
      final back = OthelloUndo.undo(after, setup).state!;
      expect(back.turn, 'B');
      expect(back.moves, 0);
      expect(back.board[3].contains('WB'), isTrue);
    });
    test('★白が計算機なら、人が打つ番まで戻す', () {
      final setup = OthelloSetup.newSetup('human', 'machine', 0, 3);
      var s = OthelloGame.play(OthelloState.newState(), 'd3').state!;
      s = OthelloGame.play(s, 'c3').state!;
      final back = OthelloUndo.undo(s, setup).state!;
      expect(back.turn, 'B');
    });
  });

  group('OthelloView:pressable — §6.2', () {
    test('置ける升が無い → パスだけ押せる', () {
      final full = List<String>.filled(8, 'BBBBBBBB');
      final stuck = GameState(full, 'W', 0, 0, <Entry>[]);
      final got = OthelloView.pressable(stuck, const Moves(<String>[], true));
      expect(got.pass, isTrue);
      expect(got.square, isFalse);
    });
    test('置ける升がある → 升が押せる', () {
      final got = OthelloView.pressable(
          OthelloState.newState(), const Moves(<String>['d3'], true));
      expect(got.square, isTrue);
      expect(got.pass, isFalse);
    });
  });

  group('OthelloView:buildView — §6.3', () {
    test('初期配置 → can に d3 を含む・終わっていない', () {
      final setup = OthelloSetup.newSetup('human', 'human', 0, 0);
      final v = OthelloView.buildView(OthelloState.newState(), setup);
      expect(v.can.contains('d3'), isTrue);
      expect(v.over, isFalse);
      expect(v.message, '');
      expect(v.last, isNull);
    });
    test('盤に石が無い → 置ける升が無い', () {
      final setup = OthelloSetup.newSetup('human', 'human', 0, 0);
      final empty = GameState(
          List<String>.filled(8, '........'), 'B', 0, 0, <Entry>[]);
      expect(OthelloView.buildView(empty, setup).can, <String>[]);
    });
    test('★終局したら文言が入る（引き分けと未完を同じ顔にしない）', () {
      final setup = OthelloSetup.newSetup('human', 'human', 0, 0);
      final full = GameState(
          List<String>.filled(8, 'BBBBBBBB'), 'B', 0, 0, <Entry>[]);
      final v = OthelloView.buildView(full, setup);
      expect(v.over, isTrue);
      expect(v.message.contains('黒の勝ち'), isTrue);
    });
  });
}
