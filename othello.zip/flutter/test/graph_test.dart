// 形勢のグラフの検算。設計書の挙動宣言と試験材料をそのまま撃つ。
// 出所: DD-L4-othello-graph 3.2・3.3・3.4／DD-L3-othello-graph 3.1・3.2
//
// 登録しない（owner 指示 2026-08-23）。
import 'package:flutter_test/flutter_test.dart';
import 'package:othello_flutter/othello_board.dart';
import 'package:othello_flutter/othello_graph.dart';
import 'package:othello_flutter/types.dart';

const List<String> _empty = <String>[
  '........',
  '........',
  '........',
  '........',
  '........',
  '........',
  '........',
  '........',
];

List<String> _withStone(int row, int col, String side) {
  final rows = List<String>.from(_empty);
  final line = rows[row];
  rows[row] = line.substring(0, col) + side + line.substring(col + 1);
  return rows;
}

void main() {
  group('weightSum — 3.2 の材料', () {
    test('その側の石が無い=True → 0', () {
      expect(OthelloGraph.weightSum(_empty, 'B'), 0);
    });

    test('その側の石が無い=False → 積算値（角は 120）', () {
      expect(OthelloGraph.weightSum(_withStone(0, 0, 'B'), 'B'), 120);
    });

    test('相手の石を引かない — 白が角でも黒は 0', () {
      expect(OthelloGraph.weightSum(_withStone(0, 0, 'W'), 'B'), 0);
    });

    test('初期配置は、黒も白も内側の 3 が 2 つで 6', () {
      final board = OthelloBoard.initialBoard();
      expect(OthelloGraph.weightSum(board, 'B'), 6);
      expect(OthelloGraph.weightSum(board, 'W'), 6);
    });

    // 設計: DD-L3-othello-graph 3.2「同じ枚数でも、隅を持っていれば線は高い」
    test('同じ枚数でも、隅を持っていれば高い', () {
      final corner = OthelloGraph.weightSum(_withStone(0, 0, 'B'), 'B');
      final inner = OthelloGraph.weightSum(_withStone(3, 3, 'B'), 'B');
      expect(corner, greaterThan(inner));
    });
  });

  group('appended — 3.3 の材料', () {
    test('計算機が居ない=True → そのまま（両方とも空）', () {
      final got = OthelloGraph.appended(
          const Trend(<int>[], <int>[]), OthelloBoard.initialBoard(), false);
      expect(got.black, isEmpty);
      expect(got.white, isEmpty);
    });

    test('計算機が居ない=False → 1 つ伸びる', () {
      final got = OthelloGraph.appended(
          const Trend(<int>[], <int>[]), OthelloBoard.initialBoard(), true);
      expect(got.black.length, 1);
      expect(got.white.length, 1);
      expect(got.black.first, 6);
      expect(got.white.first, 6);
    });

    test('2 本を同じ長さに保つ', () {
      var trend = const Trend(<int>[], <int>[]);
      for (var i = 0; i < 5; i++) {
        trend = OthelloGraph.appended(trend, OthelloBoard.initialBoard(), true);
      }
      expect(trend.black.length, trend.white.length);
      expect(trend.black.length, 5);
    });

    test('作り直さない — 前の並びはそのまま残る', () {
      final one = OthelloGraph.appended(
          const Trend(<int>[10], <int>[20]), _withStone(0, 0, 'B'), true);
      expect(one.black, <int>[10, 120]);
      expect(one.white, <int>[20, 0]);
    });
  });

  group('trimmed — 3.4 の材料', () {
    test('手数のほうが長い=True → そのまま', () {
      final got =
          OthelloGraph.trimmed(const Trend(<int>[10, 20], <int>[5, 8]), 5);
      expect(got.black, <int>[10, 20]);
    });

    test('手数のほうが長い=False → 切り詰める（手数 ＋ 1）', () {
      final got =
          OthelloGraph.trimmed(const Trend(<int>[10, 20], <int>[5, 8]), 0);
      expect(got.black, <int>[10]);
      expect(got.white, <int>[5]);
    });

    // 設計: DD-L4-othello-graph 3.4「＋1 を忘れると、待ったのたびに 1 つずつ短くなる」
    test('＋1 を忘れない — 手数 2 なら 3 つ残る', () {
      final got = OthelloGraph.trimmed(
          const Trend(<int>[0, 1, 2, 3, 4], <int>[0, 1, 2, 3, 4]), 2);
      expect(got.black.length, 3);
      expect(got.white.length, 3);
    });

    test('2 本とも同じ長さのまま切り詰める', () {
      final got = OthelloGraph.trimmed(
          const Trend(<int>[0, 1, 2, 3], <int>[0, 1, 2, 3]), 1);
      expect(got.black.length, got.white.length);
    });
  });
}
