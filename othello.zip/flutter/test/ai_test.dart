// 打ち手の試験。期待値は設計書から起こす（コードは見ない）。
// 出所: DD-L3-othello-ai §3.1・§3.1b・§3.2 ／ DD-L4-othello-ai §3〜§7
import 'package:flutter_test/flutter_test.dart';
import 'package:othello_flutter/othello_ai.dart';
import 'package:othello_flutter/othello_board.dart';
import 'package:othello_flutter/othello_eval.dart';
import 'package:othello_flutter/othello_param.dart';
import 'package:othello_flutter/othello_search.dart';
import 'package:othello_flutter/othello_weight.dart';

void main() {
  group('OthelloWeight.weightOf — DD-L4-othello-ai 3.2', () {
    test('角は 120', () {
      expect(OthelloWeight.weightOf(0, 0), 120);
      expect(OthelloWeight.weightOf(0, 7), 120);
      expect(OthelloWeight.weightOf(7, 0), 120);
      expect(OthelloWeight.weightOf(7, 7), 120);
    });

    test('角の斜めの隣が最も負（-40）', () {
      expect(OthelloWeight.weightOf(1, 1), -40);
      expect(OthelloWeight.weightOf(1, 6), -40);
      expect(OthelloWeight.weightOf(6, 1), -40);
      expect(OthelloWeight.weightOf(6, 6), -40);
    });

    test('内側はほとんど差を付けない（3）', () {
      expect(OthelloWeight.weightOf(3, 3), 3);
      expect(OthelloWeight.weightOf(4, 4), 3);
    });

    test('行か列が 0 から 7 の外なら 0 を返す', () {
      expect(OthelloWeight.weightOf(-1, 0), 0);
      expect(OthelloWeight.weightOf(0, 8), 0);
      expect(OthelloWeight.weightOf(8, 8), 0);
    });

    test('盤の 4 方向に対称である', () {
      for (var r = 0; r < 8; r++) {
        for (var c = 0; c < 8; c++) {
          final v = OthelloWeight.weightOf(r, c);
          expect(OthelloWeight.weightOf(r, 7 - c), v);
          expect(OthelloWeight.weightOf(7 - r, c), v);
          expect(OthelloWeight.weightOf(c, r), v);
        }
      }
    });
  });

  group('OthelloWeight.authorOf — DD-L3-othello-ai 3.1b', () {
    test('隅は 25', () {
      expect(OthelloWeight.authorOf(0, 0), 25);
      expect(OthelloWeight.authorOf(7, 7), 25);
    });

    test('隅に接する 3 升は縦・横・斜めとも -16', () {
      expect(OthelloWeight.authorOf(0, 1), -16);
      expect(OthelloWeight.authorOf(1, 0), -16);
      expect(OthelloWeight.authorOf(1, 1), -16);
    });

    test('出てくる点は 25 / -16 / 9 / -1 の 4 つだけ', () {
      final seen = <int>{};
      for (var r = 0; r < 8; r++) {
        for (var c = 0; c < 8; c++) {
          seen.add(OthelloWeight.authorOf(r, c));
        }
      }
      expect(seen, <int>{25, -16, 9, -1});
    });

    test('大外は 4 辺とも同じ並び 25 -16 9 -1 -1 9 -16 25', () {
      final top = <int>[
        for (var c = 0; c < 8; c++) OthelloWeight.authorOf(0, c)
      ];
      final bottom = <int>[
        for (var c = 0; c < 8; c++) OthelloWeight.authorOf(7, c)
      ];
      final left = <int>[
        for (var r = 0; r < 8; r++) OthelloWeight.authorOf(r, 0)
      ];
      final right = <int>[
        for (var r = 0; r < 8; r++) OthelloWeight.authorOf(r, 7)
      ];
      const want = <int>[25, -16, 9, -1, -1, 9, -16, 25];
      expect(top, want);
      expect(bottom, want);
      expect(left, want);
      expect(right, want);
    });
  });

  group('positionScore / authorScore — 手番の側から見た点', () {
    test('初期配置は、どちらの手番でも 0（対称だから）', () {
      final board = OthelloBoard.initialBoard();
      expect(OthelloWeight.positionScore(board, 'B'), 0);
      expect(OthelloWeight.positionScore(board, 'W'), 0);
      expect(OthelloWeight.authorScore(board, 'B'), 0);
    });

    test('自分の角 1 つだけなら、重みそのもの', () {
      final board = <String>[
        'B.......',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
      ];
      expect(OthelloWeight.positionScore(board, 'B'), 120);
      expect(OthelloWeight.positionScore(board, 'W'), -120);
      expect(OthelloWeight.authorScore(board, 'B'), 25);
      expect(OthelloWeight.authorScore(board, 'W'), -25);
    });
  });

  group('OthelloParam.levelParams — DD-L3-othello-ai 3.2', () {
    test('段 1 は 枚数 1・深さ 1', () {
      final p = OthelloParam.levelParams(1)!;
      expect(p.weight, 0);
      expect(p.mobility, 0);
      expect(p.stones, 1);
      expect(p.depth, 1);
    });

    test('段 4 は 重み 1・手の数 10・深さ 4', () {
      final p = OthelloParam.levelParams(4)!;
      expect(p.weight, 1);
      expect(p.mobility, 10);
      expect(p.stones, 0);
      expect(p.depth, 4);
    });

    test('段 6 は著者方式・深さ 4', () {
      final p = OthelloParam.levelParams(6)!;
      expect(p.author, true);
      expect(p.depth, 4);
    });

    test('段が 1 から 6 の外なら空の器（近い段に丸めない）', () {
      expect(OthelloParam.levelParams(0), isNull);
      expect(OthelloParam.levelParams(7), isNull);
      expect(OthelloParam.levelParams(-1), isNull);
    });

    test('段 5 は記録が無ければ段 4 に落ちる。落ちた印が付く', () {
      final p = OthelloParam.levelParams(5)!;
      final four = OthelloParam.levelParams(4)!;
      expect(p.weight, four.weight);
      expect(p.mobility, four.mobility);
      expect(p.depth, four.depth);
      expect(p.fellBack, true);
      expect(four.fellBack, false);
    });
  });

  group('OthelloEval — DD-L4-othello-ai 4', () {
    test('mobility は 初期配置で 0（黒 4 手・白 4 手）', () {
      final board = OthelloBoard.initialBoard();
      expect(OthelloEval.mobility(board, 'B'), 0);
    });

    test('段 2 は係数が全部 0 なので、どんな盤でも点は 0', () {
      final board = OthelloBoard.initialBoard();
      final p = OthelloParam.levelParams(2)!;
      expect(OthelloEval.evaluate(board, 'B', p), 0);
    });

    test('段 6 は表だけを見る。石の数も置ける升の数も見ない', () {
      final board = <String>[
        'B.......',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
      ];
      final p = OthelloParam.levelParams(6)!;
      expect(OthelloEval.evaluate(board, 'B', p), 25);
    });
  });

  group('OthelloSearch — DD-L4-othello-ai 5', () {
    test('深さ 0 なら evaluate の点と空の升', () {
      final board = OthelloBoard.initialBoard();
      final p = OthelloParam.levelParams(3)!;
      final got = OthelloSearch.search(board, 'B', 0, p, -1000000, 1000000, 0);
      expect(got.move, '');
      expect(got.score, OthelloEval.evaluate(board, 'B', p));
    });

    test('同じ盤面には同じ手を返す（同点なら入れ替えない）', () {
      final board = OthelloBoard.initialBoard();
      final p = OthelloParam.levelParams(4)!;
      final a = OthelloSearch.bestMove(board, 'B', 4, p, -1000000, 1000000, 0);
      final b = OthelloSearch.bestMove(board, 'B', 4, p, -1000000, 1000000, 0);
      expect(a, b);
    });

    test('段 2（点が全部 0）は、升の順で先頭を選ぶ', () {
      final board = OthelloBoard.initialBoard();
      final p = OthelloParam.levelParams(2)!;
      final got =
          OthelloSearch.bestMove(board, 'B', 1, p, -1000000, 1000000, 0);
      expect(got, 'c4');
    });
  });

  group('OthelloAi.chooseMove — DD-L4-othello-ai 7.2', () {
    test('パラメータが空なら、決められないと分かる形で返す', () {
      final board = OthelloBoard.initialBoard();
      final got = OthelloAi.chooseMove(board, 'B', null, 0);
      expect(got.ok, false);
      expect(got.move, '');
    });

    test('置ける升が 1 つも無ければ、手が無いと分かる形で返す', () {
      final board = <String>[
        'B.......',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
        '........',
      ];
      final got =
          OthelloAi.chooseMove(board, 'B', OthelloParam.levelParams(3), 0);
      expect(got.ok, false);
    });

    test('初期配置なら、置ける升のどれかを返す', () {
      final board = OthelloBoard.initialBoard();
      final got =
          OthelloAi.chooseMove(board, 'B', OthelloParam.levelParams(4), 0);
      expect(got.ok, true);
      expect(<String>['c4', 'd3', 'e6', 'f5'].contains(got.move), true);
    });
  });
}
