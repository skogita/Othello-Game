// 計算機の番の検算。設計書の挙動宣言と試験材料をそのまま撃つ。
// 出所: DD-L4-othello-flutter-play 8・DD-L4-othello-flutter-bridge 3.4
//
// 登録しない（owner 指示 2026-08-23）。
import 'package:flutter_test/flutter_test.dart';
import 'package:othello_flutter/othello_setup.dart';
import 'package:othello_flutter/othello_state.dart';
import 'package:othello_flutter/othello_turn.dart';
import 'package:othello_flutter/othello_view.dart';
import 'package:othello_flutter/types.dart';

/// 黒が置ける升を 1 つも持たない盤。白だけが 1 つ在り、挟める相手が居ない。
List<String> _noMoveBoard() {
  final rows = List<String>.filled(8, '........');
  rows[0] = 'W.......';
  return rows;
}

GameState _stateWith(List<String> board, String turn) {
  final fresh = OthelloState.newState();
  return GameState(board, turn, fresh.moves, fresh.passes, fresh.history);
}

void main() {
  group('machineStep — 出口「進めない」', () {
    test('人の番なら進めない', () {
      final got = OthelloTurn.machineStep(OthelloState.newState(),
          OthelloSetup.newSetup('human', 'machine', 4, 4), 0);
      expect(got.ok, isFalse);
      expect(got.passed, isFalse);
      expect(got.state, isNull);
    });
  });

  group('machineStep — 出口「打った」', () {
    test('計算機どうしなら手数が 1 増える', () {
      final got = OthelloTurn.machineStep(OthelloState.newState(),
          OthelloSetup.newSetup('machine', 'machine', 4, 4), 0);
      expect(got.ok, isTrue);
      expect(got.passed, isFalse);
      expect(got.state!.moves, 1);
    });

    test('同じ盤面には同じ手を返す（時刻が違っても）', () {
      final setup = OthelloSetup.newSetup('machine', 'machine', 4, 4);
      final a = OthelloTurn.machineStep(OthelloState.newState(), setup, 0);
      final b = OthelloTurn.machineStep(OthelloState.newState(), setup, 999);
      expect(a.state!.board, b.state!.board);
    });

    test('打つ側の組を使う — 2 手目は黒へ戻る', () {
      final setup = OthelloSetup.newSetup('machine', 'machine', 1, 6);
      final one = OthelloTurn.machineStep(OthelloState.newState(), setup, 0);
      final two = OthelloTurn.machineStep(one.state!, setup, 0);
      expect(two.ok, isTrue);
      expect(two.state!.turn, 'B');
    });
  });

  group('machineStep — 出口「パスした」', () {
    test('置ける升が無いなら、担当がパスする', () {
      final got = OthelloTurn.machineStep(_stateWith(_noMoveBoard(), 'B'),
          OthelloSetup.newSetup('machine', 'machine', 4, 4), 0);
      expect(got.ok, isTrue);
      expect(got.passed, isTrue);
      expect(got.state!.turn, 'W');
    });

    // 設計: DD-L4-othello-play 4.4 の段 3「連続パスと手数に 1 を足し」
    // ★はじめ「パスは手数に数えないだろう」と決めつけて書き、落ちた。
    // ★期待値は設計から採る。思い込みから採らない。
    test('パスでも手数は 1 増える（連続パスも 1 増える）', () {
      final before = _stateWith(_noMoveBoard(), 'B');
      final got = OthelloTurn.machineStep(
          before, OthelloSetup.newSetup('machine', 'machine', 4, 4), 0);
      expect(got.state!.moves, before.moves + 1);
      expect(got.state!.passes, before.passes + 1);
    });
  });

  group('buildView — 次も計算機の番か（DD-L2-othello 7z）', () {
    test('人の番なら machineNext は偽', () {
      final view = OthelloView.buildView(OthelloState.newState(),
          OthelloSetup.newSetup('human', 'machine', 4, 4));
      expect(view.machineNext, isFalse);
    });

    test('計算機の番なら machineNext は真', () {
      final view = OthelloView.buildView(OthelloState.newState(),
          OthelloSetup.newSetup('machine', 'machine', 4, 4));
      expect(view.machineNext, isTrue);
    });

    test('判断は一式が持つ — 画面は手番と設定を見比べない', () {
      final view = OthelloView.buildView(_stateWith(_noMoveBoard(), 'W'),
          OthelloSetup.newSetup('machine', 'human', 4, 4));
      expect(view.machineNext, isFalse);
    });
  });

  group('計算機どうしは終局まで進む（DD-L1-othello 6.4）', () {
    test('繰り返し進めると、必ず終局に着く', () {
      final setup = OthelloSetup.newSetup('machine', 'machine', 1, 1);
      var state = OthelloState.newState();
      var steps = 0;
      while (steps < 200) {
        if (OthelloView.buildView(state, setup).over) {
          break;
        }
        final got = OthelloTurn.machineStep(state, setup, 0);
        expect(got.ok, isTrue);
        state = got.state!;
        steps = steps + 1;
      }
      expect(OthelloView.buildView(state, setup).over, isTrue);
      expect(steps, lessThan(200));
    });

    test('終局したら、盤は 64 升のうち空きが無いか、両者が置けない', () {
      final setup = OthelloSetup.newSetup('machine', 'machine', 4, 4);
      var state = OthelloState.newState();
      var steps = 0;
      while (steps < 200 && !OthelloView.buildView(state, setup).over) {
        state = OthelloTurn.machineStep(state, setup, 0).state!;
        steps = steps + 1;
      }
      final view = OthelloView.buildView(state, setup);
      expect(view.over, isTrue);
      expect(view.stones.black + view.stones.white, greaterThan(4));
    });
  });
}
