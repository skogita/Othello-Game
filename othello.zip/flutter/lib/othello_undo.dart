// 待った。設計: DD-L4-othello-play §5
import 'othello_setup.dart';
import 'types.dart';

class OthelloUndo {
  /// 状態、対局の設定 → 受理したかと、★**人が打つ番まで戻した**状態か理由。
  /// 設計: DD-L4-othello-play §5.2
  ///
  /// ★**戻し忘れが起きない形にした。**状態を丸ごと積んであるので、
  /// 盤だけ戻して数字を戻し忘れる、が起こらない。
  ///
  /// ★**3 が要る理由。**人と計算機の対局で 1 手だけ戻すと、戻った先は計算機の番。
  /// すぐ計算機が打ち直し、同じ盤に戻る——押しても何も変わらないように見える。
  /// だから、**人が打つ番に着くまで戻す**。
  static Played undo(GameState state, Setup setup) {
    // 1. 履歴が空なら、受理しないで理由を返す
    if (state.history.isEmpty) {
      return const Played(false, null, 'まだ 1 手も指していません');
    }
    // 2. 履歴の末尾から、置く前の状態をそのまま取り出す
    var history = <Entry>[...state.history];
    var back = history[history.length - 1].before;
    history = history.sublist(0, history.length - 1);
    // 3. 計算機の番である間、さらに 1 つ前を取り出す。履歴が尽きたら対局の頭
    while (OthelloSetup.isMachineTurn(setup, back.turn) &&
        history.isNotEmpty) {
      back = history[history.length - 1].before;
      history = history.sublist(0, history.length - 1);
    }
    // 4. その状態を返す
    return Played(
        true,
        GameState(back.board, back.turn, back.moves, back.passes, history),
        '');
  }
}
