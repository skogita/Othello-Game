// 盤の良さ。設計: DD-L4-othello-ai §4
import 'ai_types.dart';
import 'othello_rules.dart';
import 'othello_weight.dart';

class OthelloEval {
  /// 盤、手番 → 自分が置ける升の数から、相手が置ける升の数を引いた数。
  /// 設計: DD-L4-othello-ai §4.2
  static int mobility(List<String> board, String turn) {
    // 1. legalMoves を自分の手番で呼ぶ
    final mine = OthelloRules.legalMoves(board, turn);
    // 2. 同じものを相手の手番で呼ぶ
    final other = OthelloRules.legalMoves(board, turn == 'B' ? 'W' : 'B');
    // 3. 自分の置ける升の数から、相手の置ける升の数を引いて返す
    return mine.moves.length - other.moves.length;
  }

  /// 盤、手番、パラメータの組 → 盤の良さ（手番の側から見た点）。
  /// 設計: DD-L4-othello-ai §4.3
  ///
  /// ★語で切り替えず、係数を掛ける。係数が 0 なら効かない。
  /// ★繰り返しも入れ子も無い。見方が増えても、行が 1 つ増えるだけである。
  static int evaluate(List<String> board, String turn, Params params) {
    // ★段 6 は著者方式の表だけを見る（§3.1b）。石の数も置ける升の数も見ない。
    if (params.author) {
      return OthelloWeight.authorScore(board, turn);
    }
    // 1. 点を 0 から始める
    var score = 0;
    // 2. positionScore に重みの係数を掛けて足す
    score = score + OthelloWeight.positionScore(board, turn) * params.weight;
    // 3. mobility に手の数の係数を掛けて足す
    score = score + mobility(board, turn) * params.mobility;
    // 4. 自分の石の数から相手の石の数を引き、枚数の係数を掛けて足す
    score = score + _stoneDiff(board, turn) * params.stones;
    // 5. 合計を返す
    return score;
  }

  static int _stoneDiff(List<String> board, String turn) {
    final other = turn == 'B' ? 'W' : 'B';
    var mine = 0;
    var theirs = 0;
    for (final row in board) {
      for (var col = 0; col < row.length; col++) {
        if (row[col] == turn) {
          mine = mine + 1;
        }
        if (row[col] == other) {
          theirs = theirs + 1;
        }
      }
    }
    return mine - theirs;
  }
}
