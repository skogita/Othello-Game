// 升の名前。設計: DD-L4-othello-rules §3
//
// ★升の名前と、行・列の行き来だけを持つ。盤も規則も知らない。
import 'types.dart';

class OthelloSquare {
  /// 升（`f5` の形）→ 行と列の組。盤の外なら負の値。
  /// 設計: DD-L4-othello-rules §3.2
  static Step squareToRc(String square) {
    // 1. 升の長さが 2 でなければ、負の値の組を返す
    if (square.length != 2) {
      return const Step(-1, -1);
    }
    // 2. 先頭の 1 文字を列に、次の 1 文字を行に直す
    final col = square.codeUnitAt(0) - 'a'.codeUnitAt(0);
    final row = square.codeUnitAt(1) - '1'.codeUnitAt(0);
    // 3. どちらかが 0 から 7 の外なら、負の値の組を返す
    if (row < 0 || row > 7 || col < 0 || col > 7) {
      return const Step(-1, -1);
    }
    // 4. 行と列の組を返す
    return Step(row, col);
  }

  /// 行、列 → 升の名前。盤の外なら空。
  /// 設計: DD-L4-othello-rules §3.3
  static String rcToSquare(int row, int col) {
    // 1. 行か列が 0 から 7 の外なら、空を返す
    if (row < 0 || row > 7 || col < 0 || col > 7) {
      return '';
    }
    // 2. 列を英字に、行を数字に直してつなぎ、返す
    final letter = String.fromCharCode('a'.codeUnitAt(0) + col);
    final digit = String.fromCharCode('1'.codeUnitAt(0) + row);
    return '$letter$digit';
  }

  /// 盤の 64 升の名前を並べたもの。
  /// 設計: DD-L4-othello-rules §3.4
  ///
  /// ★この関数が在るので、升を走る側は**繰り返しを 1 つで済ませられる**。
  static List<String> allSquares() {
    final out = <String>[];
    // 1. 行と列の全ての組について rcToSquare を呼ぶ
    for (var i = 0; i < 64; i++) {
      out.add(rcToSquare(i ~/ 8, i % 8));
    }
    // 2. 得た名前を並べて返す
    return out;
  }
}
