// 段のパラメータ。設計: DD-L4-othello-ai §6・DD-L3-othello-ai §3.2
import 'ai_types.dart';

/// 段ごとの組。DD-L3-othello-ai §3.2 の表そのもの。
///
/// | 段 | 重み | 手の数 | 枚数 | 深さ | 読み切り |
/// | 1 | 0 | 0 | 1 | 1 | 0 |
/// | 2 | 0 | 0 | 0 | 1 | 0 |
/// | 3 | 1 | 0 | 0 | 1 | 0 |
/// | 4 | 1 | 10 | 0 | 4 | 0 |
/// | 6 | 著者方式の表（§3.1b）・深さ 4 |
const Map<int, Params> _table = <int, Params>{
  1: Params(0, 0, 1, 1, 0, false, false),
  2: Params(0, 0, 0, 1, 0, false, false),
  3: Params(1, 0, 0, 1, 0, false, false),
  4: Params(1, 10, 0, 4, 0, false, false),
  6: Params(0, 0, 0, 4, 0, true, false),
};

class OthelloParam {
  /// 段（1 から 6）→ パラメータの組。段が範囲の外なら空の器。
  /// 設計: DD-L4-othello-ai §6.2
  ///
  /// ★近い段に丸めない。6 を渡されたら 5 として扱う作りにすると、
  /// 呼ぶ側の間違いが黙って通る。
  static Params? levelParams(int level) {
    // 1. 段が 1 から 6 の外なら、空の器を返す
    if (level < 1 || level > 6) {
      return null;
    }
    // 2. 段が 5 なら記録から選ぶ（bestParams）。
    //    ★この版は記録の読み書きを持たないので、選べない。
    // 3. 空の器が返ったら、段 4 の組をそのまま使い、
    //    ★選べなかったという印を付ける。
    //    ★黙って落とすと、記録には「段 5 で打った」と残るのに中身は段 4 に
    //    なる（§6.2 の 3）。
    if (level == 5) {
      final four = _table[4]!;
      return Params(four.weight, four.mobility, four.stones, four.depth,
          four.endgame, four.author, true);
    }
    // 4. 段が 1 から 4、または 6 なら、表からその段の組を返す
    return _table[level];
  }
}
