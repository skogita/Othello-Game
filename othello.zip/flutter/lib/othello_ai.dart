// 打ち手の入口。設計: DD-L4-othello-ai §7
import 'ai_types.dart';
import 'othello_rules.dart';
import 'othello_search.dart';

class OthelloAi {
  /// 盤、手番、パラメータの組 → 次に置く升と、決められたかどうか。
  /// 設計: DD-L4-othello-ai §7.2
  ///
  /// ★4 が終盤の読み切りである。深さを増やすのではなく、残りの空きの数と
  /// 同じにする。こうすると、終局まで読み切ったことが数で分かる。
  static Chosen chooseMove(
      List<String> board, String turn, Params? params, int nowMs) {
    // 1. パラメータが空の器なら、決められないと分かる形で返す
    if (params == null) {
      return const Chosen('', false, 'パラメータの組がありません');
    }
    // 2. legalMoves を呼ぶ
    final moves = OthelloRules.legalMoves(board, turn);
    // 3. 置ける升が 1 つも無ければ、手が無いと分かる形で返す
    if (moves.moves.isEmpty) {
      return const Chosen('', false, '置ける升がありません');
    }
    // 4. 空いている升の数が、組の「読み切りに入る空きの数」以下なら、
    //    深さを空きの数に置き換える
    var depth = params.depth;
    final empty = _emptyCount(board);
    if (params.endgame > 0 && empty <= params.endgame) {
      depth = empty;
    }
    // 4b. ★打ち切りの時刻を作る——いまから 5 秒後（DD-L1-othello-ai §4.4）
    final until = nowMs + 5000;
    // 5. bestMove を呼ぶ
    final square = OthelloSearch.bestMove(
        board, turn, depth, params, -1000000, 1000000, until);
    // 6. 返った升を器に入れて返す
    if (square.isEmpty) {
      return const Chosen('', false, '升が決まりませんでした');
    }
    return Chosen(square, true, '');
  }

  static int _emptyCount(List<String> board) {
    var n = 0;
    for (final row in board) {
      for (var col = 0; col < row.length; col++) {
        if (row[col] == '.') {
          n = n + 1;
        }
      }
    }
    return n;
  }
}
