// 対局の進行。設計: DD-L4-othello-play §4
import 'othello_rules.dart';
import 'othello_scan.dart';
import 'types.dart';

class OthelloGame {
  /// 履歴に積む「置く前の状態」。★**履歴そのものは入れない**。
  /// 設計: DD-L4-othello-play §4.3
  ///
  /// ★入れると、履歴の中に履歴が入り、深さが手数ぶん増えていく。
  /// ★**この形を 2 か所に書かない**——進めるときとパスするときの両方で積むので、
  /// 片方だけ欄が増えたときに、戻したあとの状態が食い違う。
  static Before beforeState(GameState state) {
    return Before(state.board, state.turn, state.moves, state.passes);
  }

  /// 状態、升 → 受理したかと、新しい状態か理由。
  /// 設計: DD-L4-othello-play §4.2
  static Played play(GameState state, String move) {
    // 1. flips を呼ぶ
    final turned = OthelloScan.flips(state.board, move, state.turn);
    // 2. 返った一覧が空なら、状態に触らずに受理しないで理由を返す
    if (turned.isEmpty) {
      return const Played(false, null, 'そこには置けません');
    }
    // 3. applyMove を呼ぶ
    final board = OthelloRules.applyMove(state.board, move, state.turn);
    // 4. beforeState を呼び、「置いた升・裏返った升・置く前の状態」を履歴に積む
    final history = <Entry>[...state.history,
        Entry(beforeState(state), move, turned.length)];
    // 5. 盤・手番・手数を進め、**連続パスを 0 に戻す**
    //    ★後半を落とすと、盤が動いているのに次の 1 回のパスで終局する。
    final next = state.turn == 'B' ? 'W' : 'B';
    // 6. 新しい状態を返す
    return Played(
        true, GameState(board, next, state.moves + 1, 0, history), '');
  }

  /// 状態 → 受理したかと、新しい状態か理由。
  /// 設計: DD-L4-othello-play §4.4
  static Played passTurn(GameState state) {
    // 1. legalMoves を呼ぶ
    //    ★画面が「押せた」ことを根拠にしない。押された瞬間に、もう一度数える。
    final moves = OthelloRules.legalMoves(state.board, state.turn);
    // 2. 置ける升が 1 つでもあれば、受理しないで理由を返す
    if (moves.moves.isNotEmpty) {
      return const Played(false, null, '置ける升があるのでパスできません');
    }
    // 3. 連続パスと手数に 1 を足し、写した状態を履歴に積み、手番を移す
    final history = <Entry>[...state.history,
        Entry(beforeState(state), '', 0)];
    final next = state.turn == 'B' ? 'W' : 'B';
    // 4. 連続パスが 2 なら、終局の印を立てる（★数は状態が持つ。判定は isOver）
    return Played(
        true,
        GameState(state.board, next, state.moves + 1, state.passes + 1,
            history),
        '');
  }
}
