// 升の重み。設計: DD-L4-othello-ai §3・DD-L3-othello-ai §3.1・§3.1b
//
// ★表は 1 か所にだけ持つ。片方の角の隣の符号を書き間違えると、
// その段だけが静かに弱くなる。弱くなったことは、対局してみるまで分からない。

/// 段 1〜4 の重み。DD-L3-othello-ai §3.1 の表そのもの。
/// ★上下左右に対称。★角の斜めの隣が最も負（-40）。
const List<List<int>> _weights = <List<int>>[
  <int>[120, -20, 20, 5, 5, 20, -20, 120],
  <int>[-20, -40, -5, -5, -5, -5, -40, -20],
  <int>[20, -5, 15, 3, 3, 15, -5, 20],
  <int>[5, -5, 3, 3, 3, 3, -5, 5],
  <int>[5, -5, 3, 3, 3, 3, -5, 5],
  <int>[20, -5, 15, 3, 3, 15, -5, 20],
  <int>[-20, -40, -5, -5, -5, -5, -40, -20],
  <int>[120, -20, 20, 5, 5, 20, -20, 120],
];

/// 段 6 の点。DD-L3-othello-ai §3.1b の表そのもの。
///
/// ★式で作らない。この表は利用者が升ごとに与えたものであって、
/// 距離や歩数から導けるものではない。与えられた表は、表のまま持つ。
const List<List<int>> _author = <List<int>>[
  <int>[25, -16, 9, -1, -1, 9, -16, 25],
  <int>[-16, -16, 9, 9, 9, 9, -16, -16],
  <int>[9, 9, 9, 9, 9, 9, 9, 9],
  <int>[-1, -1, 9, 9, 9, 9, -1, -1],
  <int>[-1, -1, 9, 9, 9, 9, -1, -1],
  <int>[9, 9, 9, 9, 9, 9, 9, 9],
  <int>[-16, -16, 9, 9, 9, 9, -16, -16],
  <int>[25, -16, 9, -1, -1, 9, -16, 25],
];

class OthelloWeight {
  /// 行、列 → その升の重み。設計: DD-L4-othello-ai §3.2
  static int weightOf(int row, int col) {
    // 1. 行か列が 0 から 7 の外なら、0 を返す
    if (row < 0 || row > 7 || col < 0 || col > 7) {
      return 0;
    }
    // 2. 表から、その升の重みを取って返す
    return _weights[row][col];
  }

  /// 行、列 → 段 6 の点。設計: DD-L4-othello-ai §3.3
  static int authorOf(int row, int col) {
    if (row < 0 || row > 7 || col < 0 || col > 7) {
      return 0;
    }
    return _author[row][col];
  }

  /// 盤、手番 → 自分の石の重みの合計から、相手の石の重みの合計を引いた数。
  /// 設計: DD-L4-othello-ai §3.3
  ///
  /// ★手番の側から見た点にする。黒から見た点で通すと、白の番のたびに
  /// 符号を入れ替える場所が増える。
  static int positionScore(List<String> board, String turn) {
    return _sum(board, turn, weightOf);
  }

  /// 盤、手番 → 段 6 の点の差。設計: DD-L4-othello-ai §3.4
  ///
  /// ★石の数も、置ける升の数も見ない。段 6 はこの表だけが決めである。
  static int authorScore(List<String> board, String turn) {
    return _sum(board, turn, authorOf);
  }

  /// 表を 1 つ受け取り、自分の合計から相手の合計を引く。
  /// ★この足し引きを 2 か所に書かない（片方だけ直る事故を避ける）。
  static int _sum(
      List<String> board, String turn, int Function(int, int) of) {
    final other = turn == 'B' ? 'W' : 'B';
    var total = 0;
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        final cell = board[row][col];
        if (cell == turn) {
          total = total + of(row, col);
        }
        if (cell == other) {
          total = total - of(row, col);
        }
      }
    }
    return total;
  }
}
