// 入口。設計: DD-L4-othello-flutter-bridge
//
// ★ここが「触られたことを渡す先」である。画面は判定を持たないので、
// 判定はここから下（進行・規則・打ち手）が持つ。
// ★`View` は設計書の語（一式）。Flutter の `View` と名がぶつかるので、
// ★**設計書の語を残し、Flutter の側を隠す**。
import 'dart:async';

import 'package:flutter/material.dart' hide View;

import 'othello_game.dart';
import 'othello_screen.dart';
import 'othello_setup.dart';
import 'othello_state.dart';
import 'othello_touch.dart';
import 'othello_turn.dart';
import 'othello_undo.dart';
import 'othello_view.dart';
import 'othello_graph.dart';
import 'types.dart';

void main() {
  runApp(const OthelloApp());
}

class OthelloApp extends StatelessWidget {
  const OthelloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'オセロ',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.teal),
      home: const Scaffold(body: SafeArea(child: OthelloHost())),
    );
  }
}

/// 状態を持つ 1 か所。
///
/// ★★「対局が無い」と「選び直し中」を別の欄で持つ（BUG-31）。
class OthelloHost extends StatefulWidget {
  const OthelloHost({super.key});

  @override
  State<OthelloHost> createState() => _OthelloHostState();
}

class _OthelloHostState extends State<OthelloHost> {
  GameState? _state;
  Setup _setup = OthelloSetup.newSetup('human', 'machine', 4, 4);
  bool _choosing = false;
  bool _listing = false;
  bool _helping = false;

  /// ★次の 1 手を段取り済みか。★二重に段取りしないための印
  /// （DD-L4-othello-flutter-bridge §3.4 の 3）。
  bool _pending = false;
  /// ★形勢の 2 本の並び。設計: DD-L3-othello-graph §3.3
  /// ★対局の間だけ持つ。★どこにも書かない。
  Trend _trend = const Trend(<int>[], <int>[]);
  String _message = '';

  @override
  Widget build(BuildContext context) {
    final s = _state;
    final view = s == null ? null : _viewOf(s);
    // 3. その一式を見て、次も計算機の番なら、間を置いて次の 1 手を送る段取りをする
    _scheduleMachine(view);
    return OthelloScreen(
      view: view,
      choosing: _choosing,
      setup: _setup,
      trend: _trend,
      games: const <GameHead>[],
      listing: _listing,
      helping: _helping,
      touch: OthelloTouch(
        onSquare: _onSquare,
        onPass: _onPass,
        onUndo: _onUndo,
        onNewGame: () => setState(() => _choosing = true),
        onMachineStep: _onMachineStep,
        onReplayList: () => setState(() => _listing = true),
        onReplayPick: (_) => setState(() => _listing = false),
        onReplayNext: () {},
        onImport: () => setState(() => _message = '取り込みは、この版では持ちません'),
        onDump: () => setState(() => _message = '書き出しは、この版では持ちません'),
        onHelp: () => setState(() => _helping = true),
        onCloseHelp: () => setState(() => _helping = false),
        onStart: _onStart,
        onCancelSetup: () => setState(() {
          _choosing = false;
          _listing = false;
        }),
      ),
    );
  }

  View _viewOf(GameState s) {
    final base = OthelloView.buildView(s, _setup);
    if (_message.isEmpty) {
      return base;
    }
    return View(base.board, base.turn, base.can, base.stones, base.moves,
        base.over, base.last, base.pressable, _message,
        machineNext: base.machineNext);
  }

  /// ★次も計算機なら、間を置いてから次の 1 手を送る。
  /// 設計: DD-L4-othello-flutter-bridge §3.4
  ///
  /// ★★間を置くのは画面の側である。共通は時計を見ない。
  /// ★★判断はここでしない——一式が言う（DD-L2-othello §7z）。
  void _scheduleMachine(View? view) {
    // 1. 一式が「次も計算機の番」と言っていなければ、何もしない
    if (view == null || !view.machineNext) {
      return;
    }
    // 2. 終局していれば、何もしない
    if (view.over) {
      return;
    }
    // 3. すでに段取り済みなら、二重に段取りしない
    if (_pending) {
      return;
    }
    // 4. 間を置く（★盤が見えるだけの長さ・BUG-24／CR-6）
    _pending = true;
    Timer(const Duration(milliseconds: 700), () {
      _pending = false;
      // 5. 間を置いたあと、計算機の 1 手を送る
      _onMachineStep();
    });
  }

  void _onStart(String black, String white, int blackLevel, int whiteLevel,
      String name) {
    setState(() {
      _setup = OthelloSetup.newSetup(black, white, blackLevel, whiteLevel);
      _state = OthelloState.newState();
      _choosing = false;
      _message = '';
      // ★対局を始めたときに、0 手目の分を 1 つ入れる（初期配置の積算）。
      // ★入れないと、線が 1 手目から始まる（DD-L3-othello-graph §5.1）。
      _trend = OthelloGraph.appended(const Trend(<int>[], <int>[]),
          _state!.board, OthelloSetup.hasMachine(_setup));
    });
  }

  void _onSquare(String square) {
    final s = _state;
    if (s == null) {
      return;
    }
    final got = OthelloGame.play(s, square);
    setState(() {
      if (got.ok && got.state != null) {
        _state = got.state;
        _message = '';
        _pushTrend(got.state!);
      } else {
        _message = got.why;
      }
    });
  }

  void _onPass() {
    final s = _state;
    if (s == null) {
      return;
    }
    final got = OthelloGame.passTurn(s);
    setState(() {
      if (got.ok && got.state != null) {
        _state = got.state;
        _message = '';
        // ★パスでも手数は 1 増える（DD-L4-othello-play §4.4 段 3）。
        // ★★横軸は手数なので、線も 1 つ足す——足さないと長さがずれる。
        _pushTrend(got.state!);
      } else {
        _message = got.why;
      }
    });
  }

  void _onUndo() {
    final s = _state;
    if (s == null) {
      return;
    }
    final got = OthelloUndo.undo(s, _setup);
    setState(() {
      if (got.ok && got.state != null) {
        _state = got.state;
        _message = '';
        // ★横軸が手数だから、手数が戻れば線も戻る（CR-8）。
        // ★足すのと切り詰めるのを、同じ場所でやる。
        _trend = OthelloGraph.trimmed(_trend, got.state!.moves);
      } else {
        _message = got.why;
      }
    });
  }

  /// 計算機の 1 手。設計: DD-L4-othello-flutter-bridge §3.5
  ///
  /// ★★時計を見るのはここである。打ち手は時計を見ない。
  /// ★★手が無いときのパスは machineStep の中で起きる——ここで分岐を持たない。
  void _onMachineStep() {
    final s = _state;
    if (s == null) {
      return;
    }
    // 2. いまの時刻を取り、machineStep を呼ぶ
    final got = OthelloTurn.machineStep(
        s, _setup, DateTime.now().millisecondsSinceEpoch);
    if (!mounted) {
      return;
    }
    setState(() {
      // 3. 進められなければ、返ってきた理由を出して終わる
      if (!got.ok || got.state == null) {
        _message = got.why;
        return;
      }
      // 4. 進められたら、新しい状態に入れ替える
      _state = got.state;
      _message = '';
      _pushTrend(got.state!);
    });
  }

  /// ★2 本の並びの末尾へ、1 つずつ足す。設計: DD-L3-othello-graph §5.1 の段 4
  ///
  /// ★画面は数えないので、ここで作って渡す。
  /// ★★計算機が居なければ、`appended` が何もしない（人どうしの対局）。
  void _pushTrend(GameState s) {
    _trend =
        OthelloGraph.appended(_trend, s.board, OthelloSetup.hasMachine(_setup));
  }
}
