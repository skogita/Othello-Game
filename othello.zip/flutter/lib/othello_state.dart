// 対局の状態。設計: DD-L4-othello-play §3
import 'othello_board.dart';
import 'types.dart';

class OthelloState {
  /// 初期配置・黒番・手数 0 の状態。
  /// 設計: DD-L4-othello-play §3.2
  static GameState newState() {
    // 1. initialBoard を呼ぶ
    final board = OthelloBoard.initialBoard();
    // 2. 盤・手番（黒）・手数 0・空の履歴・連続パス 0 を器に入れて返す
    return GameState(board, 'B', 0, 0, <Entry>[]);
  }

  /// 盤 → 黒と白の枚数。
  /// 設計: DD-L4-othello-play §3.3
  static Stones countStones(List<String> board) {
    // 1. 盤の全ての升を見て、黒と白をそれぞれ数える
    var black = 0;
    var white = 0;
    for (final row in board) {
      for (var i = 0; i < row.length; i++) {
        if (row[i] == 'B') {
          black = black + 1;
        }
        if (row[i] == 'W') {
          white = white + 1;
        }
      }
    }
    // 2. 2 つの数を器に入れて返す
    return Stones(black, white);
  }

  /// 履歴 → 直前の升と裏返った枚数。★**履歴が空なら「無し」**。
  /// 設計: DD-L4-othello-play §3.4
  ///
  /// ★**履歴が空のときに 0 を入れない。**入れると、対局開始直後の画面に
  /// 「裏返った石 0 枚」と出て、1 手も指していないことと 0 枚裏返ったことが
  /// 同じ見た目になる。
  static LastMove? lastMoveInfo(List<Entry> history) {
    // 1. 履歴が空なら、「無し」を返す（空の器ではない）
    if (history.isEmpty) {
      return null;
    }
    // 2. 末尾から、置いた升と裏返った升の数を取り出して器に入れて返す
    final last = history[history.length - 1];
    return LastMove(last.square, last.flipped);
  }
}
