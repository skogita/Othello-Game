// 画面へ渡すもの。設計: DD-L4-othello-play §6
import 'othello_rules.dart';
import 'othello_setup.dart';
import 'othello_state.dart';
import 'types.dart';

class OthelloView {
  /// 升・パス・待った、それぞれ押せるか。
  /// 設計: DD-L4-othello-play §6.2
  static Pressable pressable(GameState state, Moves moves) {
    // 1. 升は、置ける升の一覧をそのまま押せるものとする
    final square = moves.moves.isNotEmpty;
    // 2. パスは、置ける升が 0 のときだけ押せるものとする
    final pass = moves.moves.isEmpty;
    // 3. 待ったは、履歴があるときだけ押せるものとする
    final undo = state.history.isNotEmpty;
    // 4. 3 つを器に入れて返す
    return Pressable(square, pass, undo);
  }

  /// 画面が描くのに要るもの一式。★**画面はこれ 1 つで足りる**。
  /// 設計: DD-L4-othello-play §6.3
  ///
  /// ★★**「打てない」を画面に任せない。**画面が押せる升を無視するだけだと、
  /// 次の画面が来たときに、また押せるように見える——
  /// **押せないことは、渡すものの側で決める。**
  ///
  /// ★**前に渡した器を書き換えて使い回さない。**画面がまだ描いている途中の
  /// 値を書き換えることになる。
  static View buildView(GameState state, Setup setup) {
    // 1. legalMoves を呼ぶ
    final moves = OthelloRules.legalMoves(state.board, state.turn);
    // 2. countStones を呼ぶ
    final stones = OthelloState.countStones(state.board);
    // 3. lastMoveInfo を呼ぶ
    final last = OthelloState.lastMoveInfo(state.history);
    // 4. pressable を呼ぶ
    final press = pressable(state, moves);
    // 6. isOver を呼び、終局していれば終局の文言を入れる。していなければ空
    final over = OthelloRules.isOver(state.board);
    final message = over ? _result(stones) : '';
    // 7. 以上を**新しい器**にまとめて返す
    return View(state.board, state.turn, moves.moves, stones, state.moves,
        over, last, press, message,
        machineNext: OthelloSetup.isMachineTurn(setup, state.turn));
  }

  /// 終局の文言。★**引き分けと未完を同じ顔にしない**。
  static String _result(Stones stones) {
    if (stones.black > stones.white) {
      return '黒の勝ちです（${stones.black} 対 ${stones.white}）';
    }
    if (stones.white > stones.black) {
      return '白の勝ちです（${stones.white} 対 ${stones.black}）';
    }
    return '引き分けです（${stones.black} 対 ${stones.white}）';
  }

  /// いまの手番の段。計算機でなければ持たない。
  static int? levelOrNone(Setup setup, String turn) {
    if (!OthelloSetup.isMachineTurn(setup, turn)) {
      return null;
    }
    return OthelloSetup.levelOf(setup, turn);
  }
}
