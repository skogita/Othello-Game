// 打ち手の値の型。設計: DD-L3-othello-ai §3.2・DD-L4-othello-ai §5・§7

/// 打ち手のパラメータの組。設計: DD-L3-othello-ai §3.2
///
/// ★**語で切り替えず、係数を掛ける。**係数が 0 なら効かない
/// （DD-L4-othello-ai §4.3）。★語の組み合わせを探す形にすると、
/// 記録から選ぶときに比べられなくなる（数なら比べられる）。
class Params {
  final int weight;
  final int mobility;
  final int stones;
  final int depth;
  final int endgame;

  /// ★段 6 は著者方式の表**だけ**を見る（DD-L3-othello-ai §3.1b）。
  final bool author;

  /// ★段 5 で選べなかったとき、段 4 に落ちたことの印。
  /// ★**黙って落とすと、記録には「段 5 で打った」と残るのに中身は段 4**
  /// という食い違いができる（DD-L4-othello-ai §6.2 の 3）。
  final bool fellBack;

  const Params(this.weight, this.mobility, this.stones, this.depth,
      this.endgame, this.author, this.fellBack);
}

/// 読みの結果。点と、そこで最良だった升。
class Searched {
  final int score;
  final String move;
  const Searched(this.score, this.move);
}

/// 次に置く升と、決められたかどうか。
class Chosen {
  final String move;
  final bool ok;
  final String why;
  const Chosen(this.move, this.ok, this.why);
}
