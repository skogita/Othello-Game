// 盤の下に、形勢の線を 2 本描く。設計: DD-L4-othello-ui §3.5
//
// ★★判定を持たない——★優劣を書かない（★見る人が読む）。
// だから「黒が有利」「押している」といった語をここに出さない。
// ★重みの表も持たない。数える所と描く所を分ける。
import 'package:flutter/material.dart';

import 'types.dart';

/// 手数を横、重みの積算値を縦にして、★2 本の線を引く。
class OthelloGraphView extends StatelessWidget {
  final Trend trend;
  const OthelloGraphView({super.key, required this.trend});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // ★どちらの線がどちらかを、名で出す。★優劣は書かない。
          Row(
            children: const <Widget>[
              _Key(color: Color(0xFF1B2430), label: '黒'),
              SizedBox(width: 16),
              _Key(color: Color(0xFF8B95A3), label: '白'),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: CustomPaint(
              painter: _TrendPainter(trend),
              child: Container(),
            ),
          ),
        ],
      ),
    );
  }
}

/// 線の名札。
class _Key extends StatelessWidget {
  final Color color;
  final String label;
  const _Key({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Container(width: 18, height: 3, color: color),
        const SizedBox(width: 6),
        Text(label, style: const TextStyle(fontSize: 13)),
      ],
    );
  }
}

class _TrendPainter extends CustomPainter {
  final Trend trend;
  _TrendPainter(this.trend);

  @override
  void paint(Canvas canvas, Size size) {
    final axis = Paint()
      ..color = const Color(0xFFC8D0DA)
      ..strokeWidth = 1;
    // 横の軸（0 の線）
    canvas.drawLine(Offset(0, size.height / 2),
        Offset(size.width, size.height / 2), axis);
    if (trend.black.length < 2) {
      return;
    }
    // ★2 本を同じ物差しで描く——別々に伸ばすと、比べられない
    final top = _top();
    _line(canvas, size, trend.black, top, const Color(0xFF1B2430));
    _line(canvas, size, trend.white, top, const Color(0xFF8B95A3));
  }

  /// 2 本を合わせた、いちばん大きい絶対値。0 なら 1 にする（割れなくなるため）。
  int _top() {
    var top = 1;
    for (final v in trend.black) {
      final a = v < 0 ? -v : v;
      if (a > top) {
        top = a;
      }
    }
    for (final v in trend.white) {
      final a = v < 0 ? -v : v;
      if (a > top) {
        top = a;
      }
    }
    return top;
  }

  void _line(
      Canvas canvas, Size size, List<int> values, int top, Color color) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final x = size.width * i / (values.length - 1);
      final y = size.height / 2 - (size.height / 2) * values[i] / top;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_TrendPainter old) => old.trend != trend;
}
