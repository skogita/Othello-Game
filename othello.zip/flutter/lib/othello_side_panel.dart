// わきの補助情報とボタン。設計: DD-L4-othello-ui §3.4
// ★`View` は設計書の語（一式）。Flutter の `View` と名がぶつかるので、
// ★**設計書の語を残し、Flutter の側を隠す**。
import 'package:flutter/material.dart' hide View;

import 'othello_touch.dart';
import 'types.dart';

/// ★押されたことを、そのまま渡す——★押せるかどうかの判定も、ここではしない。
/// 押せるかどうかは、一式（View.pressable）が持っている。
class OthelloSidePanel extends StatelessWidget {
  final View view;
  final Setup setup;
  final OthelloTouch touch;
  const OthelloSidePanel(
      {super.key,
      required this.view,
      required this.setup,
      required this.touch});

  @override
  Widget build(BuildContext context) {
    final p = view.pressable;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        // 1. 手番・枚数・手数・直前の手・置ける升の数・強さを出す
        _line('手番', view.turn == 'B' ? '黒' : '白'),
        _line('枚数', '黒 ${view.stones.black} ／ 白 ${view.stones.white}'),
        _line('手数', '${view.moves}'),
        _line(
            '直前の手',
            view.last == null
                ? '無し'
                : '${view.last!.square}（${view.last!.flipped} 枚）'),
        _line('置ける升', '${view.can.length}'),
        _line('強さ', '黒 ${setup.blackLevel} ／ 白 ${setup.whiteLevel}'),
        if (view.message.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(view.message,
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
        const SizedBox(height: 12),
        // 2. ボタンを並べる（★ヘルプはいちばん下）
        _button('パス', p.pass ? touch.onPass : null),
        _button('待った', p.undo ? touch.onUndo : null),
        _button('計算機の 1 手', touch.onMachineStep),
        // ★新しい対局はいつでも押せる（DD-L1-othello §6.5c）
        _button('新しい対局', touch.onNewGame),
        _button('再生', touch.onReplayList),
        _button('取り込み', touch.onImport),
        _button('書き出し', touch.onDump),
        _button('ヘルプ', touch.onHelp),
      ],
    );
  }

  Widget _line(String name, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(name, style: const TextStyle(color: Color(0xFF5B6673))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _button(String label, void Function()? onPressed) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: OutlinedButton(onPressed: onPressed, child: Text(label)),
    );
  }
}
