// 走査。設計: DD-L4-othello-rules §5
//
// ★**8 方向の定めを持つのは、このファイルだけ。**
import 'othello_square.dart';
import 'types.dart';

class OthelloScan {
  /// 8 つの向き。★ここだけが持つ。
  static const List<Step> steps = <Step>[
    Step(-1, -1), Step(-1, 0), Step(-1, 1),
    Step(0, -1), Step(0, 1),
    Step(1, -1), Step(1, 0), Step(1, 1),
  ];

  /// その向きで挟める升の一覧。挟めなければ空。
  /// 設計: DD-L4-othello-rules §5.2
  ///
  /// ★**この関数は 1 方向しか見ない。**だから繰り返しが 1 つで済み、深くならない。
  static List<String> scanLine(
      List<String> board, int row, int col, Step step, String turn) {
    final other = turn == 'B' ? 'W' : 'B';
    final got = <String>[];
    // 1. 置く升から、渡された向きへ 1 つ進む
    var r = row + step.row;
    var c = col + step.col;
    // 2. 相手の石が続くあいだ、升の名前に直し、集めながら進む
    while (r >= 0 && r < 8 && c >= 0 && c < 8 && board[r][c] == other) {
      got.add(OthelloSquare.rcToSquare(r, c));
      r = r + step.row;
      c = c + step.col;
    }
    // 3. 止まった先が自分の石で、かつ 1 つ以上集めていれば、集めた升を返す
    if (r >= 0 && r < 8 && c >= 0 && c < 8 && board[r][c] == turn &&
        got.isNotEmpty) {
      return got;
    }
    // 4. そうでなければ、空を返す
    return <String>[];
  }

  /// 裏返る升の一覧。置けないときは空。
  /// 設計: DD-L4-othello-rules §5.3
  static List<String> flips(List<String> board, String move, String turn) {
    // 1. squareToRc を呼ぶ
    final rc = OthelloSquare.squareToRc(move);
    // 2. 返った組が負なら、空を返す
    if (rc.row < 0 || rc.col < 0) {
      return <String>[];
    }
    // 3. その升に既に石が在れば、空を返す
    if (board[rc.row][rc.col] != '.') {
      return <String>[];
    }
    // 4. 8 つの向きのそれぞれについて scanLine を呼び、返った升をつなぐ
    final out = <String>[];
    for (final step in steps) {
      out.addAll(scanLine(board, rc.row, rc.col, step, turn));
    }
    // 5. つないだ一覧を返す
    return out;
  }
}
