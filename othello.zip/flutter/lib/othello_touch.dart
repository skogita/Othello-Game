// 触られたことを渡す口の束。設計: DD-L4-othello-ui §2b
//
// ★interface は使わない（C 規約「interface 禁止（抽象・合成せよ）」）。
// ★入れ替えたいのは「振る舞い」ではなく「渡し先」である。
// ★画面は判定を持たないので、渡す口の束を、そのまま器で受け取ればよい。
//
// ★14 の口を 1 つの器で渡す——引数を 14 個並べない
// （並べると、呼ぶ側が順を覚える）。
class OthelloTouch {
  final void Function(String square) onSquare;
  final void Function() onPass;
  final void Function() onUndo;
  final void Function() onNewGame;
  final void Function() onMachineStep;
  final void Function() onReplayList;
  final void Function(int gameId) onReplayPick;
  final void Function() onReplayNext;
  final void Function() onImport;
  final void Function() onDump;
  final void Function() onHelp;
  final void Function() onCloseHelp;
  final void Function(String black, String white, int blackLevel,
      int whiteLevel, String name) onStart;
  final void Function() onCancelSetup;

  const OthelloTouch({
    required this.onSquare,
    required this.onPass,
    required this.onUndo,
    required this.onNewGame,
    required this.onMachineStep,
    required this.onReplayList,
    required this.onReplayPick,
    required this.onReplayNext,
    required this.onImport,
    required this.onDump,
    required this.onHelp,
    required this.onCloseHelp,
    required this.onStart,
    required this.onCancelSetup,
  });
}

/// 控えの 1 件（再生の窓が並べるもの）。
class GameHead {
  final int gameId;
  final String name;
  final int moves;
  const GameHead(this.gameId, this.name, this.moves);
}
