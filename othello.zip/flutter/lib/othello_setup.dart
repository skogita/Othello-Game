// 対局の設定。設計: DD-L4-othello-play §7
import 'types.dart';

class OthelloSetup {
  /// 黒の打ち手、白の打ち手、それぞれの段 → 設定。
  static Setup newSetup(
      String black, String white, int blackLevel, int whiteLevel) {
    return Setup(black, white, blackLevel, whiteLevel);
  }

  /// いまの手番が計算機かどうか。
  ///
  /// ★**どちらが人かを知っているのは設定だけ**（§5.2 の 3）。
  static bool isMachineTurn(Setup setup, String turn) {
    if (turn == 'B') {
      return setup.black == 'machine';
    }
    return setup.white == 'machine';
  }

  /// 計算機が居るかどうか。設計: DD-L3-othello-graph §5.1 の段 2
  ///
  /// ★★人どうしの対局なら、形勢の並びは両方とも空のままにする
  /// （DD-L1-othello §5.2c）——★測る物差しが段の表だからである。
  static bool hasMachine(Setup setup) {
    return setup.black == 'machine' || setup.white == 'machine';
  }

  /// いまの手番の段。計算機でなければ 0。
  static int levelOf(Setup setup, String turn) {
    if (turn == 'B') {
      return setup.blackLevel;
    }
    return setup.whiteLevel;
  }
}
