// 形勢を数え、並びに足す。設計: DD-L4-othello-flutter-graph §3
//
// ★数える所と描く所を分ける。描く側に重みの表を写すと、
// ★段を足したときに片方だけ古くなる。
import 'othello_weight.dart';
import 'types.dart';

class OthelloGraph {
  /// 盤、どちらの側か → その側の石が乗っている升の重みの合計。
  /// 設計: DD-L4-othello-flutter-graph §3.2
  ///
  /// ★相手の石を引かない。2 本の線で見せるので、それぞれの側の合計が要る。
  /// ★★表を段で切り替えない。黒と白で段が違えば表も違うので、
  /// 切り替えると 2 本の線が違う基準になる（CR-8・CR-12）。
  static int weightSum(List<String> board, String side) {
    var total = 0;
    // 1. 盤の升を 1 つずつ見る
    for (var row = 0; row < 8; row++) {
      for (var col = 0; col < 8; col++) {
        // 2. その升にその側の石が乗っていれば、升の重みを足す
        //    3. いつも weightOf を使う（★段から切り離した物差し）
        if (board[row][col] == side) {
          total = total + OthelloWeight.weightOf(row, col);
        }
      }
    }
    // 4. 合計を返す
    return total;
  }

  /// いままでの 2 本、いまの盤、計算機が居るか → 1 つ伸びた 2 本。
  /// 設計: DD-L4-othello-flutter-graph §3.3
  static Trend appended(Trend now, List<String> board, bool machine) {
    // 1. 計算機が居なければ、そのまま返す（人どうしの対局）
    if (!machine) {
      return now;
    }
    // 2. 黒と白について 1 回ずつ呼ぶ
    // 3. 2 本の並びの末尾へ、1 つずつ足して返す
    //    ★2 本を同じ長さに保つ。片方だけ足すと、横軸のどこを指すか分からない。
    return Trend(
      List<int>.from(now.black)..add(weightSum(board, 'B')),
      List<int>.from(now.white)..add(weightSum(board, 'W')),
    );
  }

  /// いままでの 2 本、いまの手数 → 手数に合わせて切り詰めた 2 本。
  /// 設計: DD-L4-othello-flutter-graph §3.4
  ///
  /// ★1 で「＋1」を忘れない。忘れると、待ったのたびに線が 1 つずつ短くなる。
  static Trend trimmed(Trend now, int moves) {
    // 1. 残す数を出す——手数 ＋ 1（0 手目を含むから）
    final keep = moves + 1;
    // 3. いまの長さのほうが短ければ、そのまま返す（伸ばさない）
    if (now.black.length <= keep) {
      return now;
    }
    // 2. 2 本とも、先頭からその数だけ残して返す
    return Trend(
      now.black.sublist(0, keep),
      now.white.sublist(0, keep),
    );
  }
}
