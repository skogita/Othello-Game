// 控えから選ぶ窓。設計: DD-L4-othello-ui §3.7
import 'package:flutter/material.dart';

import 'othello_touch.dart';

/// 控えの一覧を並べ、選ばれた番号を渡す。
///
/// ★並べるのは、終わった対局だけ。★どれが終わったかは渡された一覧が決める
/// （★画面は判定しない）。
class OthelloReplayDialog extends StatelessWidget {
  final List<GameHead> games;
  final OthelloTouch touch;
  const OthelloReplayDialog(
      {super.key, required this.games, required this.touch});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('控えから選びます'),
      content: SizedBox(
        width: 360,
        child: games.isEmpty
            ? const Text('控えがありません。')
            : ListView(
                shrinkWrap: true,
                children: <Widget>[
                  // 1. 控えの一覧を並べる
                  for (final g in games)
                    ListTile(
                      title: Text(g.name),
                      subtitle: Text('${g.moves} 手'),
                      // 2. 選ばれた番号を渡す
                      onTap: () => touch.onReplayPick(g.gameId),
                    ),
                ],
              ),
      ),
      actions: <Widget>[
        TextButton(
            onPressed: touch.onCancelSetup, child: const Text('閉じる')),
      ],
    );
  }
}
