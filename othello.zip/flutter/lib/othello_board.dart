// 盤という値。設計: DD-L4-othello-rules §4
//
// ★盤を作る、写す。**判定は持たない。**

class OthelloBoard {
  /// 初期配置の盤。8 行、各行 8 文字。
  /// 設計: DD-L4-othello-rules §4.2
  static List<String> initialBoard() {
    // 1. 空の升だけの 8 行 8 列を作る
    final rows = <List<String>>[];
    for (var r = 0; r < 8; r++) {
      rows.add(List<String>.filled(8, '.'));
    }
    // 2. 中央 4 升に、白・黒・黒・白の順で置く
    rows[3][3] = 'W';
    rows[3][4] = 'B';
    rows[4][3] = 'B';
    rows[4][4] = 'W';
    // 3. その盤を返す
    return rows.map((r) => r.join()).toList();
  }

  /// 盤 → 中身の同じ**新しい**盤。
  /// 設計: DD-L4-othello-rules §4.3
  ///
  /// ★**受け取った盤に触らない。**待ったのときに 1 手前の盤を
  /// そのまま使えるようにするため。
  static List<String> copyBoard(List<String> board) {
    // 1. 盤の各行を 1 つずつ写して、新しい並びを作る
    final out = <String>[];
    for (final row in board) {
      out.add(row);
    }
    // 2. 新しい盤を返す
    return out;
  }
}
