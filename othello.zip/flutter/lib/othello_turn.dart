// 計算機の番。打ち手に聞いて 1 手進める。設計: DD-L4-othello-flutter-play §8
//
// ★この関数は盤を読まない。置ける升の判定も、裏返しも、全部よそが持っている。
import 'othello_ai.dart';
import 'othello_game.dart';
import 'othello_param.dart';
import 'othello_setup.dart';
import 'types.dart';

/// 計算機の 1 手を進めた結果。
class Stepped {
  final bool ok;
  final bool passed;
  final GameState? state;
  final String why;
  const Stepped(this.ok, this.passed, this.state, this.why);
}

class OthelloTurn {
  /// 進めたかと、新しい状態か理由。設計: DD-L4-othello-flutter-play §8.2
  static Stepped machineStep(GameState state, Setup setup, int nowMs) {
    // 1. いまの手番が計算機でなければ、進めないと分かる形で返す
    if (!OthelloSetup.isMachineTurn(setup, state.turn)) {
      return const Stepped(false, false, null, '人の番なので進めない');
    }
    // 2. 打つ側の組を使う。間違えると相手の強さで打つ
    final level = OthelloSetup.levelOf(setup, state.turn);
    final params = OthelloParam.levelParams(level);
    // 3. 打ち手に手を聞く
    final chosen = OthelloAi.chooseMove(state.board, state.turn, params, nowMs);
    // 4. 升が空なら、passTurn を呼ぶ。置けない番の担当がパスする
    if (chosen.move == '') {
      final passed = OthelloGame.passTurn(state);
      return Stepped(passed.ok, true, passed.state, chosen.why);
    }
    // 5. 升が在れば、その升で打つ
    final played = OthelloGame.play(state, chosen.move);
    return Stepped(played.ok, false, played.state, played.why);
  }
}
