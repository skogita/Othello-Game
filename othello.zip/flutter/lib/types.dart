// オセロ — 値の型。設計: DD-L4-othello-rules §2a・DD-L4-othello-play §2a
//
// ★盤は 8 行、各行 8 文字の並び（`.` は空、`B` は黒、`W` は白）。
// ★升は `f5` の形。先頭の 1 文字が列、次の 1 文字が行。

/// 行と列の組。盤の外なら負の値。
class Step {
  final int row;
  final int col;
  const Step(this.row, this.col);

  @override
  bool operator ==(Object other) =>
      other is Step && other.row == row && other.col == col;

  @override
  int get hashCode => row * 31 + col;

  @override
  String toString() => '($row, $col)';
}

/// 置ける升の器。
///
/// ★一覧そのものにせず器にしたのは、**数えた結果が 0 件であること**と
/// **呼ばれていないこと**を、受け取った側が言い分けられるようにするため
/// （DD-L4-othello-rules §6.1）。
class Moves {
  final List<String> moves;
  final bool counted;
  const Moves(this.moves, this.counted);
}

/// 黒と白の枚数。
class Stones {
  final int black;
  final int white;
  const Stones(this.black, this.white);
}

/// 直前の手。★履歴が空なら「無し」＝この型を持たない。
class LastMove {
  final String square;
  final int flipped;
  const LastMove(this.square, this.flipped);
}

/// 履歴に積む「置く前の状態」。★履歴そのものは入れない
/// （DD-L4-othello-play `OthelloGame:beforeState`）。
class Before {
  final List<String> board;
  final String turn;
  final int moves;
  final int passes;
  const Before(this.board, this.turn, this.moves, this.passes);
}

/// 履歴の 1 件。
class Entry {
  final Before before;
  final String square;
  final int flipped;
  const Entry(this.before, this.square, this.flipped);
}

/// 対局の状態。
class GameState {
  final List<String> board;
  final String turn;
  final int moves;
  final int passes;
  final List<Entry> history;
  const GameState(this.board, this.turn, this.moves, this.passes, this.history);
}

/// 受理したかと、新しい状態か理由。
class Played {
  final bool ok;
  final GameState? state;
  final String why;
  const Played(this.ok, this.state, this.why);
}

/// 対局の設定。
class Setup {
  final String black;
  final String white;
  final int blackLevel;
  final int whiteLevel;
  const Setup(this.black, this.white, this.blackLevel, this.whiteLevel);
}

/// 升・パス・待った、それぞれ押せるか。
class Pressable {
  final bool square;
  final bool pass;
  final bool undo;
  const Pressable(this.square, this.pass, this.undo);
}

/// 形勢の 2 本の並び。設計: DD-L3-othello-graph §3.1
///
/// ★2 本を別々の長さにしない。長さが違うと、
/// ★横軸のどこを指しているかが分からなくなる。
/// ★引かない——黒は黒の合計、白は白の合計。差ではなく 2 本の線で見せる。
class Trend {
  final List<int> black;
  final List<int> white;
  const Trend(this.black, this.white);
}

/// 画面が描くのに要るもの一式。★画面はこれ 1 つで足りる。
class View {
  final List<String> board;
  final String turn;
  final List<String> can;
  final Stones stones;
  final int moves;
  final bool over;
  final LastMove? last;
  final Pressable pressable;
  final String message;

  /// ★次も計算機の番か。設計: DD-L2-othello §7z・DD-L1-othello §6.4
  ///
  /// ★真なら、画面は**間を置いてから次の出来事を送る**。
  /// ★★**画面は判断しない——一式が言う。**
  final bool machineNext;
  const View(this.board, this.turn, this.can, this.stones, this.moves,
      this.over, this.last, this.pressable, this.message,
      {this.machineNext = false});
}
