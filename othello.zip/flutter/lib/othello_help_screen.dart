// 遊び方を読む画面。設計: DD-L4-othello-ui §3.8（F-12）
import 'package:flutter/material.dart';

import 'othello_touch.dart';

/// 遊び方・操作・ボタンの意味を並べ、閉じられたことを渡す。
///
/// ★対局する人に向けたもの——★作る人に向けた説明はここに置かない。
class OthelloHelpScreen extends StatelessWidget {
  final OthelloTouch touch;
  const OthelloHelpScreen({super.key, required this.touch});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('遊び方'),
      content: SizedBox(
        width: 420,
        child: ListView(
          shrinkWrap: true,
          children: const <Widget>[
            // 1. 遊び方・操作・ボタンの意味を並べる
            _Head('遊び方'),
            _Item('黒から始めます。相手の石を挟める升にだけ置けます。'),
            _Item('置くと、挟んだ石が全部裏返ります。'),
            _Item('置ける升が 1 つも無いときは、パスします。'),
            _Item('両者ともパスになったら終わりです。石の多いほうが勝ちです。'),
            _Head('操作'),
            _Item('置ける升には、薄い丸が出ます。その升を押します。'),
            _Head('ボタン'),
            _Item('パス — 置ける升が 1 つも無いときだけ押せます。'),
            _Item('待った — 1 手戻します。'),
            _Item('計算機の 1 手 — 計算機の番を、1 手だけ進めます。'),
            _Item('新しい対局 — いつでも押せます。'),
            _Item('再生 — 終わった対局を選んで、手を追えます。'),
            _Item('取り込み／書き出し — 記録をやりとりします。'),
          ],
        ),
      ),
      actions: <Widget>[
        // 2. 閉じられたことを渡す
        FilledButton(onPressed: touch.onCloseHelp, child: const Text('閉じる')),
      ],
    );
  }
}

class _Head extends StatelessWidget {
  final String text;
  const _Head(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 14, bottom: 4),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold)),
    );
  }
}

class _Item extends StatelessWidget {
  final String text;
  const _Item(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Text('・$text'),
    );
  }
}
