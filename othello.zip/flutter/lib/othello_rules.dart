// 盤の規則。設計: DD-L4-othello-rules §6
//
// ★盤と手番を受け取り、答えを返す。状態を持たない。
import 'othello_board.dart';
import 'othello_scan.dart';
import 'othello_square.dart';
import 'types.dart';

class OthelloRules {
  /// 置ける升と、数えたことの印を持つ器。
  /// 設計: DD-L4-othello-rules §6.2
  ///
  /// ★器にしたのは、**数えた結果が 0 件であること**と
  /// **呼ばれていないこと**を言い分けられるようにするため。
  static Moves legalMoves(List<String> board, String turn) {
    // 1. allSquares を呼ぶ
    final squares = OthelloSquare.allSquares();
    // 2. 得た升のそれぞれについて flips を呼び、空でなければ集める
    final got = <String>[];
    for (final square in squares) {
      if (OthelloScan.flips(board, square, turn).isNotEmpty) {
        got.add(square);
      }
    }
    // 3. 集めた升と、数えたという印を器に入れて返す
    return Moves(got, true);
  }

  /// 置いた後の**新しい**盤。
  /// 設計: DD-L4-othello-rules §6.3
  static List<String> applyMove(
      List<String> board, String move, String turn) {
    // 1. flips を呼ぶ
    final turned = OthelloScan.flips(board, move, turn);
    // 2. 返った一覧が空なら、置けないので**盤を変えずに**そのまま返す
    if (turned.isEmpty) {
      return board;
    }
    // 3. copyBoard を呼んで新しい盤を作る
    final rows =
        OthelloBoard.copyBoard(board).map((r) => r.split('')).toList();
    // 4. 置いた升と裏返る升のそれぞれを行と列に直し、その升を手番の色にする
    final all = <String>[move, ...turned];
    for (final square in all) {
      final rc = OthelloSquare.squareToRc(square);
      rows[rc.row][rc.col] = turn;
    }
    // 5. 新しい盤を返す
    return rows.map((r) => r.join()).toList();
  }

  /// 両者とも置ける升が無ければ真。
  /// 設計: DD-L4-othello-rules §6.4
  static bool isOver(List<String> board) {
    return legalMoves(board, 'B').moves.isEmpty &&
        legalMoves(board, 'W').moves.isEmpty;
  }
}
