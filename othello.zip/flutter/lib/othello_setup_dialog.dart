// 始める前の窓。設計: DD-L4-othello-ui §3.6
import 'package:flutter/material.dart';

import 'othello_touch.dart';

/// 誰が黒か・強さ・先手と後手を決めさせる窓。
///
/// ★やめられるかは、渡された印で決める——★対局が無いときはやめられない。
class OthelloSetupDialog extends StatefulWidget {
  final bool canCancel;
  final OthelloTouch touch;
  const OthelloSetupDialog(
      {super.key, required this.canCancel, required this.touch});

  @override
  State<OthelloSetupDialog> createState() => _OthelloSetupDialogState();
}

class _OthelloSetupDialogState extends State<OthelloSetupDialog> {
  // 1. 黒と白のそれぞれを、人か計算機か選ばせる（F-6・4 通り）
  String _black = 'human';
  String _white = 'machine';
  // 2. 強さを 6 段階から選ばせる（F-8）
  int _blackLevel = 4;
  int _whiteLevel = 4;
  // 3. 先手と後手を決めさせる（F-7）
  String _first = 'B';
  final TextEditingController _name = TextEditingController(text: 'othello');

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('対局を始めます'),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _who('黒', _black, (v) => setState(() => _black = v)),
            _level('黒の強さ', _blackLevel, (v) => setState(() => _blackLevel = v)),
            const Divider(),
            _who('白', _white, (v) => setState(() => _white = v)),
            _level('白の強さ', _whiteLevel, (v) => setState(() => _whiteLevel = v)),
            const Divider(),
            _firstRow(),
            TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: '対局の名'),
            ),
          ],
        ),
      ),
      actions: <Widget>[
        // 4. やめられるかは、渡された印で決める
        if (widget.canCancel)
          TextButton(
              onPressed: widget.touch.onCancelSetup, child: const Text('やめる')),
        FilledButton(
          onPressed: () => widget.touch.onStart(
              _first == 'B' ? _black : _white,
              _first == 'B' ? _white : _black,
              _first == 'B' ? _blackLevel : _whiteLevel,
              _first == 'B' ? _whiteLevel : _blackLevel,
              _name.text),
          child: const Text('始める'),
        ),
      ],
    );
  }

  Widget _who(String label, String value, void Function(String) onChanged) {
    return Row(
      children: <Widget>[
        SizedBox(width: 44, child: Text(label)),
        Expanded(
          child: SegmentedButton<String>(
            segments: const <ButtonSegment<String>>[
              ButtonSegment<String>(value: 'human', label: Text('人')),
              ButtonSegment<String>(value: 'machine', label: Text('計算機')),
            ],
            selected: <String>{value},
            onSelectionChanged: (s) => onChanged(s.first),
          ),
        ),
      ],
    );
  }

  Widget _level(String label, int value, void Function(int) onChanged) {
    return Row(
      children: <Widget>[
        SizedBox(width: 76, child: Text(label)),
        Expanded(
          child: DropdownButton<int>(
            isExpanded: true,
            value: value,
            items: <DropdownMenuItem<int>>[
              for (var i = 1; i <= 6; i++)
                DropdownMenuItem<int>(value: i, child: Text('段 $i')),
            ],
            onChanged: (v) => onChanged(v ?? value),
          ),
        ),
      ],
    );
  }

  Widget _firstRow() {
    return Row(
      children: <Widget>[
        const SizedBox(width: 44, child: Text('先手')),
        Expanded(
          child: SegmentedButton<String>(
            segments: const <ButtonSegment<String>>[
              ButtonSegment<String>(value: 'B', label: Text('黒から')),
              ButtonSegment<String>(value: 'W', label: Text('白から')),
            ],
            selected: <String>{_first},
            onSelectionChanged: (s) => setState(() => _first = s.first),
          ),
        ),
      ],
    );
  }
}
