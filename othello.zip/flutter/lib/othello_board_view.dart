// 盤を描く。設計: DD-L4-othello-ui §3.3
// ★`View` は設計書の語（一式）。Flutter の `View` と名がぶつかるので、
// ★**設計書の語を残し、Flutter の側を隠す**。
import 'package:flutter/material.dart' hide View;

import 'othello_square.dart';
import 'othello_touch.dart';
import 'types.dart';

/// 盤を描き、升が押されたことを名前で渡す。
///
/// ★画面は判定を持たない——置ける升は、一式が持っている一覧から印を付ける。
/// ★画面は数えない。
class OthelloBoardView extends StatelessWidget {
  final View view;
  final OthelloTouch touch;
  const OthelloBoardView(
      {super.key, required this.view, required this.touch});

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF14624A),
          border: Border.all(color: const Color(0xFF0D3F30), width: 3),
        ),
        // 1. 8×8 の升を描く（升の名は a1 の形）
        child: Column(
          children: <Widget>[
            for (var row = 0; row < 8; row++)
              Expanded(
                child: Row(
                  children: <Widget>[
                    for (var col = 0; col < 8; col++)
                      Expanded(child: _cell(row, col)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _cell(int row, int col) {
    final square = OthelloSquare.rcToSquare(row, col);
    final stone = view.board[row][col];
    // 3. 置ける升に印を付ける（一式が持っている一覧から）
    final canPlace = view.can.contains(square);
    return GestureDetector(
      // 4. 押された升を、名前で渡す
      onTap: () => touch.onSquare(square),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFF0D4A39)),
        ),
        child: Center(child: _mark(stone, canPlace)),
      ),
    );
  }

  // 2. 石を描く（黒・白）
  Widget _mark(String stone, bool canPlace) {
    if (stone == 'B') {
      return const _Disc(Color(0xFF111111));
    }
    if (stone == 'W') {
      return const _Disc(Color(0xFFF2F2F2));
    }
    if (canPlace) {
      return const _Hint();
    }
    return const SizedBox.shrink();
  }
}

class _Disc extends StatelessWidget {
  final Color color;
  const _Disc(this.color);

  @override
  Widget build(BuildContext context) {
    return FractionallySizedBox(
      widthFactor: 0.78,
      heightFactor: 0.78,
      child: DecoratedBox(
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
    );
  }
}

class _Hint extends StatelessWidget {
  const _Hint();

  @override
  Widget build(BuildContext context) {
    return const FractionallySizedBox(
      widthFactor: 0.26,
      heightFactor: 0.26,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Color(0x73FFFFFF),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
