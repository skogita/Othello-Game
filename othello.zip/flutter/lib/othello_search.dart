// 先を読む。設計: DD-L4-othello-ai §5
import 'ai_types.dart';
import 'othello_eval.dart';
import 'othello_rules.dart';

class OthelloSearch {
  /// 盤、手番、深さ、組、下限、上限、打ち切りの時刻 → 点と最良の升。
  /// 設計: DD-L4-othello-ai §5.2
  ///
  /// ★5 の反転を落とさない。落とすと、相手にとって良い手を、自分にとって
  /// 良い手として選ぶ。エラーは出ない。ただ弱くなるだけなので、対局してみる
  /// まで気付けない。
  ///
  /// ★6 の「同点なら入れ替えない」が、升の順を効かせている。並べる順を決めず
  /// に最大を取ると、点数が並んだ瞬間に非決定になる。★この決めは読みの全段で
  /// 効く。
  ///
  /// ★渡された盤は書き換えない。規則が新しい盤を返すので、戻す処理が要らない。
  static Searched search(List<String> board, String turn, int depth,
      Params params, int alpha, int beta, int until) {
    // 1. 深さが 0 なら evaluate を呼び、その点と空の升を返す
    if (depth == 0) {
      return Searched(OthelloEval.evaluate(board, turn, params), '');
    }
    // 2. legalMoves を呼ぶ
    final moves = OthelloRules.legalMoves(board, turn);
    // 3. 置ける升が 1 つも無ければ、同じく evaluate を呼び、その点と空の升を返す
    if (moves.moves.isEmpty) {
      return Searched(OthelloEval.evaluate(board, turn, params), '');
    }
    // 4. 置ける升を升の順に並べる
    final ordered = List<String>.from(moves.moves)..sort();
    var bestScore = -1000000;
    var bestMoveSquare = '';
    var low = alpha;
    for (final square in ordered) {
      // 5. applyMove で新しい盤を作り、相手の手番で 1 段深く読み、
      //    ★返った点の符号を反転する
      final next = OthelloRules.applyMove(board, square, turn);
      final deeper = search(next, turn == 'B' ? 'W' : 'B', depth - 1, params,
          -beta, -low, until);
      final score = -deeper.score;
      // 6. その点が下限より高ければ、最良の升と点を入れ替える。
      //    ★同点なら入れ替えない
      if (score > bestScore) {
        bestScore = score;
        bestMoveSquare = square;
      }
      if (score > low) {
        low = score;
      }
      // 7. 下限が上限以上になったら、そこで止める
      if (low >= beta) {
        break;
      }
    }
    // 8. 最良の点と升を、器に入れて返す
    return Searched(bestScore, bestMoveSquare);
  }

  /// 升だけが欲しい呼び手のための口。設計: DD-L4-othello-ai §5.3
  ///
  /// ★この関数は読みを持たない。
  static String bestMove(List<String> board, String turn, int depth,
      Params params, int alpha, int beta, int until) {
    // 1. search を呼ぶ
    final got = search(board, turn, depth, params, alpha, beta, until);
    // 2. 返った器から升を取り出して返す
    return got.move;
  }
}
