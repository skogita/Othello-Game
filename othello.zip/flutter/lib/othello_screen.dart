// 3 つを並べ、触られたことを渡す。設計: DD-L4-othello-ui §3.2
// ★`View` は設計書の語（一式）。Flutter の `View` と名がぶつかるので、
// ★**設計書の語を残し、Flutter の側を隠す**。
import 'package:flutter/material.dart' hide View;

import 'othello_board_view.dart';
import 'othello_graph_view.dart';
import 'othello_help_screen.dart';
import 'othello_replay_dialog.dart';
import 'othello_setup_dialog.dart';
import 'othello_side_panel.dart';
import 'othello_touch.dart';
import 'types.dart';

/// 画面の入口。
///
/// ★★画面は判定を持たない——受け取った一式を描き、触られたことを渡すだけ。
///
/// ★★「対局が無い」と「選び直し中」を、同じ欄で兼ねない——
/// 兼ねると、やめても対局が無いことになり、また同じ窓が出る
/// （BUG-31・実測 2026-08-12）。だから `view == null`（対局が無い）と
/// `choosing`（選び直し中）を別の欄で受け取る。
class OthelloScreen extends StatelessWidget {
  final View? view;
  final bool choosing;
  final Setup setup;
  final Trend trend;
  final List<GameHead> games;
  final bool listing;
  final bool helping;
  final OthelloTouch touch;

  const OthelloScreen({
    super.key,
    required this.view,
    required this.choosing,
    required this.setup,
    required this.trend,
    required this.games,
    required this.listing,
    required this.helping,
    required this.touch,
  });

  @override
  Widget build(BuildContext context) {
    final v = view;
    return Stack(
      children: <Widget>[
        // 2. 在れば、盤・わき・グラフの 3 つを並べる
        if (v != null) _three(v) else const SizedBox.shrink(),
        // 1. 一式が無ければ、始める窓を出す（★盤は描かない）
        //    ★選び直し中も同じ窓を出すが、そのときは「やめる」が押せる
        if (v == null || choosing)
          OthelloSetupDialog(canCancel: v != null, touch: touch),
        if (listing) OthelloReplayDialog(games: games, touch: touch),
        if (helping) OthelloHelpScreen(touch: touch),
      ],
    );
  }

  Widget _three(View v) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            flex: 3,
            child: Column(
              children: <Widget>[
                // ★盤は、残った高さの中に収める。
                // ★実測 2026-08-23: 収めずに置いたら、8 行目が窓の外へ出て、
                // ★グラフも見えなかった（owner の画面で確認）。
                Expanded(
                    child: Center(
                        child: OthelloBoardView(view: v, touch: touch))),
                const SizedBox(height: 12),
                OthelloGraphView(trend: trend),
              ],
            ),
          ),
          const SizedBox(width: 20),
          Expanded(
            flex: 2,
            // 3. 触られたことを、そのまま渡す（★画面は判定しない）
            child: SingleChildScrollView(
              child: OthelloSidePanel(view: v, setup: setup, touch: touch),
            ),
          ),
        ],
      ),
    );
  }
}
