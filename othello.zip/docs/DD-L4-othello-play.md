# DD-L4 関数仕様 — 対局の進行と画面

- doc_id : DD-L4-othello-play ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **対局の進行・待った・表示の組み立て・設定・計算機の番**について、関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料を定める。
- 出典 : DD-L3-othello §2（受け皿のうち進行と画面の側）・§5（状態遷移）・§7（概要の手順）
- 呼ぶ相手 : [[DD-L4-othello-rules]]（盤の規則）・[[DD-L4-othello-ai]]（打ち手）・[[DD-L4-othello-log]]（記録）。★**呼び方は、いずれも呼ばれる側が決めたものをそのまま使う**

---

## 0. L4 と L5 の役割分担

このアプリは**全部 L4 に書く**。L5 は書かない。

| 層 | 何を書く層か | オセロではどうか |
|:---|:---|:---|
| L4 | 関数単位の仕様。インタフェース・挙動・手順 | ★**ここに全部書く** |
| L5 | 拡張として差し込む実装のプロトコル仕様 | ★**書かない。**差し込みの口を持たないアプリだから |


### 0b. ★言語を移したときに、何が変わって何が変わらなかったか

この一式は、共通の実装を別の言語へ移した（[[DD-L2-othello]] §7z.4）。**そのとき何が動いたかを残す。**

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | どのファイルに何を置くか。1 つも動かしていない |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | 段の並びは 1 つも変えていない |
| 挙動の宣言 | 条件も出口も、認めかたも同じ |
| 試験の材料 | 入力の値も、期待値も同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | 綴りの決まりが違う（区切りの記号と、大文字の使い方） |
| メソッドの名 | 同上 |
| クラスの欄 | 擬似のものから、**実在する入れ物の名**へ |
| 型の名 | その言語の型へ |

★★**設計が言語に依っていなかったことが、ここで確かめられた。**
もし手順や宣言まで書き直す必要が出ていたなら、それは**設計に実装の都合が混ざっていた**ということである。

★**型の名だけは、記法の側の都合で調整した**（下の「型の名に読点を入れない」）。
これは設計の内容ではなく、**書き表し方の問題**である。

## 1. ファイルの分け方 — 上限に張り付かせない

規約は、Python が 1 ファイル 300 行・5 関数まで、ネストは 4 まで、分岐は 20 まで。
**上限ちょうどで設計しない。**上限に張り付いた設計は、次に 1 つ足した瞬間に超え、割り直しになる。

**目安は、1 ファイル 3 関数まで・100 行まで・ネスト 2 まで**とする。

| ファイル | 関数 | 行数の見込み | ネストの深さ | 何を持つか |
|:---|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloState.kt` | 3 | 約 60 | 2 | 対局の状態を作る・数える・直前の手 |
| `shared/src/main/kotlin/othello/OthelloGame.kt` | 3 | 約 70 | 2 | 1 手進める・パス・置く前の状態を写す |
| `shared/src/main/kotlin/othello/OthelloUndo.kt` | 1 | 約 40 | 2 | 待った（人が打つ番まで戻す） |
| `shared/src/main/kotlin/othello/OthelloView.kt` | 2 | 約 70 | 2 | 押せるものを決める・一式を組み立てる |
| `shared/src/main/kotlin/othello/OthelloSetup.kt` | 2 | 約 40 | 1 | 対局の設定を作る・計算機の番かを答える |
| `shared/src/main/kotlin/othello/OthelloTurn.kt` | 1 | 約 40 | 1 | 計算機の番なら 1 手進める |
| `shared/src/main/kotlin/othello/OthelloPlace.kt` | 1 | 約 25 | 1 | 記録の置き場を決める |

### 1.1 ★状態を持つクラスをやめた

DD-L3-othello では対局の進行をクラス 1 つにしていたが、**値と関数に分けた**。

| 前 | 後 |
|:---|:---|
| `Game` が盤・手番・手数・履歴・連続パスを持ち、メソッドが書き換える | **状態は器 1 つの値**。`play` などは**受け取って、新しい状態を返す** |

こうすると、メソッドが 4 つ以上になる圧力が消え、**どの関数も引数と戻り値だけで試験できる**。
状態を書き換える関数が 1 つも無いので、待ったも「前の状態をそのまま使う」だけで済む。

書き換えないことの効き目は、待ったのところで最も大きい。書き換える作りだと、戻すために「何を元に戻すか」を一つずつ数え上げることになる。盤を戻し、手番を戻し、手数を戻し、連続パスを戻す。数え上げた表から一つ落ちれば、そこだけが 1 手前のまま残る。しかも落ちたことは、その場では分からない。**戻す代わりに、前の状態をそのまま取り出す形にすれば、落ちようがない。**

★**状態を器の値にすると、試験も楽になる。**関数に器を渡して、返ってきた器を見るだけで済む。あらかじめ組み立てておくものが何も要らない。

### 1b. ★書いた後の実測（2026-08-12）

見込みと、実際に書いたものを並べる。**見込みだけ書いて確かめないと、上限に張り付いていないことが言えない。**

| ファイル | 関数（見込み→実測） | 行数（見込み→実測） | ネスト（見込み→実測） |
|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloState.kt` | 3 → **3** | 60 → **27** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloGame.kt` | 3 → **3** | 70 → **42** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloUndo.kt` | 1 → **1** | 40 → **22** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloView.kt` | 2 → **2** | 70 → **27** | 2 → **0** |
| `shared/src/main/kotlin/othello/OthelloSetup.kt` | 2 → **2** | 40 → **30** | 1 → **1** |
| `shared/src/main/kotlin/othello/OthelloTurn.kt` | 1 → **1** | 40 → **24** | 1 → **1** |

★**行数はどれも見込みより短い。**規約（300 行・5 関数・ネスト 4）にも、目安（3 関数・100 行・ネスト 2）にも、**張り付いていない**。

## 2. 綴りの決め

関数を名指す綴りは、**この設計書のどこでも `コードファイルの相対パス:クラス:メソッド`** とする。区切りはすべて `:`。
クラスに属さない関数は `(module)` と書く。系の外は `外` と書く。
引数と戻り値の型は、**表と呼び出しにだけ**書く。

★**分岐の無い関数は、特徴を書かない。**条件が無いのだから、「どの条件を撃ったか」も無い。無いものを埋めるために特徴をこしらえると、**試験が何を確かめているのか分からなくなる**。

★**引数を取らない関数は、材料を書かずに免除にする。**★分類は `other_language` を使う——★**免除の分類は述語で裏付くものだけが効く**（[[DD-L4-dsl-exempt-audit]] §免除の法）。`no_args` の述語は Python の構文木を引くので、この一式（Kotlin）では裏付かない。


★★**型の名に読点を入れない。**この記法は引数を読点で区切るので、
`Pair<Int, Int>` のような型をそのまま書くと、**引数が 1 つ増えたように読まれる**。
∴ 読点を含む型には**別名を付けて**使う（`Step`＝向きの組、`Body`＝記録の中身）。
★**記法が読める形にするのは、書き手の仕事である。**読み手を賢くして解決しない。

## 2a. クラスとメソッド

★**クラスの欄を空にしない。**この一式では、モジュールごとに **`object` を 1 つ**置き、
関数はその中に入る。★**クラス名は、その `object` の名である**（`USER_MANUAL` §3.10・`DesignClass`）。
**「クラスを持たない」という状態は無い。**

| クラス | コードファイル | 親クラス | 属するメソッド |
|:---|:---|:---|:---|
| `OthelloState` | `shared/src/main/kotlin/othello/OthelloState.kt` | 無し（object） | `newState` ・ `countStones` ・ `lastMoveInfo` |
| `OthelloGame` | `shared/src/main/kotlin/othello/OthelloGame.kt` | 無し（object） | `play` ・ `passTurn` ・ `beforeState` |
| `OthelloUndo` | `shared/src/main/kotlin/othello/OthelloUndo.kt` | 無し（object） | `undo` |
| `OthelloView` | `shared/src/main/kotlin/othello/OthelloView.kt` | 無し（object） | `pressable` ・ `buildView` |
| `OthelloSetup` | `shared/src/main/kotlin/othello/OthelloSetup.kt` | 無し（object） | `newSetup` ・ `isMachineTurn` |
| `OthelloTurn` | `shared/src/main/kotlin/othello/OthelloTurn.kt` | 無し（object） | `machineStep` |
| `OthelloPlace` | `shared/src/main/kotlin/othello/OthelloPlace.kt` | 無し（object） | `logRoot` |

★★**この表と、インタフェース表は別物である。**
ここは**どのクラスにどのメソッドが属するか**を決める表であり、
インタフェース表は各メソッドの**入口と出口の項目**（名前・型・順序）を決める表である。
**所属が無ければ呼び先が解けず、項目が無ければ引数が合っているかを照合できない。**

★**親クラスは持たない。**`object` は継承の木に載らない。★**状態を持たない**ので、包む必要が無い。

★**この一式は、進行と画面の側である。**盤の規則を持たず、打ち手も記録も持たない。
持っているのは、**状態をどう進めるか**と、**画面へ何を渡すか**と、**境をどう越えるか**の 3 つだけである。

★**状態を書き換えない、という決めが、ここでいちばん効いている。**進める関数も、パスも、待ったも、
**受け取った状態には触らず、新しい状態を返す**。だから待ったは、積んである前の状態を取り出すだけで済む。
戻すために何を元に戻すかを数え上げる作業が、**そもそも要らない**。

★**境の窓口が薄いことにも理由がある。**出来事を受けて、進行のどれかを呼び、一式を作って返すだけ。
ここに判断を足すと、**同じ判断が窓口と進行の 2 か所に生まれる**。

## 2b. 試験材料の値は、実体で書く

★**材料の値に呼び名を書かない。**「初期の盤」「人と計算機の設定」のような名で置くと、
**その名が何を指すのかは、どこにも書かれていない**ことになる。読む側が想像で埋めるしかなく、
書いた本人の頭の中にしか正しい値が無い。★**試験は、その想像の上に立つことになる。**

| 書き方 | 可否 | なぜ |
|:---|:---|:---|
| 呼び名（`board=initial`） | ★**不可** | 中身が無い。試験を起こす材料にならない |
| 実体（8 行の並びをそのまま） | 可 | そのまま渡せる。読めば何を試しているかが分かる |

盤は **8 つの文字列**で持つ。1 文字が 1 升で、`.` が空、`B` が黒、`W` が白である。
上から 4 行目と 5 行目の真ん中に、白と黒が斜めに 2 つずつ置かれているのが、対局の始まりの形である。

★**値が長くなることを嫌がらない。**長いのは、盤という物が実際に 64 升あるからであって、
書き方が悪いからではない。**短く書くために名前で逃げると、その名前の中身を誰も確かめられなくなる。**

★**同じ値を 2 か所に書くことは避けられない。**材料は行ごとに独立していなければならないからである。
ここで大事なのは、**食い違ったときに気付ける形**であることで、
どの行も**そのまま読めば何の盤か分かる**なら、突き合わせは目で足りる。

---

---

## 3. 対局の状態 — `shared/src/main/kotlin/othello/OthelloState.kt`

状態は**器 1 つの値**。盤・手番・手数・履歴・連続パスを持つ。**書き換えない。**

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState() -> State` | 無し | 初期配置・黒番・手数 0 の状態 |
| `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones(board: List<String>) -> Stones` | 盤 | 黒と白の枚数 |
| `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo(history: List<Entry>) -> LastMove?` | 履歴 | 直前の升と裏返った枚数。★**履歴が空なら「無し」** |

### 3.2 `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` の処理手順

1. `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard() -> List<String>` を呼ぶ
2. 盤・手番（黒）・手数 0・空の履歴・連続パス 0 を器に入れて返す

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState`
- それ以外は「初期の状態」
- 出口「初期の状態」は `['turn']:B` で認める

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★引数も無いので材料で変えられる入力が無い。★中身は `shared/src/test/kotlin/othello/OthelloPlayGroupTest.kt` が現に確かめている

### 3.3 `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones` の処理手順

1. 盤の全ての升を見て、黒と白をそれぞれ数える
2. 2 つの数を器に入れて返す

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones`
- 入口の語: `board`
- もし `盤に石が無い` なら「どちらも 0 枚」
- それ以外は「枚数」
- 出口「どちらも 0 枚」は `['B']:0` で認める
- 出口「枚数」は `['B']:2` で認める

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones` の試験材料

- 入力 `board=["........", "........", "........", "........", "........", "........", "........", "........"]` のとき 特徴 `盤に石が無い=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"]` のとき 特徴 `盤に石が無い=False`
- 出口「どちらも 0 枚」は `['B']:0` で認める
- 出口「枚数」は `['B']:2` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo` の処理手順

1. 履歴が空なら、★**「無し」を返す**（空の器ではない。空の器は「升 `` に打った」と読めてしまう）
2. 末尾から、置いた升と裏返った升の数を取り出して器に入れて返す

★**履歴が空のときに 0 を入れない。**入れると、対局開始直後の画面に「裏返った石 0 枚」と出て、
1 手も指していないことと、0 枚裏返ったことが同じ見た目になる。

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo`
- 入口の語: `history`
- もし `履歴が空` なら「まだ 1 手も無い」
- それ以外は「直前の手」
- 出口「まだ 1 手も無い」は `is_none` で認める
- 出口「直前の手」は `['square']:d3` で認める

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo` の試験材料

- 入力 `history=[]` のとき 特徴 `履歴が空=True`
- 入力 `history=[{"square": "d3", "flipped": ["d4"], "before": {"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "passes": 0}}]` のとき 特徴 `履歴が空=False`
- 出口「まだ 1 手も無い」は `is_none` で認める
- 出口「直前の手」は `['square']:d3` で認める

---

## 3z. ★受け渡しの器（★道つきで書く・法 §4-1）

| ファイル | 中の器 |
|:---|:---|
| `shared/src/main/kotlin/othello/Types.kt` | `Step`（升の位置）・`Moves`（置ける升と★**数えたかどうか**）・`Params`（重みの組）・`Setup`（始める決め）・`Body`（やりとりの中身）・`Tally`（集計）・`Event`（起きたこと 1 つ）・`DbHandle`（DB の繋ぎと★開けない理由） |

★★**器に判定を入れない**——★**入れると、同じ判定が二か所に出る**。
★**`Moves` が「数えたかどうか」を持つのは、★「0 か所」と「まだ数えていない」を同じ顔にしないため**（[[DD-L1-othello]] §2）。

## 4. 対局の進行 — `shared/src/main/kotlin/othello/OthelloGame.kt`

**状態を受け取り、新しい状態を返す。**書き換えない。だから待ったは、前の状態をそのまま使うだけで済む。

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play(state: State, move: String) -> Played` | 状態、升 | 受理したかと、新しい状態か理由 |
| `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn(state: State) -> Played` | 状態 | 受理したかと、新しい状態か理由 |
| `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState(state: State) -> Before` | 状態 | 履歴に積む「置く前の状態」。★**履歴そのものは入れない** |


★戻り値は**受理したかどうかと理由**。置けないことを例外で伝えない。

### 4.2 `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` の処理手順

1. `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips(board: List<String>, move: String, turn: String) -> List<String>` を呼ぶ
2. 返った一覧が空なら、**状態に触らずに**受理しないで理由を返す
3. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove(board: List<String>, move: String, turn: String) -> List<String>` を呼ぶ
4. `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState(state: State) -> Before` を呼び、「置いた升・裏返った升・置く前の状態」を履歴に積む
5. 盤・手番・手数を進め、**連続パスを 0 に戻す**
6. 新しい状態を返す

★5 の後半を落とさない。落とすと、**盤が動いているのに次の 1 回のパスで終局する**。

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play`
- 入口の語: `state`, `move`
- もし `裏返る升が無い` なら「受理しない」
- それ以外は「受理した」
- 出口「受理しない」は `['ok']:False` で認める
- 出口「受理した」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, move="d3"` のとき 特徴 `裏返る升が無い=False`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, move="a1"` のとき 特徴 `裏返る升が無い=True`
- 出口「受理した」は `['ok']:True` で認める
- 出口「受理しない」は `['reason']:contains:裏返` で認める

### 4.3 `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState` の処理手順

1. 盤・手番・手数・連続パスを、新しい器に写して返す

★**履歴を入れない。**入れると、履歴の中に履歴が入り、深さが手数ぶん増えていく。
★**この形を 2 か所に書かない。**進めるときとパスするときの両方で積むので、
片方だけ欄が増えたときに、**戻したあとの状態が食い違う**。

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState`
- 入口の語: `state`
- もし `白の番` なら「白の置く前」
- それ以外は「置く前の状態」
- 出口「白の置く前」は `['turn']:W` で認める
- 出口「置く前の状態」は `['turn']:B` で認める

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}` のとき 特徴 `白の番=False`
- 入力 `state={"board": ["........", "........", "...B....", "...BB...", "...BW...", "........", "........", "........"], "turn": "W", "moves": 1, "history": [], "passes": 0}` のとき 特徴 `白の番=True`
- 出口「白の置く前」は `['turn']:W` で認める
- 出口「置く前の状態」は `['turn']:B` で認める

### 4.4 `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` の処理手順

1. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を呼ぶ
2. 置ける升が 1 つでもあれば、受理しないで理由を返す
3. 連続パスと手数に 1 を足し、`shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:beforeState(state: State) -> Before` で写した状態を履歴に積み、手番を移す
4. 連続パスが 2 なら、終局の印を立てる
5. 新しい状態を返す

★1 を省いて、画面が「押せた」ことを根拠にしない。**押された瞬間に、もう一度数える。**

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn`
- 入口の語: `state`
- もし `置ける升がある` なら「受理しない」
- それ以外は「受理した」
- 出口「受理しない」は `['ok']:False` で認める
- 出口「受理した」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}` のとき 特徴 `置ける升がある=True`
- 入力 `state={"board": ["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], "turn": "B", "moves": 0, "history": [], "passes": 0}` のとき 特徴 `置ける升がある=False`
- 出口「受理しない」は `['reason']:contains:置ける` で認める
- 出口「受理した」は `['ok']:True` で認める

---

## 5. 待った — `shared/src/main/kotlin/othello/OthelloUndo.kt`

**戻すことだけを受け持つ。**★**戻す先は「1 手前」ではなく、「人が打つ番」である**（[[DD-L1-othello]] §6.6）。

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo(state: State, setup: Setup) -> Played` | 状態、対局の設定 | 受理したかと、★**人が打つ番まで戻した**状態か理由 |

★**進行から切り出した。**進行に置いたままだと 3 関数になり、次に 1 つ足した瞬間に詰まる。
**戻す話は、進める話と別である。**

### 5.2 `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo` の処理手順

1. 履歴が空なら、受理しないで理由を返す
2. 履歴の末尾から、**置く前の状態をそのまま取り出す**
3. `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn(setup: Setup, turn: String) -> Boolean` を呼び、計算機の番である間、さらに 1 つ前を取り出す。履歴が尽きたら対局の頭の状態
4. その状態を返す

★**戻し忘れが起きない形にした。**状態を丸ごと積んであるので、盤だけ戻して数字を戻し忘れる、が起こらない。

★**3 が要る理由。**人と計算機の対局で 1 手だけ戻すと、戻った先は計算機の番である。**すぐ計算機が打ち直し、同じ盤に戻る**——押しても何も変わらないように見える。だから、**人が打つ番に着くまで戻す**。ここで対局の設定が要るのは、**どちらが人かを知っているのが設定だけ**だからである。

#### `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo`
- 入口の語: `state`, `setup`
- もし `履歴が空` なら「受理しない」
- それ以外は「受理した」
- 出口「受理しない」は `['ok']:False` で認める
- 出口「受理した」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}` のとき 特徴 `履歴が空=True`
- 入力 `state={"board": ["........", "........", "...B....", "...BB...", "...BW...", "........", "........", "........"], "turn": "W", "moves": 1, "history": [{"square": "d3", "flipped": ["d4"], "before": {"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "passes": 0}}], "passes": 0}, setup={"black": "human", "white": "human", "level": None, "params": None}` のとき 特徴 `履歴が空=False`
- 入力 `state={"board": ["........", "........", "..WB....", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 2, "history": [{"square": "d3", "flipped": ["d4"], "before": {"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "passes": 0}}, {"square": "c3", "flipped": ["d4"], "before": {"board": ["........", "........", "...B....", "...BB...", "...BW...", "........", "........", "........"], "turn": "W", "moves": 1, "passes": 0}}], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}` のとき 特徴 `履歴が空=False`
- 出口「受理しない」は `['reason']:contains:戻せ` で認める
- 出口「受理した」は `['ok']:True` で認める

---

## 6. 表示の組み立て — `shared/src/main/kotlin/othello/OthelloView.kt`

画面が描くのに要るものを、1 かたまりにして渡す。描画はしない。

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable(state: State, moves: Moves) -> Pressable` | 状態、置ける升の器 | 升・パス・待った、それぞれ押せるか |
| `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView(state: State, setup: Setup) -> View` | 状態、対局の設定 | 画面が描くのに要るもの一式。★**画面はこれ 1 つで足りる** |

### 6.2 `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable` の処理手順

1. 升は、置ける升の一覧をそのまま押せるものとする
2. パスは、置ける升が 0 のときだけ押せるものとする
3. 待ったは、履歴があるときだけ押せるものとする
4. 3 つを器に入れて返す

#### `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable`
- 入口の語: `state`, `moves`
- もし `置ける升が無い` なら「パスだけ押せる」
- それ以外は「升が押せる」
- 出口「パスだけ押せる」は `['can_pass']:True` で認める
- 出口「升が押せる」は `['squares']:contains:d3` で認める

#### `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, moves={"moves": ["d3", "c4", "f5", "e6"], "counted": True}` のとき 特徴 `置ける升が無い=False`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, moves={"moves": [], "counted": True}` のとき 特徴 `置ける升が無い=True`
- 出口「升が押せる」は `['squares']:contains:d3` で認める
- 出口「パスだけ押せる」は `['can_pass']:True` で認める

★**名前は判定に使わない。**★**そのまま持ち回るだけ**——受け取って、対局の設定に載せる（CR-9 の 9-2）。
★**空でも断らない**（任意だから。空なら DB の側で日時が入る）。

### 6.3 `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView` の処理手順

1. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を呼ぶ
2. `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones(board: List<String>) -> Stones` を呼ぶ
3. `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:lastMoveInfo(history: List<Entry>) -> LastMove?` を呼ぶ
4. `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:pressable(state: State, moves: Moves) -> Pressable` を呼ぶ
5. 設定から**いま何段目か**を取る。計算機が居ないなら**持たない**
6. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver(board: List<String>) -> Boolean` を呼び、終局していれば**終局の文言**を入れる。していなければ空
6b. ★**今回裏返った升の並び**を、履歴の末尾から取る。履歴が空なら**空の並び**
6c. ★**次も計算機の番か**を、`shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn(setup: Setup, turn: String) -> Boolean` で見て入れる（★**再生中は偽**——★**画面が「計算機の 1 手」を送り始める**。CR-10）
6d. ★**再生の続きが在るか**を入れる（状態の**再生の並びが空でない**なら真。CR-10）
6e. ★**再生中は、押せる升を空にする**——★**打てない**（CR-10 の 10-3）。★**パスと待ったも押せない**（★**戻せない**。10-2）
7. 以上を**新しい器**にまとめて返す

★★**「打てない」を画面に任せない。**画面が押せる升を無視するだけだと、
★**次の画面が来たときに、また押せるように見える**——**押せないことは、渡すものの側で決める**。

★**5 と 6 が要る。**[[DD-L2-othello]] §3.4 は、画面が受け取るものに「いま何段目か」と「出す文言」を挙げている。ここで入れないと、**画面が設定や状態をもう一度引くことになり、一式で渡す意味が無くなる**。

★5 が要点。前に渡した器を書き換えて使い回さない。**画面がまだ描いている途中の値を書き換えることになる。**

#### `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView`
- 入口の語: `state`, `setup`
- もし `盤に石が無い` なら「置ける升が無い」
- それ以外は「一式」
- 出口「置ける升が無い」は `['hints']:[]` で認める
- 出口「一式」は `['hints']:contains:d3` で認める

★**一式は、今回裏返った升の並びと、次も計算機の番かを持つ**（CR-6）。

#### `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView` の試験材料

- 入力 `state={"board": ["........", "........", "........", "........", "........", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "blackLevel": 3, "whiteLevel": 3, "root": "runs", "name": ""}` のとき 特徴 `盤に石が無い=True`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "blackLevel": 3, "whiteLevel": 3, "root": "runs", "name": ""}` のとき 特徴 `盤に石が無い=False`
- 出口「置ける升が無い」は `['hints']:[]` で認める
- 出口「一式」は `['hints']:contains:d3` で認める
- 出口「一式」は `['flipped']:[]` で認める
- 出口「一式」は `['picked']:True` で認める
- 出口「一式」は `['pickedGames']:0` で認める
- 出口「一式」は `['trend']:is_none` で認める

---

## 7. 対局の設定 — `shared/src/main/kotlin/othello/OthelloSetup.kt`

黒白それぞれの打ち手・先手後手・強さの段を持つ。**盤も進行も知らない。**

### 7.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup(black: String, white: String, blackLevel: Int, whiteLevel: Int, root: String, name: String) -> Setup` | 黒の打ち手、白の打ち手、★**黒の段**、★**白の段**、記録の置き場 | 対局の設定。★**パラメータの組を含む**。受け付けられないときは空の器 |
| `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn(setup: Setup, turn: String) -> Boolean` | 設定、手番 | いまの手番が計算機かどうか |

★★**先手後手は、[[DD-L1-othello]] §5.4 のとおり「選ぶもの」である**（owner 裁定 2026-08-12・
**上の層が正当**）。ここには一度「別に持たない」と書いたが、★**上の決めを下から書き換えていた**。

| 何を | どうするか |
|:---|:---|
| 画面 | ★**先手後手として見せる**（黒が先手・白が後手であることを、利用者に分かる形で） |
| 持ち方 | ★**欄を増やさない。**黒が先手と決まっているので、黒白の打ち手がそのまま先手後手を表す |
| なぜ欄を増やさないか | 増やすと、**黒＝計算機なのに「人が先手」**という、在り得ない組み合わせが持てる |

★**「選ばせる」と「別の欄を持つ」は違う。**上の層が求めているのは**利用者から見える選択**であって、
**内側の欄の数**ではない。★**下の都合（二重に持たない）で、上の決め（選ばせる）を消さない。**

### 7.2 `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup` の処理手順

1. 黒と白の打ち手が、どちらも「人」か「計算機」のいずれかかを見る。違えば空の器を返す
2. どちらかが計算機なら、段が 1 から 6 の中かを見る。外なら空の器を返す
3. どちらも人なら、段もパラメータも持たない
4. 段が在るなら `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams(level: Int, root: String) -> Params?` を呼び、返ったパラメータの組を設定に入れる
5. 設定を器に入れて返す

★**段からパラメータを引くのは、ここ 1 回だけである**（[[DD-L2-othello-ai]] §1.2）。1 手ごとに引くと、**対局の途中でパラメータが変わり得る**——段 5 は記録から選ぶので、対局中に記録が増えれば別の組が返る。**同じ盤面に同じ手**が、そこで崩れる。

★★**段は側ごとに受け取り、組も側ごとに引く**（CR-12）。**片方が人なら、その側の段と組は持たない。**

★**引くのは対局の頭で 1 回だけ。**打つたびに引き直すと、**段 5 が記録を読み直して、対局の途中で強さが変わる**。

#### `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup`
- 入口の語: `black`, `white`, `blackLevel`, `whiteLevel`, `root`, `name`
- もし `打ち手の語が違う` なら「受け付けない」
- もし `段が範囲の外` なら「受け付けない」
- それ以外は「対局の設定」
- 出口「受け付けない」は `{}` で認める
- 出口「対局の設定」は `['black']:human` で認める

#### `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup` の試験材料

- 入力 `black="human", white="machine", blackLevel=3, whiteLevel=3, root="runs", name=""` のとき 特徴 `打ち手の語が違う=False, 段が範囲の外=False`
- 入力 `black="human", white="machine", blackLevel=3, whiteLevel=9, root="runs", name=""` のとき 特徴 `段が範囲の外=True`
- 入力 `black="dog", white="human", blackLevel=3, whiteLevel=3, root="runs", name=""` のとき 特徴 `打ち手の語が違う=True`
- 出口「対局の設定」は `['black']:human` で認める
- 出口「受け付けない」は `{}` で認める

### 7.3 `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn` の処理手順

1. 手番が黒なら、黒の打ち手を見る
2. 手番が白なら、白の打ち手を見る
3. それが「計算機」なら真、そうでなければ偽を返す

#### `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn`
- 入口の語: `setup`, `turn`
- もし `その手番が計算機` なら「計算機の番」
- それ以外は「人の番」
- 出口「計算機の番」は `True` で認める
- 出口「人の番」は `False` で認める

#### `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn` の試験材料

- 入力 `setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, turn="W"` のとき 特徴 `その手番が計算機=True`
- 入力 `setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, turn="B"` のとき 特徴 `その手番が計算機=False`
- 出口「計算機の番」は `True` で認める
- 出口「人の番」は `False` で認める

---

## 8. 計算機の番 — `shared/src/main/kotlin/othello/OthelloTurn.kt`

計算機の番なら、打ち手に聞いて 1 手進める。★**どう選ぶかは持たない。**

### 8.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep(state: State, setup: Setup) -> Stepped` | 対局の状態、対局の設定 | 進めたかと、新しい状態か理由 |

★**この関数の名前と形は、この設計書が決める。**呼ぶ側（画面や進行）は、これをそのまま使う。
一方、**打ち手の呼び方は [[DD-L4-othello-ai]] が決めたもの**をそのまま使う。
★**呼ばれる側が名前を決める**、が両方向で守られている。

### 8.2 `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` の処理手順

1. `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:isMachineTurn(setup: Setup, turn: String) -> Boolean` を呼ぶ
2. 人の番なら、**何もせずに**進めなかったと返す
3. 設定から**パラメータの組**を取り出す
4. それを渡して `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove(board: List<String>, turn: String, params: Params?) -> Chosen` を呼ぶ
5. 手が無いと返ってきたら `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn(state: State) -> Played` を呼ぶ
6. 手が返ってきたら `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play(state: State, move: String) -> Played` を呼ぶ
7. 返った新しい状態を、そのまま返す

★**ここでは段を見ない。**パラメータの組は、対局の頭で設定に入っている。打ち手に段を渡すと、**打ち手の中に段ごとの分岐が生まれる**（[[DD-L1-othello-ai]] §2.2 で、それをやらないと決めた）。

★**5 が、人のときと決めが違うところである。**人にはパスを押させるが、計算機には押させる相手がいない。
ただし**パスしたことは画面に出す**（[[DD-L1-othello]] §6.5）。

★**この関数は盤を読まない。**置ける升の判定も、裏返しも、全部よそが持っている。

★★**打つ側の組を使う**（CR-12）。**手番が黒なら黒の組、白なら白の組**——★**間違えると、相手の強さで打つ**。

#### `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep`
- 入口の語: `state`, `setup`
- もし `人の番` なら「進めない」
- もし `打ち手に手が無い` なら「パスした」
- それ以外は「1 手進めた」
- 出口「進めない」は `['ok']:False` で認める
- 出口「パスした」は `['passed']:True` で認める
- 出口「1 手進めた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}` のとき 特徴 `人の番=True`
- 入力 `state={"board": ["........", "........", "...B....", "...BB...", "...BW...", "........", "........", "........"], "turn": "W", "moves": 1, "history": [{"square": "d3", "flipped": ["d4"], "before": {"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "passes": 0}}], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}` のとき 特徴 `人の番=False, 打ち手に手が無い=False`
- 入力 `state={"board": ["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], "turn": "W", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}` のとき 特徴 `人の番=False, 打ち手に手が無い=True`
- 出口「進めない」は `['ok']:False` で認める
- 出口「パスした」は `['passed']:True` で認める
- 出口「1 手進めた」は `['ok']:True` で認める

---

## 8a. 記録の置き場 — `shared/src/main/kotlin/othello/OthelloPlace.kt`

置き場を決める。★**探さない。書けるかを尋ねない**（[[DD-L2-othello]] §7z.2c）。

### 8a.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot(app: String, given: String, provided: String) -> String` | アプリの名前、外から指定された場所（無ければ空）、環境が用意した置き場（無ければ空） | 記録の置き場。★**どちらも無ければ空** |

★**環境の値を、この関数の中で読まない。**環境が用意した置き場は**引数で受け取る**。
中で読むと、環境ごとに読み方が分かれ、**同じコードが両方で動く**という決め（§7z.2d）が崩れる。

### 8a.2 `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot` の処理手順

1. 外から指定された場所が空でなければ、**それを返す**（試験と開発のため）
2. 環境が用意した置き場が空なら、**空を返す**
3. 環境が用意した置き場の下に、アプリの名前をつないだ場所を返す

★**3 で作らない。**作るのは書く側である。ここは**場所を決めるだけ**。
決めることと作ることを 1 つの関数に入れると、**場所を知りたいだけの呼び手が、作ってしまう**。

★**2 で空を返すのが要点である。**無いものを、在るふりをして返さない。
空が返れば、呼んだ側は**記録を残さないと決めて進める**（[[DD-L1-othello]] §4b）。

#### `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot`
- 入口の語: `app`, `given`, `provided`
- もし `外からの指定がある` なら「指定された場所」
- もし `環境の置き場が無い` なら「場所なし」
- それ以外は「環境の下の場所」
- 出口「指定された場所」は `runs` で認める
- 出口「場所なし」は `''` で認める
- 出口「環境の下の場所」は `contains:othello` で認める

#### `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot` の試験材料

- 入力 `app="othello", given='runs', provided=""` のとき 特徴 `外からの指定がある=True`
- 入力 `app="othello", given='', provided=""` のとき 特徴 `外からの指定がある=False, 環境の置き場が無い=True`
- 入力 `app="othello", given='', provided="/data/user/0/app/files"` のとき 特徴 `外からの指定がある=False, 環境の置き場が無い=False`
- 出口「指定された場所」は `runs` で認める
- 出口「場所なし」は `''` で認める
- 出口「環境の下の場所」は `contains:othello` で認める

#### `shared/src/main/kotlin/othello/OthelloPlace.kt:OthelloPlace:logRoot` の呼ぶIF

★**他の設計書を呼ばない。**環境を読まず、渡された値をつなぐだけである。

## 9z. 呼ぶIF（要求インタフェース）

記法の出どころは**開発環境側の設計書** `DD-L4-integration-contract` §4 である（このアプリの設計書ではないので、二重角括弧で結ばない）。

> 本節はインタフェース表（＝**呼ばれるIF**）の**対**である。契約は相手の設計書の表に既に書かれているので、
> **二重に持たない**——宣言するのは**辺だけ**である。契約も、呼ぶ順序も、ここには書かない。

★**同じ設計書の中の呼び出しは、ここに書かない。**相手の表が同じ本の中に在るので、辺を宣言する相手がいない。
書くのは**設計書をまたぐ依存**だけである。

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup` の呼ぶIF

- [[DD-L4-othello-ai]] `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` の呼ぶIF

- [[DD-L4-othello-ai]] `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ
## 9. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| 置ける升が無いとき、勝手に手番を進めない | `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` が押されるまで進まない。`pressable` が `can_pass` を立てる |
| 置けない升は理由を返す | `play` の出口「受理しない」が理由を持つ |
| 状態を書き換えない | `play` などが**新しい状態を返す**。待ったは前の状態をそのまま使う |
| ★記録は対局に 1 本 | `play` ・ `passTurn` ・ `undo` が★**記録の手を引き継ぐ**（[[DD-L3-othello]] §3.5） |
| 連続パスは盤が動いたら 0 | `play` の手順 5 |
| 対局開始直後に 0 を出さない | `lastMoveInfo` が★**「無し」を返す**（空の器ではない） |
| 打ち手の中身をここに書かない | `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` は `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` を呼ぶだけ |
| 名前は呼ばれる側が決める | `shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep` の形はここが決め、`shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` の形は向こうが決めた |
| 先手後手を二重に持たない | `shared/src/main/kotlin/othello/OthelloSetup.kt:OthelloSetup:newSetup` は黒白の打ち手だけを持つ |
