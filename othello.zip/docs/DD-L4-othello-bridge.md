# DD-L4 関数仕様 — 境の窓口と画面

- doc_id : DD-L4-othello-bridge ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **境の窓口と画面**について、関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料を定める。
- 出典 : DD-L3-othello §2（受け皿のうち窓口と画面）・§7.1b（境を越えるまで）・DD-L2-othello §7z（実行の形）
- 呼ぶ相手 : [[DD-L4-othello-play]]（進行・待った・状態・表示の組み立て）・[[DD-L4-othello-log]]（記録）

---

## 1. ファイルの分け方

★**[[DD-L4-othello-play]] から切り出した。**800 行の上限に張り付いたためであり、
**切る場所は「境」にした**——窓口と画面は、共通の内側とは**別の理由で変わる**（環境が増えたとき）。

| ファイル | 関数の数 | 行の目安 | 分岐の深さ | 何を持つか |
|:---|---:|---:|---:|:---|
| `shared/src/main/kotlin/othello/OthelloBridge.kt` | 3 | 約 85 | 2 | 境の窓口。出来事を受け、一式を返す。記録を開き・書き・閉じる |
| ★**`shared/src/main/kotlin/othello/OthelloBridgeEvent.kt`** | 4 | 約 80 | 2 | ★**出来事ごとの枝**。どう状態が変わるかだけを持つ |
| ★**`shared/src/main/kotlin/othello/OthelloBridgeAfter.kt`** | 3 | 約 70 | 2 | ★**後始末**。形勢の伸ばし切り詰め・閉じたときの永続化と控え・結果の文言 |
| `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt` | — | 約 120 | — | 盤と升を描く |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt` | — | 約 90 | — | わきの補助情報とボタンを描く |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt` | — | 約 80 | — | 対局を始める前の設定の窓。強さはポップアップ |
| ★**`ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt`** | — | 約 70 | — | ★**対局を選ぶ窓**（新しい順の一覧。時刻と名前で見分ける） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt` | — | 約 60 | — | 3 つを並べ、触られたことを渡す |
| ★**`shared/src/main/kotlin/othello/OthelloHelp.kt`** | 2 | 約 70 | 1 | ★**ヘルプの本文**（節の並び）。F-12・RF-64 |
| ★**`ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt`** | — | 約 60 | — | ★**ヘルプの画面**。受け取った節を並べるだけ |

★★**`shared/src/main/kotlin/othello/OthelloHelp.kt` はプログラムではない。**中身は**決めた文言**であって手続きではないので、
★**登録の型は `Document`**（`--type Code` にしない・owner 指示 2026-08-15）。

## 2. クラスとメソッド

| クラス | ファイル | 親 | メソッド |
|:---|:---|:---|:---|
| `OthelloBridge` | `shared/src/main/kotlin/othello/OthelloBridge.kt` | 無し（object） | `handle` ・ `opened` ・ `recordMove` |
| ★**`OthelloBridgeEvent`** | `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt` | 無し（object） | `apply` ・ `replayOf` ・ `nextOf` ・ `helpOf` |
| ★**`OthelloBridgeAfter`** | `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt` | 無し（object） | `drawn` ・ `closed` ・ `told` |
| ★**`OthelloHelp`** | `shared/src/main/kotlin/othello/OthelloHelp.kt` | 無し（object） | `sections` ・ `sectionAt` |

★★**`handle` の枝を、関数として外へ出した**（2026-08-15・[[DD-L3-othello]] §2）。
`handle` の複雑度が **37**（規約は 20 まで）になったためである。
★**切れ目は、まずコード単位。それで足りなければ関数単位**（owner 指示 2026-08-15）——
★**ここは 1 つの関数が超えていた**ので、★**ファイルを割っても複雑度は 1 も下がらない**。∴ 関数単位で割る。

| 出した関数 | 何を持つか |
|:---|:---|
| `apply` | ★**出来事 1 つを、進行への呼び分けに直す**（升・パス・待った・計算機・始める） |
| `replayOf` | ★**再生を始める**——手の並びを取り、対局の頭の状態に持たせる |
| `nextOf` | ★**再生の次の 1 手**——並びの先頭を置き、並びから外す。★打ち手を呼ばない |
| `helpOf` | ★**ヘルプの印を立てる／下ろす**だけ。盤にも進行にも触らない |

★**判定は増えない。**枝を外へ出しても、★**判断の置き場は 1 つのまま**である（[[DD-L2-othello]] §3.5）。

★★**1 度割っても足りなかった**（実測 2026-08-15）。枝を出して **37 → 31** まで下がったが、規約（20）に届かない。
★**残っていたのは「枝」ではなく「後始末」**である——★**出来事の種類で分かれる部分は出したが、
どの出来事のあとでも走る部分が残っていた。**∴ もう一段、関数単位で割る。

| 出した関数 | 何を持つか |
|:---|:---|
| `drawn` | ★**形勢の並びを伸ばす／切り詰める**（CR-8）。待ったなら手数に合わせて切る |
| `closed` | ★**記録を閉じたなら、DB を終わらせて永続化し、控えを取る**（CR-9） |
| `told` | ★**一覧・取り込み・書き出しの結果を、一式の文言に載せる**（BUG-48 の場所） |

★★**「割った」ことと「収まった」ことは別である。**★**割ったら必ず撃って、数で確かめる**——
1 度目は割ったのに超えたままだった。

★**画面の 5 本はクラスを持たない。**描く関数を並べるだけであり、
状態も判定も持たない（[[DD-L2-othello]] §7z.2b）。★**`ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt` も同じ**——
★**関数の数を `—` と書くのは、「無い」ことをそう書く形である**（空欄にしない）。

---

## 3. 境の窓口 — `shared/src/main/kotlin/othello/OthelloBridge.kt`

出来事を 1 つ受け取り、一式を 1 つ返す（[[DD-L2-othello]] §7z）。★**判定を持たない。画面を知らない。**

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle(state: State, setup: Setup, event: Command, root: String) -> Handled` | いまの状態、対局の設定、出来事 1 つ、★**記録を置くところ** | ★**新しい状態と一式**を持つ器 |
| `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened(setup: Setup, root: String) -> State` | 対局の設定、★**記録を置くところ** | 新しい対局の状態。★**置き場が在れば、記録の手を持つ** |
| `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove(state: State, log: LogHandle, setup: Setup, frm: Int) -> State` | いまの状態、記録の在り処、対局の設定、★**この出来事の前の手数** | 記録を書いたあとの状態。★**閉じたら手を離した状態** |

★**窓口が受ける出来事は 10 個**（升・パス・待った・対局を始める・★**計算機の 1 手**・★**再生を始める**・★**再生の次の 1 手**・★**対局の一覧**・★**取り込み**・★**DB を書き出す**）。それ以外は受け付けない。

★★**一覧と取り込みも、窓口が受ける。**——★**画面が DB を直に呼ぶと、画面が DB を知ることになる**（[[DD-L3-othello-db]] §2）。
★**再生を始めるのが既に窓口を通っている**ので、**同じ道に揃える**。
★**この 2 つは盤を変えない。**変えないが、★**一式は返す**（一覧を載せ、取り込んだ本数を文言に出すため）。

★**「新しい対局」は窓口に来ない。**あれは選び直しの窓へ戻ることであり、**口が受ける**（[[DD-L2-othello]] §7z.2b1）。

★**なぜ窓口を 1 つにするのか。**画面から共通へ入る道が複数あると、
**入る道ごとに、進行の呼び方が写される**。写しが増えれば、片方だけ直る事故が起きる。
道を 1 本にすれば、進行をどう呼ぶかは**この関数だけが知っていればよい**。

★**なぜ状態を引数で受け取るのか。**窓口が状態を抱え込むと、
**窓口が状態の持ち主になる**。持ち主が 2 人（画面と窓口）になった時点で、
どちらが本物かを決める話が始まる。★**渡されたものを使い、新しいものを返す**——
進行がそうしているのと同じ形にする。

★**受理されなかったときも、一式を返す。**断ったことは断ったこととして返るが、
画面が描くのに要るものは変わらず要る。ここで何も返さないと、
**画面は前の一式を持ったまま**になり、盤と理由の表示がずれる。

### 3.2 `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle` の処理手順

1. 出来事の種類が決めた語のいずれかかを見る。違えば、状態を変えずに理由を返す
2. 升なら `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play(state: State, move: String) -> Played` を呼ぶ
3. パスなら `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn(state: State) -> Played` を呼ぶ
4. 待ったなら `shared/src/main/kotlin/othello/OthelloUndo.kt:OthelloUndo:undo(state: State, setup: Setup) -> Played` を呼ぶ
5. 対局を始めるなら `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened(setup: Setup, root: String) -> State` を呼ぶ
5b. ★**計算機の 1 手なら、状態を変えずに次へ進む**（手順 7 が 1 手だけ進める）
6. 受理されなければ、**状態を変えずに**理由を返す
7. ★**手番が計算機なら、`shared/src/main/kotlin/othello/OthelloTurn.kt:OthelloTurn:machineStep(state: State, setup: Setup) -> Stepped` を 1 回だけ呼ぶ**（CR-6。続けて進めない）
7b. ★★**ただし再生中は呼ばない**（CR-10 の 10-3）——★**手は記録に在る。打ち手が要らない**
8. `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView(state: State, setup: Setup) -> View` を呼ぶ
5d. ★**再生を始めるなら、`shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves(db: DbHandle, gameId: Int) -> List<String>` で手の並びを取り、対局の頭の状態に持たせる**（CR-10）
5e. ★**再生の次の 1 手なら、並びの先頭を 1 つ置き、並びから外す**。★**打ち手を呼ばない**（手は記録に在る）
5f. ★**対局の一覧なら、`shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames(db: DbHandle, limit: Int) -> List<GameHead>` を呼び、一式に載せる**（★**新しいほうから 50 本まで**）。★**盤は変えない**。★**1 本も無ければ、その旨を文言に出す**
5g. ★**取り込みなら、`shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder(db: DbHandle, root: String) -> Int` を呼び、★**入った本数を一式の文言に入れる**。★**盤は変えない**
5h. ★**DB を書き出すなら、`shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump(db: DbHandle, root: String) -> String` を呼び、★**在り処と行数を一式の文言に入れる**。★**盤は変えない**
5i. ★**ヘルプなら、開いている印を立てるだけ**（F-12・RF-64）。★**盤にも進行にも触らない**
5j. ★**ヘルプを閉じるなら、印を下ろすだけ**。★★**戻す作業を持たない**——★**触っていないので、戻すものが無い**（[[DD-L3-othello]] §7.4）

★★**「文言」は一式の欄である。**拒否の理由（器が持つ）とは**別の場所**——
★**理由は画面に出ていない**ので、そこへ入れると★**押しても何も出ない**。
★**実測 2026-08-13**: 取り込みを押しても何も出なかった（BUG-48）。★**試験も理由のほうを見ていたので通っていた。**
8a. ★**受理されたなら、`shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended(now: Trend, board: List<String>, machine: Boolean) -> Trend` で形勢の並びを 1 つ伸ばす**（CR-8）
8a2. ★**待ったなら、`shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed(now: Trend, moves: Int) -> Trend` で手数に合わせて切り詰める**
8b. ★**記録の手が在り、受理されていれば、`shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove(state: State, log: LogHandle, setup: Setup, frm: Int) -> State` を呼ぶ**（`frm` は**この出来事の前の手数**）
8c. ★**記録を閉じたなら、`shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame(db: DbHandle, gameId: Int, result: Result) -> Written` を呼ぶ**（★**ここで永続化される**）
8d. ★**続けて `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb(db: DbHandle, root: String, keep: Int) -> Int` を呼ぶ**（★**3 代前まで残す**）
9. 新しい状態と一式を、器に入れて返す

★★**「打ち手を呼ばない」は、再生の 1 手の枝だけでは足りない。**
★**手順 7 は、どの出来事のあとでも走る**——★**再生の手を置いた直後にも走り、計算機が続けて打ち始める**。
∴ **再生中かどうかで、手順 7 そのものを止める。**

★**実測 2026-08-13**: 再生したところ★**手数が 98 まで伸び、グラフが止まらなかった**（BUG-47。手は 60 手が上限）。
★**並びを使い切ったあとも、計算機が打ち続けていた。**

★★**再生は、対局と同じ道を通る**（[[DD-L2-othello]] §7z.2b5）。**違うのは 3 つだけ**——★**打ち手を呼ばない**・★**記録を残さない**・★**押しても進まない**（間を置いて画面が送る）。
★**再生中は記録を開かない。**再生は対局ではないので、**残すものが無い**（CR-10 の 10-5）。

★★**DB へは、対局の頭・1 手ごと・終わりの 3 回に分けて書く**（[[DD-L3-othello-db]] §4.1）。★**丸ごと入れる `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` は、取り込みのときだけ使う。**

★**窓口は `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` を直に呼ばない。**★**置き場ごと入れる `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` を呼ぶ**——
**1 本ずつ選ばせない**（利用者は「置き場に在るものを入れたい」のであって、**どれを入れるかを決めたいのではない**）。

★**対局の番号は、状態が持つ。**対局の頭で受け取り、終わるまで持ち回る。

★★**DB へ入れるのは、閉じたときだけである**（CR-9）。**途中の対局は入れない**——**閉じるまでは、まだ記録ではない**（[[DD-L4-othello-log]] §8）。
★**ファイルは変えない。**DB は**探すための索引**であって、**記録そのものはファイル**である。

★★**形勢の並びは、ここで足し、ここで切り詰める**（[[DD-L3-othello-graph]] §5.2）。**2 か所に分けない**——片方だけ直す事故が起きる。
★**対局を始めるときに、0 手目の分を 1 つ入れる**（入れないと線が 1 手目から始まる）。

★★**5c は「対局を始める」の枝の中だけである。**枝の外に置くと、★**出来事が来るたびに記録が 1 本ずつできる**（実測 2026-08-12・BUG-29。29 本のうち 27 本が、開いただけの空の記録だった）。
★**書く先が「開いた」という事実は、開いてしまってからでは取り消せない。**

★★**5c・8b が要る。**書く関数は 3 つとも在り、その試験も通っていたのに、★**呼ぶ者を決めていなかったので、記録は 1 本も残らなかった**（実測 2026-08-12・BUG-25）。★**7 と同じ形の欠陥である。**

★**記録の手は状態が持つ**（[[DD-L3-othello]] §3.5）。窓口が抱えると、窓口が状態の持ち主になる——**この節が既に断っていること**である。

★**置き場が空なら、開かない。**書けないことは対局を止めない（[[DD-L1-othello]] §4b）。★**試験は空を渡す**ので、ファイルは 1 つも作られない。

★**7 が要る。**これを書いていなかったので、**計算機が 1 手も打たなかった**
（実測 2026-08-12: 相手を計算機にしたのに、人間どうしの対局になった）。
★**関数は在ったが、呼ぶ者が決まっていなかった。**

★★**7 は 1 回だけである**（CR-6）。続けて終局まで回すと、**一瞬で終わって、何も見えない**
（実測 2026-08-12: 計算機どうしで、始めた瞬間に終局していた）。
∴ **次も計算機の番なら、一式にそう書いて返す**——**間を置いて次を送るのは画面**である
（[[DD-L2-othello]] §7z.2b）。

★**画面にやらせない。**画面に「計算機の番ならもう一度送る」と書くと、
**環境ごとにその処理が写される**（[[DD-L2-othello]] §3.3）。

★**7 を必ず通る。**受理されなかったときも一式を返す——**画面が古い一式を持ったままにならない**ようにするため。

★**1 の確かめを省かない。**出来事の種類は、画面から来る文字である。
画面が正しく作っている前提で受けると、**画面を直したときに、共通が黙って別の道を通る**。
決めた 7 つ以外は、その場で断る。断った理由も返すので、**画面の側で何が起きたかが分かる**。

★**2 から 5 は、どれも進行の側の関数をそのまま呼ぶだけである。**ここで条件を足さない。
足した瞬間、同じ判断が窓口と進行の 2 か所に生まれる。
たとえば「置けるかどうか」を窓口が先に見てしまうと、**進行の側の判断が使われない道**ができる。

★**6 で状態を変えない。**断るときは、渡された状態をそのまま返す。
新しい状態を作って返すと、**断ったのに何かが変わった**ことになり、
待ったで戻る先が 1 つずれる。

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle`
- 入口の語: `state`, `setup`, `event`, `root`
- もし `決めていない出来事` なら「受け付けない」
- もし `受理されない` なら「断る」
- それ以外は「進んだ」
- 出口「受け付けない」は `['ok']:False` で認める
- 出口「断る」は `['ok']:False` で認める
- 出口「進んだ」は `['ok']:True` で認める

★**人と計算機の対局では、1 回の出来事で 2 手進む**（人の 1 手と、計算機の応手）。

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "machine", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, event={"kind": "machine", "value": ""}, root=""` のとき 特徴 `決めていない出来事=False, 受理されない=False`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, event={"kind": "square", "value": "d3"}, root=""` のとき 特徴 `決めていない出来事=False, 受理されない=False`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, event={"kind": "dance", "value": ""}, root=""` のとき 特徴 `決めていない出来事=True`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, event={"kind": "pass", "value": ""}, root=""` のとき 特徴 `決めていない出来事=False, 受理されない=True`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0}, setup={"black": "human", "white": "machine", "level": 3, "params": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, event={"kind": "help", "value": ""}, root=""` のとき 特徴 `決めていない出来事=False, 受理されない=False`
- 出口「進んだ」は `['ok']:True` で認める

★**ヘルプは「決めた出来事」である**（F-12・RF-64）。★**決めた語に入れ忘れると、手順 1 で断られ、
押しても何も起きない**——★**画面の側をいくら見ても原因が分からない**形になる。

★**人と計算機の対局では、1 回の出来事で 2 手進む**（人の 1 手と、計算機の応手）。
- 出口「受け付けない」は `['reason']:contains:出来事` で認める
- 出口「断る」は `['ok']:False` で認める


### 3.3 `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened` の処理手順

1. `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState() -> State` で、新しい対局の状態を作る
2. 置き場が空なら、そのまま返す（★**記録は残らないが、対局は始まる**。[[DD-L1-othello]] §4b）
3. `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog(setup: Setup, root: String) -> LogHandle` を呼ぶ
3b. ★**`shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame(db: DbHandle, setup: Setup, path: String, name: String) -> Int` を呼び、対局の番号を受け取る**（[[DD-L3-othello-db]] §4.1 の 2）
3c. ★**名前は対局の設定が持っているものを渡す**（CR-9 の 9-2）。★**空なら、DB の側で日時が入る**
4. 記録の手と、対局の番号を持たせた状態を返す

★**3b を書き落としていた。**★**実装は呼んでいるのに、手順に無かった**——
★**照合の道具は「呼ぶIF」しか見ないので、手順の落ちは出ない**（実測 2026-08-13）。

★★**この関数を分けたのは、開く場所を 1 か所にするためである。**窓口の本体に直接書くと、
**出来事の種類を見る前に評価されてしまい、出来事のたびに記録が 1 本ずつできる**
（実測 2026-08-12・BUG-29。★**29 本のうち 27 本が、開いただけの空の記録だった**）。

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened`
- 入口の語: `setup`, `root`
- もし `置き場が空` なら「記録なしで始める」
- それ以外は「記録を開いて始める」
- 出口「記録なしで始める」は `['log']:is_none` で認める
- 出口「記録を開いて始める」は `['turn']:B` で認める

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

### 3.4 `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove` の処理手順

1. 履歴の `frm` 番目から末尾までを、★**1 つずつ**取り出す
2. それぞれについて、置いた升・裏返った数・**打った側の手番**を取り出し、計算機か人かを対局の設定から決める
3. 取り出した数だけ `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent(log: LogHandle, kind: String, body: Body) -> Written` を呼ぶ
3b. ★**同じ数だけ `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove(db: DbHandle, gameId: Int, seq: Int, body: Body) -> Written` を呼ぶ**（★**1 手ごと**。[[DD-L3-othello-db]] §4.1 の 3）——★**対局の番号を持っていなければ、呼ばない**。★**渡す `seq` は `frm + i + 1`**（`i` は 1 で始めた繰り返しの何番目か・0 から数える）——★**`seq` は「何手目か」であり（[[DD-L3-othello-db]] §3 の `seq`「記録の中の並び順・1 から数える」）、★繰り返しの中で 1 ずつ増える**

★★**実測2026-08-18（この定めの元になった欠陥）**: 本手順は「同じ数だけ呼ぶ」としか書いておらず、★**`seq` に何を渡すかを書いていなかった**。 ★実装は `frm + 1` を渡していた——★**繰り返しの中で変わらない値**である。 ∴

| 何 | どうなるか |
|:---|:---|
| ★1 回の出来事で 2 手進むとき | ★**両方の手が同じ番号で入る** |
| ★出来事をまたぐとき | ★番号が `1, 3, 6…` と**飛ぶ** |
| ★再生（`seq` の順に引く） | ★★**同じ番号どうしの順は保証されない** |

★★**BUG-30 は記録ファイルの側だけを直していた**——★**DB の番号は直っていなかった**。
★★**書いていないところは、必ず誰かが埋める。**★埋まるのは、その場でいちばん近くに在った変数である。
4. 終局していなければ、状態をそのまま返す
5. `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones(board: List<String>) -> Stones` で数え、勝者を決める
6. `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog(log: LogHandle, result: Result) -> Written` を呼ぶ
7. ★**記録の手を離した状態を返す**（閉じた記録に、あとから書き足さないため）

★★**1 回の出来事で、手が 2 つ進むことがある**（人の 1 手と、計算機の応手）。★**末尾だけを書くと、人の手が 1 手も残らない**——記録には計算機の手だけが並ぶ（実測 2026-08-12・BUG-30。5 手の対局で、人の手は 0 件だった）。

∴ **増えた分を、増えた順に全部書く。**「1 件」と決めていたことが誤りだった。

★**打った側は「いまの手番」ではない。**置いた直後は手番が相手へ移っているので、
**履歴に残した「置く前の手番」**を使う。ここを取り違えると、★**記録の中で黒と白が入れ替わる**。

★**引き分けは `-` で書く。**勝者の欄を空にすると、「書き落とし」と見分けが付かない。

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove`
- 入口の語: `state`, `log`, `setup`, `frm`
- もし `終局している` なら「閉じて手を離す」
- それ以外は「書き足す」
- 出口「閉じて手を離す」は `['log']:is_none` で認める
- 出口「書き足す」は `['turn']:B` で認める

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

---

## 3c. 出来事ごとの枝 — `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt`

★**どう状態が変わるかだけ**を持つ。★**一式は作らない。記録も DB も触らない**（それは §3d）。

### 3c.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:apply(state: State, setup: Setup, event: Command, root: String) -> Played` | いまの状態、対局の設定、出来事 1 つ、記録を置くところ | 受理できたかと、新しい状態か理由 |
| `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:replayOf(event: Command, root: String) -> Played` | 出来事（対局の番号を持つ）、記録を置くところ | ★**対局の頭の状態**に、手の並びを持たせたもの |
| `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:nextOf(state: State) -> Played` | いまの状態（手の並びを持つ） | 先頭を 1 つ置いた状態。★**並びが空なら断る** |
| `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:helpOf(state: State, event: Command) -> Played` | いまの状態、出来事 | ★**印だけ変えた状態**。盤も進行も変わらない |

### 3c.2 `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:apply` の処理手順

1. 出来事の種類で、呼ぶ先を決める
2. 升・パス・待った・計算機は、進行へ渡す
3. 再生を始める・次の 1 手・ヘルプは、この設計書の他の関数へ渡す
4. 一覧・取り込み・書き出しは、★**盤を変えずに受理する**
5. それ以外（対局を始める）は、記録を開いて新しい状態にする

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:apply` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:apply`
- 入口の語: `state`, `setup`, `event`, `root`
- もし `再生の続きが無い` なら「断る」
- それ以外は「呼び分けた」
- 出口「断る」は `['ok']:False` で認める
- 出口「呼び分けた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:apply` の試験材料

- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0, "replay": []}, setup={"black": "human", "white": "human", "blackLevel": 0, "whiteLevel": 0, "root": "", "name": ""}, event={"kind": "next", "value": ""}, root=""` のとき 特徴 `再生の続きが無い=True`
- 入力 `state={"board": ["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], "turn": "B", "moves": 0, "history": [], "passes": 0, "replay": []}, setup={"black": "human", "white": "human", "blackLevel": 0, "whiteLevel": 0, "root": "", "name": ""}, event={"kind": "games", "value": ""}, root=""` のとき 特徴 `再生の続きが無い=False`
- 出口「断る」は `['ok']:False` で認める
- 出口「呼び分けた」は `['ok']:True` で認める

### 3c.3 `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:replayOf` の処理手順

1. 出来事の値を対局の番号として読む。数でなければ 0 とする
2. その番号の手の並びを DB から取る
3. ★**対局の頭の状態**に、その並びを持たせて返す

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:replayOf` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:replayOf`
- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）
- それ以外は「頭から始める」

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:replayOf` の試験材料

- 試験: `shared/src/test/kotlin/othello/OthelloBridgeSplitTest.kt`（★**この関数だけを撃つ**）

### 3c.4 `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:nextOf` の処理手順

1. 手の並びが空なら、受理せずに理由を返す
2. 先頭の升を置く。置けたら、並びから 1 つ外した状態を返す
3. 置けなければパスとして進め、並びから 1 つ外す

★**打ち手を呼ばない。**手は記録に在る（CR-10 の 10-3）。

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:nextOf` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:nextOf`
- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）
- もし `並びが空` なら「断る」
- それ以外は「1 つ進む」

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:nextOf` の試験材料

- 試験: `shared/src/test/kotlin/othello/OthelloBridgeSplitTest.kt`（★**この関数だけを撃つ**）

### 3c.5 `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:helpOf` の処理手順

1. 出来事が「ヘルプ」なら印を立て、そうでなければ下ろした状態を返す

★**盤にも進行にも触らない。**★**閉じるときに戻す作業を持たない**（[[DD-L3-othello]] §7.4）。

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:helpOf` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:helpOf`
- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）
- それ以外は「印を変えた」

#### `shared/src/main/kotlin/othello/OthelloBridgeEvent.kt:OthelloBridgeEvent:helpOf` の試験材料

- 試験: `shared/src/test/kotlin/othello/OthelloBridgeSplitTest.kt`（★**この関数だけを撃つ**）

---

## 3d. 後始末 — `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt`

★**どの出来事のあとでも走る部分**だけを持つ。★**出来事の種類では分かれない**。

### 3d.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:drawn(state: State, setup: Setup, event: Command, ok: Boolean) -> State` | いまの状態、対局の設定、出来事、受理できたか | 形勢の並びを伸ばすか切り詰めた状態 |
| `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:closed(state: State, log: LogHandle, root: String, keep: Int) -> Written` | いまの状態、記録の在り処、記録を置くところ、残す代の数 | ★**閉じたときだけ**永続化して控えを取る |
| `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:told(view: View, event: Command, root: String, shown: Int) -> View` | 一式、出来事、記録を置くところ、一覧に出す上限 | ★**結果を文言に載せた一式**。当てはまらなければそのまま |

### 3d.2 `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:drawn` の処理手順

1. 待ったなら、手数に合わせて切り詰める
2. 受理できていなければ、そのまま返す
3. それ以外は、形勢の並びを 1 つ伸ばす

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:drawn` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:drawn`
- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）
- もし `待った` なら「切り詰める」
- それ以外は「伸ばす」

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:drawn` の試験材料

- 試験: `shared/src/test/kotlin/othello/OthelloBridgeSplitTest.kt`（★**この関数だけを撃つ**）

### 3d.3 `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:closed` の処理手順

1. 記録の手が無い・まだ閉じていない・置き場が空・番号が無いなら、何もしない
2. 勝敗と枚数を数え、DB を終わらせる（★**ここで永続化される**）
3. 続けて控えを取る

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:closed` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:closed`
- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）
- もし `閉じていない` なら「何もしない」
- それ以外は「永続化する」

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:closed` の試験材料

- 試験: `shared/src/test/kotlin/othello/OthelloBridgeSplitTest.kt`（★**この関数だけを撃つ**）

### 3d.4 `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:told` の処理手順

1. 一覧なら、新しいほうから上限まで取り、一式に載せる。1 本も無ければその旨を文言に出す
2. 取り込みなら、入った本数を文言に出す
3. 書き出しなら、在り処と行数を文言に出す。書き出す先が無ければその旨を出す
4. どれでもなければ、受け取った一式をそのまま返す

★★**文言は一式の欄に入れる。**拒否の理由は画面に出ていないので、そこへ入れると**押しても何も出ない**（BUG-48）。

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:told` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:told`
- 入口の語: `view`, `event`, `root`, `shown`
- もし `当てはまらない出来事` なら「そのまま」
- それ以外は「文言を載せる」
- 出口「そのまま」は `['message']:` で認める
- 出口「文言を載せる」は `['message']:まだ記録がありません` で認める

#### `shared/src/main/kotlin/othello/OthelloBridgeAfter.kt:OthelloBridgeAfter:told` の試験材料

- 入力 `view={"message": ""}, event={"kind": "square", "value": "d3"}, root="", shown=50` のとき 特徴 `当てはまらない出来事=True`
- 入力 `view={"message": ""}, event={"kind": "games", "value": ""}, root="", shown=50` のとき 特徴 `当てはまらない出来事=False`
- 出口「そのまま」は `['message']:` で認める
- 出口「文言を載せる」は `['message']:まだ記録がありません` で認める

---

## 3b. ヘルプの本文 — `shared/src/main/kotlin/othello/OthelloHelp.kt`（F-12・RF-64）

★★**読む相手は、対局する人である**（[[DD-L1-othello]] §6.8）。作る側の言葉を入れない。
★**節の並びを持つだけ**で、描き方も開き閉めも持たない。

### 3b.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sections() -> List<HelpSection>` | 無し | ★**5 つの節を、画面に出す順に並べたもの**（遊び方・画面の見かた・押せるもの・形勢のグラフ・前の対局を見る） |
| `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sectionAt(index: Int) -> HelpSection?` | 何番目の節か（0 から） | その節。★**並びの外なら「無し」** |

★**`HelpSection` は題と本文の組**（[[DD-L3-othello]] §3.4b）。本文は**行の並び**で持ち、1 行が 1 つの言い切りである。

### 3b.2 `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sections` の処理手順

1. 5 つの節を、決めた順に並べて返す

★**順を作らない。**★**書いてある順がそのまま画面の順**である（[[DD-L3-othello]] §3.4b）——
並べ替えを持つと、**設計書の順と画面の順が割れる**。

#### `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sections` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sections`
- それ以外は「節の並び」
- 出口「節の並び」は `len:5` で認める

#### `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sections` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★引数も無いので材料で変えられる入力が無い

### 3b.3 `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sectionAt` の処理手順

1. 番号が 0 より小さいか、節の数以上なら、「無し」を返す
2. その番号の節を返す

★**近い番号へ丸めない。**丸めると、**間違った呼び方が黙って通る**（[[DD-L3-othello-ai]] §3.2 の段と同じ理由）。

#### `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sectionAt` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sectionAt`
- 入口の語: `index`
- もし `並びの外` なら「無し」
- それ以外は「その節」
- 出口「無し」は `is_none` で認める
- 出口「その節」は `['title']:遊び方` で認める

#### `shared/src/main/kotlin/othello/OthelloHelp.kt:OthelloHelp:sectionAt` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

---

## 3z. ★環境の口（★道つきで書く・法 §4-1）

★**環境ごとに 1 つ**。★**起こし方と、置き場の伝え方だけ**を持つ（[[DD-L3-othello]] §環境の口）。

| ファイル | 何を持つか |
|:---|:---|
| `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt` | ★**Windows の口**。★窓の大きさも、ここが決める（★盤・わき・グラフが全部入る大きさ） |
| `android/src/main/kotlin/othello/android/OthelloHost.kt` | ★**Android の口**。★`java.net.http` は無いので、在るものを使う |

★★**同じ名が二つ在っても、道で決まる**——★**名だけでは、どちらを指すか決まらない**。


## 3z2. ★環境の口の関数（★道つき・DSL）

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:given() -> String` | ★**無し** | ★**渡された置き場**（★空なら既定） |
| `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:providedPlace() -> String` | ★**無し** | ★**環境が指した置き場** |
| `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:given() -> String` | ★**無し** | ★**同上**（Android の口） |
| `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:providedPlace() -> String` | ★**無し** | ★**同上** |

#### `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:given` の挙動宣言

- 対象コード: `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:given`
- 入口の語: `given`
- もし `渡されぬ` なら「既定」
- それ以外は「渡された値」
- 出口「既定」は `regex:^既定$` で認める
- 出口「渡された値」は `regex:^渡された値$` で認める
- ★**錨**: ★**起こし方と置き場の伝え方だけを持つ**（DD-L3-othello §環境の口）

#### `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:given` の試験材料

- 入力 `` のとき 特徴 `渡されぬ=True`
- 入力 `` のとき 特徴 `渡されぬ=False`
- 出口「既定」は `regex:^既定$` で認める
- 出口「渡された値」は `regex:^渡された値$` で認める

#### `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:providedPlace` の挙動宣言

- 対象コード: `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:providedPlace`
- 入口の語: `providedPlace`
- もし `指されぬ` なら「既定」
- それ以外は「指された値」
- 出口「既定」は `regex:^既定$` で認める
- 出口「指された値」は `regex:^指された値$` で認める
- ★**錨**: ★**窓の大きさもここが決める**（★盤・わき・グラフが全部入る）

#### `desktop/src/main/kotlin/othello/desktop/OthelloHost.kt:OthelloHost:providedPlace` の試験材料

- 入力 `` のとき 特徴 `指されぬ=True`
- 入力 `` のとき 特徴 `指されぬ=False`
- 出口「既定」は `regex:^既定$` で認める
- 出口「指された値」は `regex:^指された値$` で認める

#### `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:given` の挙動宣言

- 対象コード: `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:given`
- 入口の語: `given`
- もし `渡されぬ` なら「既定」
- それ以外は「渡された値」
- 出口「既定」は `regex:^既定$` で認める
- 出口「渡された値」は `regex:^渡された値$` で認める
- ★**錨**: ★**起こし方と置き場の伝え方だけを持つ**（DD-L3-othello §環境の口）

#### `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:given` の試験材料

- 入力 `` のとき 特徴 `渡されぬ=True`
- 入力 `` のとき 特徴 `渡されぬ=False`
- 出口「既定」は `regex:^既定$` で認める
- 出口「渡された値」は `regex:^渡された値$` で認める

#### `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:providedPlace` の挙動宣言

- 対象コード: `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:providedPlace`
- 入口の語: `providedPlace`
- もし `指されぬ` なら「既定」
- それ以外は「指された値」
- 出口「既定」は `regex:^既定$` で認める
- 出口「指された値」は `regex:^指された値$` で認める
- ★**錨**: ★**窓の大きさもここが決める**（★盤・わき・グラフが全部入る）

#### `android/src/main/kotlin/othello/android/OthelloHost.kt:OthelloHost:providedPlace` の試験材料

- 入力 `` のとき 特徴 `指されぬ=True`
- 入力 `` のとき 特徴 `指されぬ=False`
- 出口「既定」は `regex:^既定$` で認める
- 出口「指された値」は `regex:^指された値$` で認める

## 4. 画面 — `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt` ・ `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt` ・ `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt` ・ `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt` ・ ★`ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt`

Windows と Android で同じものを使う。**判定を持たない。**受け取った一式を描き、
触られた位置を升の名前に直して渡すだけ。

★★**列の文字が盤からはみ出さないこと。**盤の格子だけを正方形にすると、★**文字の行だけが窓の幅いっぱいに伸び、f・g・h が盤の外に出る**（実測 2026-08-13・BUG-41）。∴ **文字も格子も、同じ入れ物の中で正方形に保つ。**

★★**わきの分を、先に取り分ける。**盤の列を「中身の大きさ」で置くと、★**中のグラフが窓いっぱいに広がったときに、わきが画面の外へ出る**（実測 2026-08-13・BUG-45。**一瞬出て、次の測り直しで消える**）。
∴ **わきに幅を与え、残りを盤の列にする。**

★★**盤とわきのあいだに、空きを作らない。**窓の幅を 3 分の 1 ずつで分けると、★**盤は高さで決まる正方形なので、その右に大きな空きができ、わきが遠くへ離れる**（実測 2026-08-13）。∴ **盤は中身の大きさで置き、わきはその隣に置く。**

★★**わきの補助情報に、幅の上限を持たせる。**窓を広げると、★**名前が左端・値が右端に離れて、右上に寄って見える**（実測 2026-08-13・BUG-42）。

★★**別の筋で走らせるのは、判断ではない。**「重いものを画面の筋に置かない」という**見せ方の決め**である（[[DD-L2-othello]] §7z.2b の 5）。
★**何を計算するかは、いままでどおり共通が決める。**画面は**どの筋で呼ぶか**だけを持つ。

★★**自動試験を書かないのは「描くこと」だけである。**この 5 本が持つのは描画だけなので、
テストの終端として宣言する（分類は、対話的な画面で人手の確認が要るもの）。

### 4b. ★ヘルプの画面（F-12・RF-64）

| 誰が | 何を持つか |
|:---|:---|
| `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt` | ★**「ヘルプ」のボタン**を、いちばん下に置く。★**いつでも押せる**（押せるかを画面が判断しない） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt` | ★**一式の印を見て**ヘルプを出す。★**画面は印を持たない**——持つと共通側と食い違う |
| `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt` | ★**節を受け取って並べるだけ**。★**文言を持たない**（`OthelloHelp` が持つ）。★**並べ替えない** |

★**画面が上へ渡す出来事は 2 つ**——「ヘルプ」と「閉じる」。
★★**どちらも `handle` の決めた語に入っていること**（§3.2 の 5i・5j）——
★**入れ忘れると手順 1 で断られ、押しても何も起きない**。
★**そのとき画面の側をいくら見ても原因が分からない**（[[BUG-記録]] の「誰がやるかを決めない機能は動かない」と同じ形）。

★★**判定も、状態の持ち回りも、ここに置かない。**置けば、**そこだけ試験の無い場所**になる。
★**実測 2026-08-12**: 口（環境ごとの窓口）に状態の持ち回りを置いたところ、
**そこで欠陥が出た**——そして**そこには試験が 1 本も無かった**。
∴ 状態は**窓口が返した器を 1 つ持つだけ**にし（[[DD-L2-othello]] §7z.2b2）、
**持ち回りの正しさは、窓口の側の試験で押さえる**。

★**「試験が書けない」と「試験を書かない」を混ぜない。**書けないのは描画であって、
**判断と状態は、いつでも書ける。**

★**「やめる」が押せるかどうかも、画面は判断しない。**対局が在るかを画面が見に行くと、**その判断が環境ごとに写る**（[[DD-L1-othello]] §5.5）。∴ **押せるかを渡す。**

★**「新しい対局」は、いつでも押せる**（[[DD-L1-othello]] §5.5）。押せるかどうかを画面が判断しないので、**一式の「押せるもの」には入らない**——★**常に押せるものは、押せるかどうかを持たない**。

★**設定の窓を別ファイルにした。**わきの補助情報へ押し込むと、90 行が 170 行を超え、
**上限の 200 行に張り付く**。次に何か足した瞬間に超える。

| ファイル | 何を描くか | 判定を持つか |
|:---|:---|:---|
| `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt` | 盤・座標・石・薄い丸。★**列の文字と行の数字は、盤と同じ幅・同じ高さに揃える**（盤全体を正方形に保つ） | 持たない |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt` | 手番・枚数・手数・直前の手・置ける升の数・★**強さ（黒）と強さ（白）の 2 行**（CR-12。計算機の側だけ）・ボタン（パス・待った・★**新しい対局**・★**再生**・★**取り込み**） | 持たない |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt` | 黒白それぞれの打ち手・先手後手・**強さのポップアップ**・★**やめる（押せるかは渡される）** | 持たない |
| `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt` | 3 つを並べる。触られたことを共通へ渡す。★**計算機の 1 手は別の筋で送り、そのあいだ「考えています」と出す**。★**盤とわきは、間を空けずに隣り合わせる** | 持たない |

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:handle` の呼ぶIF

- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloView.kt:OthelloView:buildView` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump` を呼ぶ
- [[DD-L4-othello-graph]] `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended` を呼ぶ
- [[DD-L4-othello-graph]] `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:opened` の呼ぶIF

- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` を呼ぶ
- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` を呼ぶ
- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloBridge.kt:OthelloBridge:recordMove` の呼ぶIF

- [[DD-L4-othello-db]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` を呼ぶ
- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` を呼ぶ
- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones` を呼ぶ

★★**辺は「誰が呼ぶか」で置く。**——★**対局の頭は `opened`、1 手ごとは `recordMove`、終わりは `handle`**（[[DD-L3-othello-db]] §4.1）。
★**まとめて `handle` に並べていた**（`shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` ・ `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove`）——**呼ぶ者が違うので、辺の置き場所も違う。**
★**実測 2026-08-13**: 3 つとも `handle` に書いてあり、照合で 1 件が食い違った。

★**進行・待った・状態・表示の組み立ては [[DD-L4-othello-play]] が持つ。**呼ぶ相手が別の設計書になったので、**辺として宣言する**。

---

## 5. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| 共通へ入る道は 1 本 | `handle` だけが出来事を受ける |
| 窓口は判定を持たない | 2 から 5 は進行の関数をそのまま呼ぶ |
| 断ったときも一式を返す | 手順 6 と 8 |
| 計算機は 1 手だけ進む | 手順 7（CR-6） |
| 記録を開き、書き、閉じる | `handle` の 5c と `recordMove`（[[DD-L2-othello]] §7z.2b3） |
| 画面は判定を持たない | §4 の表。4 本とも「持たない」 |