# DD-L4 関数仕様 — 対局の進行（Flutter 版）

- doc_id : DD-L4-othello-flutter-play ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **対局の進行**（設定・状態・手を打つ・待った・画面へ渡す一式）を、**Dart／Flutter の側**で持つ
- 出典 : [[DD-L3-othello]] §2（受け皿のうち進行の側）・§4（状態）
- 呼ぶ相手 : `flutter/lib/othello_rules.dart`・`flutter/lib/othello_board.dart`（規則の側だけ）

---

## 0. なぜこの設計書が要るか

★★**Flutter 版のコードを、どの設計書も名乗っていなかった。**
[[DD-L4-othello-play]] が名乗るのは Kotlin のファイルであって、`flutter/lib/*.dart` ではない。
★**姉妹として分ける**——★**対象コードが違うので二重所有にならない。**

## 0b. 言語を移したときに、何が変わって何が変わらなかったか

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | **1 つも動かしていない** |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | ★**段の並びは 1 つも変えていない** |
| 挙動の宣言・試験の材料 | 同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | `OthelloGame.kt` から `othello_game.dart` へ |
| 型の名 | `Int` は `int`、`Boolean` は `bool` になった |

## 1. ファイルの分け方

| Dart のファイル | 何を持つか |
|:---|:---|
| `flutter/lib/othello_setup.dart` | 誰が黒か・強さ。★**どちらが人かを知っているのはここだけ** |
| `flutter/lib/othello_state.dart` | 状態を作る・数える・直前の手 |
| `flutter/lib/othello_game.dart` | 手を打つ・パス |
| `flutter/lib/othello_undo.dart` | 待った |
| `flutter/lib/othello_view.dart` | 画面へ渡す一式 |

★**実測（2026-08-23）**: 5 本とも **4 関数以内**、**61 行以内**。

## 2. 綴りの決め

名指しは**三要素**で書く。クラスの欄は実在する入れ物の名を書く。

## 3. 設定 — `flutter/lib/othello_setup.dart`

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_setup.dart:OthelloSetup:newSetup(black: String, white: String, blackLevel: int, whiteLevel: int) -> Setup` | 黒の打ち手、白の打ち手、それぞれの段 | 設定 |
| `flutter/lib/othello_setup.dart:OthelloSetup:isMachineTurn(setup: Setup, turn: String) -> bool` | 設定、手番 | いまの手番が計算機か |
| `flutter/lib/othello_setup.dart:OthelloSetup:levelOf(setup: Setup, turn: String) -> int` | 設定、手番 | その手番の段 |

### 3.2 `flutter/lib/othello_setup.dart:OthelloSetup:newSetup` の処理手順

1. 渡された 4 つを器に入れて返す

#### `flutter/lib/othello_setup.dart:OthelloSetup:newSetup` の挙動宣言

- 対象コード: `flutter/lib/othello_setup.dart:OthelloSetup:newSetup`
- 入口の語: `newSetup`
- 分岐は無い
- 出口「設定」は `contains:True` で認める

#### `flutter/lib/othello_setup.dart:OthelloSetup:newSetup` の試験材料

- 入力 `black="human", white="machine", blackLevel=4, whiteLevel=4` のとき 特徴 `黒="human"`・`白="machine"`

### 3.3 `flutter/lib/othello_setup.dart:OthelloSetup:isMachineTurn` の処理手順

1. 手番が黒なら、黒の打ち手を見る
2. 手番が白なら、白の打ち手を見る
3. その打ち手が計算機なら真、そうでなければ偽

★★**どちらが人かを知っているのは設定だけ。**★画面も規則も、これを持たない。

#### `flutter/lib/othello_setup.dart:OthelloSetup:isMachineTurn` の挙動宣言

- 対象コード: `flutter/lib/othello_setup.dart:OthelloSetup:isMachineTurn`
- 入口の語: `isMachineTurn`
- もし その手番の打ち手が計算機 なら「計算機」
- それ以外は「人」
- 出口「計算機」は `is_true` で認める
- 出口「人」は `is_false` で認める

#### `flutter/lib/othello_setup.dart:OthelloSetup:isMachineTurn` の試験材料

- 入力 `setup=(human, machine, 4, 4), turn="B"` のとき 特徴 `計算機=False`
- 入力 `setup=(human, machine, 4, 4), turn="W"` のとき 特徴 `計算機=True`

### 3.4 `flutter/lib/othello_setup.dart:OthelloSetup:levelOf` の処理手順

1. 手番が黒なら黒の段、白なら白の段を返す

#### `flutter/lib/othello_setup.dart:OthelloSetup:levelOf` の挙動宣言

- 対象コード: `flutter/lib/othello_setup.dart:OthelloSetup:levelOf`
- 入口の語: `levelOf`
- もし 手番が黒 なら「黒の段」
- それ以外は「白の段」
- 出口「黒の段」は `contains:True` で認める
- 出口「白の段」は `contains:True` で認める

#### `flutter/lib/othello_setup.dart:OthelloSetup:levelOf` の試験材料

- 入力 `setup=(human, machine, 2, 5), turn="B"` のとき 特徴 `段=2`
- 入力 `setup=(human, machine, 2, 5), turn="W"` のとき 特徴 `段=5`

## 4. 状態 — `flutter/lib/othello_state.dart`

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_state.dart:OthelloState:newState() -> GameState` | 無し | 初期配置・黒の番・手数 0・履歴なし |
| `flutter/lib/othello_state.dart:OthelloState:countStones(board: List<String>) -> Stones` | 盤 | 黒の枚数と白の枚数 |
| `flutter/lib/othello_state.dart:OthelloState:lastMoveInfo(history: List<Entry>) -> LastMove?` | 履歴 | 直前の手と、そのとき裏返った枚数。無ければ持たない |

### 4.2 `flutter/lib/othello_state.dart:OthelloState:newState` の処理手順

1. 初期配置の盤を作る
2. 手番を黒にする
3. 手数を 0 にし、履歴を空にする
4. 器に入れて返す

#### `flutter/lib/othello_state.dart:OthelloState:newState` の挙動宣言

- 対象コード: `flutter/lib/othello_state.dart:OthelloState:newState`
- 入口の語: `newState`
- 分岐は無い
- 出口「新しい状態」は `contains:True` で認める

#### `flutter/lib/othello_state.dart:OthelloState:newState` の試験材料

- 入力 無し のとき 特徴 `手番="B"`・`手数=0`・`履歴=0`

### 4.3 `flutter/lib/othello_state.dart:OthelloState:countStones` の処理手順

1. 盤の升を 1 つずつ見る
2. 黒なら黒の数に 1 を足す
3. 白なら白の数に 1 を足す
4. 2 つを器に入れて返す

#### `flutter/lib/othello_state.dart:OthelloState:countStones` の挙動宣言

- 対象コード: `flutter/lib/othello_state.dart:OthelloState:countStones`
- 入口の語: `countStones`
- 分岐は無い
- 出口「枚数」は `contains:True` で認める

#### `flutter/lib/othello_state.dart:OthelloState:countStones` の試験材料

- 入力 `board=初期配置` のとき 特徴 `黒=2`・`白=2`

### 4.4 `flutter/lib/othello_state.dart:OthelloState:lastMoveInfo` の処理手順

1. 履歴が空なら、持たないことが分かる形で返す
2. 末尾の項から、升と裏返った枚数を取り出して返す

★**「直前の手が無い」を、空の升で表さない。**★**持たないことが分かる形**で返す。

#### `flutter/lib/othello_state.dart:OthelloState:lastMoveInfo` の挙動宣言

- 対象コード: `flutter/lib/othello_state.dart:OthelloState:lastMoveInfo`
- 入口の語: `lastMoveInfo`
- もし 履歴が空 なら「無し」
- それ以外は「直前の手」
- 出口「無し」は `is_none` で認める
- 出口「直前の手」は `contains:True` で認める

#### `flutter/lib/othello_state.dart:OthelloState:lastMoveInfo` の試験材料

- 入力 `history=[]` のとき 特徴 `無し=True`
- 入力 `history=[d3 で 1 枚]` のとき 特徴 `升="d3"`・`枚数=1`

## 5. 手を打つ — `flutter/lib/othello_game.dart`

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_game.dart:OthelloGame:beforeState(state: GameState) -> Before` | いまの状態 | 打つ前の控え（盤・手番・手数） |
| `flutter/lib/othello_game.dart:OthelloGame:play(state: GameState, move: String) -> Played` | いまの状態、置く升 | 打てたかどうかと、打てたなら新しい状態 |
| `flutter/lib/othello_game.dart:OthelloGame:passTurn(state: GameState) -> Played` | いまの状態 | パスできたかどうかと、できたなら新しい状態 |

### 5.2 `flutter/lib/othello_game.dart:OthelloGame:beforeState` の処理手順

1. いまの盤・手番・手数を写して器に入れ、返す

★**打つ前を控える。**★これが待ったの材料になる。

#### `flutter/lib/othello_game.dart:OthelloGame:beforeState` の挙動宣言

- 対象コード: `flutter/lib/othello_game.dart:OthelloGame:beforeState`
- 入口の語: `beforeState`
- 分岐は無い
- 出口「控え」は `contains:True` で認める

#### `flutter/lib/othello_game.dart:OthelloGame:beforeState` の試験材料

- 入力 `state=初期状態` のとき 特徴 `手番="B"`・`手数=0`

### 5.3 `flutter/lib/othello_game.dart:OthelloGame:play` の処理手順

1. 置ける升を聞く
2. その升が置ける升に無ければ、打てなかったと分かる形で返す
3. 打つ前を控える
4. 規則に置かせ、新しい盤を受け取る
5. 手番を入れ替え、手数に 1 を足す
6. 履歴に、控えと升と裏返った枚数を積む
7. 新しい状態を器に入れて返す

★★**「打てない」を、状態を変えずに返す。**★**変えてから戻すのではない。**

#### `flutter/lib/othello_game.dart:OthelloGame:play` の挙動宣言

- 対象コード: `flutter/lib/othello_game.dart:OthelloGame:play`
- 入口の語: `play`
- もし その升が置ける升に無い なら「打てない」
- それ以外は「打てた」
- 出口「打てない」は `ok=False` で認める
- 出口「打てた」は `ok=True` で認める

#### `flutter/lib/othello_game.dart:OthelloGame:play` の試験材料

- 入力 `state=初期状態, move="d3"` のとき 特徴 `ok=True`・`手番="W"`・`手数=1`
- 入力 `state=初期状態, move="a1"` のとき 特徴 `ok=False`

### 5.4 `flutter/lib/othello_game.dart:OthelloGame:passTurn` の処理手順

1. 置ける升を聞く
2. 1 つでも置けるなら、パスできないと分かる形で返す
3. 打つ前を控える
4. 手番を入れ替え、手数に 1 を足す
5. 履歴に、パスであることが分かる形で積む
6. 新しい状態を器に入れて返す

★★**置ける升が在るときはパスできない。**★**勝手に手番を進めない**という決め
（[[DD-L1-othello]] §6.2）を、ここで守る。

#### `flutter/lib/othello_game.dart:OthelloGame:passTurn` の挙動宣言

- 対象コード: `flutter/lib/othello_game.dart:OthelloGame:passTurn`
- 入口の語: `passTurn`
- もし 置ける升が 1 つ以上ある なら「パスできない」
- それ以外は「パスできた」
- 出口「パスできない」は `ok=False` で認める
- 出口「パスできた」は `ok=True` で認める

#### `flutter/lib/othello_game.dart:OthelloGame:passTurn` の試験材料

- 入力 `state=初期状態` のとき 特徴 `ok=False`
- 入力 `state=置ける升が無い状態` のとき 特徴 `ok=True`・`手番が入れ替わる=True`

## 6. 待った — `flutter/lib/othello_undo.dart`

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_undo.dart:OthelloUndo:undo(state: GameState, setup: Setup) -> Played` | いまの状態、設定 | 戻せたかどうかと、戻せたなら前の状態 |

### 6.2 `flutter/lib/othello_undo.dart:OthelloUndo:undo` の処理手順

1. 履歴が空なら、戻せないと分かる形で返す
2. 末尾の控えを取り出し、盤・手番・手数を**まとめて**戻す
3. 履歴から末尾を落とす
4. 戻した先が計算機の番なら、**もう 1 手戻す**
5. 新しい状態を器に入れて返す

★★**控えを 1 つの器で戻す。**★盤だけ戻して手数を戻し忘れる、が**構造として起きない**
（[[DD-L4-othello-play]] の同じ決め）。

★★**4 が要る。**★戻した先が計算機の番だと、**戻した瞬間にまた同じ手が打たれる**。

#### `flutter/lib/othello_undo.dart:OthelloUndo:undo` の挙動宣言

- 対象コード: `flutter/lib/othello_undo.dart:OthelloUndo:undo`
- 入口の語: `undo`
- もし 履歴が空 なら「戻せない」
- それ以外は「戻せた」
- 出口「戻せない」は `ok=False` で認める
- 出口「戻せた」は `ok=True` で認める

#### `flutter/lib/othello_undo.dart:OthelloUndo:undo` の試験材料

- 入力 `state=初期状態, setup=(human, human, 4, 4)` のとき 特徴 `ok=False`
- 入力 `state=1 手打った状態, setup=(human, human, 4, 4)` のとき 特徴 `ok=True`・`手数=0`

## 7. 画面へ渡す一式 — `flutter/lib/othello_view.dart`

### 7.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_view.dart:OthelloView:pressable(state: GameState, moves: Moves) -> Pressable` | 状態、置ける升 | 升・パス・待った、それぞれ押せるか |
| `flutter/lib/othello_view.dart:OthelloView:buildView(state: GameState, setup: Setup) -> View` | 状態、設定 | 画面が描くのに要るもの一式 |
| `flutter/lib/othello_view.dart:OthelloView:levelOrNone(setup: Setup, turn: String) -> int?` | 設定、手番 | いまの手番の段。計算機でなければ持たない |

### 7.2 `flutter/lib/othello_view.dart:OthelloView:pressable` の処理手順

1. 升は、置ける升の一覧が空でなければ押せる
2. パスは、置ける升が 0 のときだけ押せる
3. 待ったは、履歴があるときだけ押せる
4. 3 つを器に入れて返す

★★**「打てない」を画面に任せない。**★画面が押せる升を無視するだけだと、
次の画面が来たときに、また押せるように見える。★**押せないことは、渡すものの側で決める。**

#### `flutter/lib/othello_view.dart:OthelloView:pressable` の挙動宣言

- 対象コード: `flutter/lib/othello_view.dart:OthelloView:pressable`
- 入口の語: `pressable`
- もし 置ける升が 0 なら「パスだけ」
- それ以外は「升が押せる」
- 出口「パスだけ」は `contains:True` で認める
- 出口「升が押せる」は `contains:True` で認める

#### `flutter/lib/othello_view.dart:OthelloView:pressable` の試験材料

- 入力 `state=初期状態, moves=4 件` のとき 特徴 `升=True`・`パス=False`・`待った=False`
- 入力 `state=初期状態, moves=0 件` のとき 特徴 `升=False`・`パス=True`

### 7.3 `flutter/lib/othello_view.dart:OthelloView:buildView` の処理手順

1. 置ける升を聞く
2. 枚数を数える
3. 直前の手を取る
4. 押せるかを作る
5. ★**次も計算機の番かを、設定と手番から決める**
6. 終局していれば終局の文言を入れる。していなければ空
7. 以上を**新しい器**にまとめて返す

★★**5 は一式が言う。**★画面は判断しない（[[DD-L2-othello]] §7z）。
★**真なら、画面は間を置いてから次の出来事を送る**（[[DD-L1-othello]] §6.4・CR-6）。

★**前に渡した器を書き換えて使い回さない。**★画面がまだ描いている途中の値を書き換えることになる。

#### `flutter/lib/othello_view.dart:OthelloView:buildView` の挙動宣言

- 対象コード: `flutter/lib/othello_view.dart:OthelloView:buildView`
- 入口の語: `buildView`
- もし 終局している なら「終局の一式」
- それ以外は「続きの一式」
- 出口「終局の一式」は `contains:True` で認める
- 出口「続きの一式」は `contains:True` で認める

#### `flutter/lib/othello_view.dart:OthelloView:buildView` の試験材料

- 入力 `state=初期状態, setup=(human, machine, 4, 4)` のとき 特徴 `終局=False`・`次も計算機=False`
- 入力 `state=初期状態, setup=(machine, machine, 4, 4)` のとき 特徴 `次も計算機=True`
- 入力 `state=終局した状態, setup=(human, human, 4, 4)` のとき 特徴 `終局=True`

### 7.4 `flutter/lib/othello_view.dart:OthelloView:levelOrNone` の処理手順

1. いまの手番が計算機でなければ、持たないことが分かる形で返す
2. その手番の段を返す

#### `flutter/lib/othello_view.dart:OthelloView:levelOrNone` の挙動宣言

- 対象コード: `flutter/lib/othello_view.dart:OthelloView:levelOrNone`
- 入口の語: `levelOrNone`
- もし 手番が計算機でない なら「無し」
- それ以外は「段」
- 出口「無し」は `is_none` で認める
- 出口「段」は `contains:True` で認める

#### `flutter/lib/othello_view.dart:OthelloView:levelOrNone` の試験材料

- 入力 `setup=(human, machine, 4, 5), turn="B"` のとき 特徴 `無し=True`
- 入力 `setup=(human, machine, 4, 5), turn="W"` のとき 特徴 `段=5`

## 8. 計算機の番 — `flutter/lib/othello_turn.dart`

★★**入れ忘れていた**（★是正 2026-08-23・owner 指摘「kt の実装みよ。DD に入れ忘れたろう」）。
★**Kotlin 版は `OthelloTurn.machineStep` を持っている**（[[DD-L4-othello-play]] §8）。
★**Flutter 版の設計書に、この関数が無かった。**

★★**この関数は盤を読まない。**★置ける升の判定も、裏返しも、全部よそが持っている。

### 8.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_turn.dart:OthelloTurn:machineStep(state: GameState, setup: Setup, nowMs: int) -> Stepped` | いまの状態、設定、いまの時刻 | 進めたか・パスしたか・新しい状態・理由 |

### 8.2 `flutter/lib/othello_turn.dart:OthelloTurn:machineStep` の処理手順

1. いまの手番が計算機でなければ、進めないと分かる形で返す
2. ★**打つ側の組を使う**（CR-12）
3. 打ち手に手を聞く
4. ★★**升が空なら、`passTurn` を呼ぶ**——★**置けない番の担当がパスする**
5. 升が在れば、その升で打つ

★★**置けない番の担当がパスする。★機械かどうかによらない**（owner 2026-08-23）。
★**人の番なら人が押す**（[[DD-L1-othello]] §6.2「パスのボタンを出して押させる」）。
★**計算機の番なら、計算機が自分でパスする。**
★**「勝手に手番を進めない」は、★担当が誰かの話であって、★パスを誰もしない、という意味ではない。**

★★**2 を間違えると、相手の強さで打つ**（CR-12）。★手番の側の組を引く。

### 8.3 `flutter/lib/othello_turn.dart:OthelloTurn:machineStep` の挙動宣言

- 対象コード: `flutter/lib/othello_turn.dart:OthelloTurn:machineStep`
- 入口の語: `machineStep`
- もし 手番が計算機でない なら「進めない」
- もし 升が空 なら「パスした」
- それ以外は「打った」
- 出口「進めない」は `ok=False` で認める
- 出口「パスした」は `passed=True` で認める
- 出口「打った」は `passed=False` で認める

### 8.4 `flutter/lib/othello_turn.dart:OthelloTurn:machineStep` の試験材料

- 入力 `state=初期状態, setup=(human, machine, 4, 4), nowMs=0` のとき 特徴 `ok=False`
- 入力 `state=初期状態, setup=(machine, machine, 4, 4), nowMs=0` のとき 特徴 `ok=True`・`passed=False`・`手数=1`
- 入力 `state=置ける升が無い状態, setup=(machine, machine, 4, 4), nowMs=0` のとき 特徴 `passed=True`

## 9. 試験

★試験は `flutter/test/` に在る。★★**登録はしていない**（owner 指示 2026-08-23）。
