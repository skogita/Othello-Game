# DD-L4 関数仕様 — 対戦の記録

- doc_id : DD-L4-othello-log ／ design_level : L4 ／ 上位 : [[DD-L3-othello-log]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料**を定める。
- 出典 : DD-L3-othello-log §2（受け皿）・§3（データ構造）・§6（概要の手順）

---

## 0. L4 と L5 の役割分担

**全部 L4 に書く。L5 は書かない。**差し込みの口を持たないため。


### 0b. ★言語を移したときに、何が変わって何が変わらなかったか

この一式は、共通の実装を別の言語へ移した（[[DD-L2-othello]] §7z.4）。**そのとき何が動いたかを残す。**

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | どのファイルに何を置くか。1 つも動かしていない |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | 段の並びは 1 つも変えていない |
| 挙動の宣言 | 条件も出口も、認めかたも同じ |
| 試験の材料 | 入力の値も、期待値も同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | 綴りの決まりが違う（区切りの記号と、大文字の使い方） |
| メソッドの名 | 同上 |
| クラスの欄 | 擬似のものから、**実在する入れ物の名**へ |
| 型の名 | その言語の型へ |

★★**設計が言語に依っていなかったことが、ここで確かめられた。**
もし手順や宣言まで書き直す必要が出ていたなら、それは**設計に実装の都合が混ざっていた**ということである。

★**型の名だけは、記法の側の都合で調整した**（下の「型の名に読点を入れない」）。
これは設計の内容ではなく、**書き表し方の問題**である。

## 1. ファイルの分け方

規約は 1 ファイル 5 関数・300 行・ネスト 4 まで。**目安は 3 関数・100 行・ネスト 2。**

| ファイル | 関数 | 行数の見込み | ネスト | 何を持つか |
|:---|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloLogWrite.kt` | 3 | 約 70 | 1 | 記録を始める・1 件書く・終わりを書く |
| `shared/src/main/kotlin/othello/OthelloLogRead.kt` | 2 | 約 60 | 2 | 1 本読む・絞って返す |
| `shared/src/main/kotlin/othello/OthelloLogOrder.kt` | 1 | 約 30 | 1 | 並びの順を確かめる |
| `shared/src/main/kotlin/othello/OthelloDrill.kt` | 4 | 約 95 | 2 | ★**素振り**。段どうしを戦わせ、記録を残す |

★**書く側と読む側を別のファイルにした。**同じファイルに置くと、
書くときに読み、読むときに書ける形になり、**追記だけ、という決めを守れなくなる**。

### 1b. ★書いた後の実測（2026-08-12）

見込みと、実際に書いたものを並べる。**見込みだけ書いて確かめないと、上限に張り付いていないことが言えない。**

| ファイル | 関数（見込み→実測） | 行数（見込み→実測） | ネスト（見込み→実測） |
|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloLogWrite.kt` | 3 → **3** | 70 → **51** | 1 → **1** |
| `shared/src/main/kotlin/othello/OthelloLogRead.kt` | 2 → **2** | 60 → **37** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloLogOrder.kt` | 1 → **1** | 30 → **24** | 1 → **2** |

★**行数はどれも見込みより短い。**規約（300 行・5 関数・ネスト 4）にも、目安（3 関数・100 行・ネスト 2）にも、**張り付いていない**。

## 2. 綴りの決め

関数を名指す綴りは、**どこでも `コードファイルの相対パス:クラス:メソッド`**。区切りはすべて `:`。
クラスに属さない関数は `(module)`。系の外は `外`。


★**分岐の無い関数は、特徴を書かない。**条件が無いのだから、「どの条件を撃ったか」も無い。無いものを埋めるために特徴をこしらえると、**試験が何を確かめているのか分からなくなる**。

★**引数を取らない関数は、材料を書かずに免除にする。**★分類は `other_language` を使う——★**免除の分類は述語で裏付くものだけが効く**（[[DD-L4-dsl-exempt-audit]] §免除の法）。`no_args` の述語は Python の構文木を引くので、この一式（Kotlin）では裏付かない。

---


★★**型の名に読点を入れない。**この記法は引数を読点で区切るので、
`Pair<Int, Int>` のような型をそのまま書くと、**引数が 1 つ増えたように読まれる**。
∴ 読点を含む型には**別名を付けて**使う（`Step`＝向きの組、`Body`＝記録の中身）。
★**記法が読める形にするのは、書き手の仕事である。**読み手を賢くして解決しない。

★★**DB の欄の名前は、英語で書く**（利用者の裁定 2026-08-13）。★**問い合わせにそのまま出る名前**だからである。
★**意味は日本語で書く**——**名前の横の説明が、意味の置き場**である。
★**辞書には語の意味だけを載せ、決めごと（必須・出どころ・鍵）は、この設計書が持つ**。

## 2a. クラスとメソッド

★**クラスの欄を空にしない。**この一式では、モジュールごとに **`object` を 1 つ**置き、
関数はその中に入る。★**クラス名は、その `object` の名である**（`USER_MANUAL` §3.10・`DesignClass`）。
**「クラスを持たない」という状態は無い。**

| クラス | コードファイル | 親クラス | 属するメソッド |
|:---|:---|:---|:---|
| `OthelloLogWrite` | `shared/src/main/kotlin/othello/OthelloLogWrite.kt` | 無し（object） | `openLog` ・ `appendEvent` ・ `closeLog` |
| `OthelloLogRead` | `shared/src/main/kotlin/othello/OthelloLogRead.kt` | 無し（object） | `readOne` ・ `collect` ・ `readMoveBodies` |
| `OthelloLogOrder` | `shared/src/main/kotlin/othello/OthelloLogOrder.kt` | 無し（object） | `checkOrder` |
| `OthelloDrill` | `shared/src/main/kotlin/othello/OthelloDrill.kt` | 無し（object） | `openDrill` ・ `runSeries` ・ `openings` ・ `playAndWrite` |

★★**この表と、インタフェース表は別物である。**
ここは**どのクラスにどのメソッドが属するか**を決める表であり、
インタフェース表は各メソッドの**入口と出口の項目**（名前・型・順序）を決める表である。
**所属が無ければ呼び先が解けず、項目が無ければ引数が合っているかを照合できない。**

★**親クラスは持たない。**`object` は継承の木に載らない。★**状態を持たない**ので、包む必要が無い。

## 3. 記録を書く — `shared/src/main/kotlin/othello/OthelloLogWrite.kt`

**日時を取るのは、このファイルだけ。**呼ぶ側に取らせない。

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog(setup: Setup, root: String) -> LogHandle` | 対局の設定（★**段と組は側ごとに入っている**。CR-12）、★**記録を置くところ** | 記録の在り処と、書けたかどうか |
| `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill(black: Params, blackLevel: Int, white: Params, whiteLevel: Int, root: String) -> LogHandle` | 黒の組と段、白の組と段、記録を置くところ | 記録の在り処と、書けたかどうか。★**両側の段と組を頭に書く** |
| `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent(log: LogHandle, kind: String, body: Body) -> Written` | 記録の在り処、種類、中身 | 書けたかどうか |
| `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog(log: LogHandle, result: Result) -> Written` | 記録の在り処、勝敗と枚数 | 書けたかどうか |

★**この 3 つの名前と形は、この設計書が決める。**呼ぶ側（対局の進行）はそのまま使う。

★**どれも「書けたかどうか」を返す。**例外を投げない。
**記録が書けないことを理由に、対局が止まってはいけない。**

### 3.2 `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog` の処理手順

1. いまの日時を取る
2. 日時から、他と重ならない名前を作る
3. ★**置き場が無ければ作る。**作った直後に、**在ることを確かめる**
4. 置き場が空か、確かめて無ければ、書けなかったと返す
5. 「対局の始まり」の 1 行を組み立てる。中身は、黒白の打ち手と、★**側ごとの段・組**（CR-12）
6. その 1 行を書く
7. 記録の在り処と、書けたかどうかを返す

★**3 が要る。**決める者（置き場を返す）と作る者を分けたので、**誰も作らないままになっていた**
（実測 2026-08-12: 記録が 1 本も残らなかった）。作るのは**書く側**である。

★**4 で「作った」を信じない。**作る仕組みは、**できなかったことを黙って返す**ことがある。
在ることを見てから書く。

★**「書けない」のは、置き場が空のときだけである。**無い場所は作るので、「場所が無い」は理由にならない。

★**1 でこちらが日時を取る。**呼ぶ側に渡させると、**呼ぶ側が時計を見る**ことになる。

★★**段と組は、設定から側ごとに取り出す**（CR-12）。★**人の側には段が無い**ので、その側は書かない。
★**片側だけ在ることが普通に起きる**——人と計算機の対局が、いちばん多い形である。

∴ **無しなら、パラメータの欄を書かずに開く**。段の欄と同じ扱いにする。

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog`
- 入口の語: `setup`, `root`
- もし `書けない` なら「書けなかった」
- それ以外は「記録を始めた」
- 出口「書けなかった」は `['ok']:False` で認める
- 出口「記録を始めた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog` の試験材料

- 入力 `setup={"black": "human", "white": "machine", "blackLevel": 3, "whiteLevel": 3, "root": "runs", "name": ""}, root="runs"` のとき 特徴 `書けない=False`
- 入力 `setup={"black": "human", "white": "machine", "blackLevel": 3, "whiteLevel": 3, "root": "runs", "name": ""}, root=""` のとき 特徴 `書けない=True`
- 出口「記録を始めた」は `['ok']:True` で認める
- 出口「書けなかった」は `['ok']:False` で認める

### 3.3 `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` の処理手順

1. いまの日時を取る
2. 種類が、決めた 4 つ（1 手・パス・待った・終わり）のいずれかかを見る。違えば書かずに返す
3. 日時・種類・中身を 1 行に組み立てる
4. ★**行の終わりまでを 1 回で書き足す。**途中で切れる書き方をしない
5. 書けたかどうかを返す

★**4 が要点。**行をまたぐと、途中で終わった記録を読むときに**最後の 1 件が半分だけ**になる。
1 行 1 件で書けば、読む側は最後の行を捨てれば済む。

★**この関数は、記録の順を確かめない。**確かめるのは読む側である（[[DD-L3-othello-log]] §5）。
ここで確かめ始めると、**書けなかったときに対局が止まる**。

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent`
- 入口の語: `log`, `kind`, `body`
- もし `種類が決めた語でない` なら「書かない」
- もし `書けない` なら「書けなかった」
- それ以外は「書いた」
- 出口「書かない」は `['reason']:contains:種類` で認める
- 出口「書けなかった」は `['reason']:contains:書けない` で認める
- 出口「書いた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` の試験材料

- 入力 `log={"path": "runs/g1.jsonl", "ok": True, "reason": ""}, kind="move", body={"turn": "B", "by": "human", "square": "d3", "flips": "1"}` のとき 特徴 `種類が決めた語でない=False, 書けない=False`
- 入力 `log={"path": "runs/g1.jsonl", "ok": True, "reason": ""}, kind="dance", body={"turn": "B", "by": "human", "square": "d3", "flips": "1"}` のとき 特徴 `種類が決めた語でない=True`
- 入力 `log={"path": "runs/g1.jsonl", "ok": False, "reason": ""}, kind="move", body={"turn": "B", "by": "human", "square": "d3", "flips": "1"}` のとき 特徴 `種類が決めた語でない=False, 書けない=True`
- 出口「書いた」は `['ok']:True` で認める
- 出口「書かない」は `['reason']:contains:種類` で認める
- 出口「書けなかった」は `['reason']:contains:書けない` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog` の処理手順

1. いまの日時を取る
2. 「対局の終わり」の 1 行を組み立てる。中身は、勝敗と黒白の最終の枚数
3. その 1 行を書き足す
4. 書けたかどうかを返す

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog`
- 入口の語: `log`, `result`
- もし `書けない` なら「書けなかった」
- それ以外は「閉じた」
- 出口「書けなかった」は `['ok']:False` で認める
- 出口「閉じた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog` の試験材料

- 入力 `log={"path": "runs/g1.jsonl", "ok": True, "reason": ""}, result={"winner": "B", "black": 34, "white": 30}` のとき 特徴 `書けない=False`
- 入力 `log={"path": "runs/g1.jsonl", "ok": False, "reason": ""}, result={"winner": "B", "black": 34, "white": 30}` のとき 特徴 `書けない=True`
- 出口「閉じた」は `['ok']:True` で認める
- 出口「書けなかった」は `['ok']:False` で認める

---

## 4. 記録を読む — `shared/src/main/kotlin/othello/OthelloLogRead.kt`

**順を確かめるのは、このファイルだけ。**

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne(path: String) -> GameRecord` | 記録 1 本の在り処 | その対局の中身（★**黒白の打ち手・段・パラメータ・勝敗**）。途中で終わっていればそう分かる形 |
| `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readMoveBodies(path: String) -> List<Body>` | 記録 1 本の在り処 | ★**「1 手」の行の中身を、古い順に**（DB へ移すために使う） |
| `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect(levels: List<Int>, root: String) -> Collected` | 集めたい段の一覧、★**記録の置き場** | 使えた対局の並びと、使えた数・外した数・壊れた数 |

★**`collect` に段の一覧を渡すのは、CR-5 のためである。**最強の段で打った対局を母数から外す。
★**絞り込みはこちらでやる。**呼んだ側に全部渡して絞らせると、**絞り忘れがそのまま母数の間違いになる**。

### 4.2 `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne` の処理手順

1. 記録を 1 行ずつ読み、並びにする
2. `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder(events: List<Event>) -> Order` を呼ぶ
3. 順が崩れていれば、**崩れていると分かる形**で返す
4. 「対局の終わり」の行が無ければ、**途中で終わったと印を付ける**
5. 始まりの行から、打ち手・段・パラメータを取る
6. 終わりの行から、勝敗と枚数を取る
7. まとめて返す

★★**記録は「両側の段と組」を持てる。**段どうしを戦わせた対局は、**黒と白で組が違う**——1 つしか書けないと、★**どちらの組が勝ったのか分からない**。
∴ 頭の行に `white_level` と `white_params` を足す。**無ければ、両側とも同じ組**（人と計算機の対局）。

★★**段は側ごとに読む**（CR-12）。**黒が人なら黒の段は無い**——★**片側だけ在ることが、普通に起きる**。
★**「段が無い＝計算機が居ない」ではない。**片側だけ計算機の対局が、いちばん多い。

★★**5 で取った打ち手を、捨てない。**手順には「打ち手・段・パラメータを取る」と書いてあったのに、**返す器に打ち手の欄が無かった**——読んだものが、読んだそばから落ちていた。
★**打ち手が無いと、段 5 は「誰が勝ったか」を数えられない**（実測 2026-08-12・BUG-32）。

★★**集めるときは、どちらかの側の段が対象に入っていれば使う**（CR-12）。**黒の段だけを見ると、★黒が人の対局が全部落ちる**（実測 2026-08-13・BUG-44）。

★**3 で読み飛ばさない。**壊れた記録を「無かったこと」にすると、
**母数から静かに減る**。減ったことは数字を見ても分からない。

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne`
- 入口の語: `path`
- もし `順が崩れている` なら「壊れた記録」
- もし `終わりの行が無い` なら「途中で終わった対局」
- それ以外は「終わった対局」
- 出口「壊れた記録」は `['broken']:True` で認める
- 出口「途中で終わった対局」は `['finished']:False` で認める
- 出口「終わった対局」は `['finished']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne` の試験材料

- 入力 `path="runs/g1.jsonl"` のとき 特徴 `順が崩れている=False, 終わりの行が無い=False`
- 入力 `path="runs/g2.jsonl"` のとき 特徴 `順が崩れている=False, 終わりの行が無い=True`
- 入力 `path="runs/g3.jsonl"` のとき 特徴 `順が崩れている=True`
- 出口「終わった対局」は `['finished']:True` で認める
- 出口「途中で終わった対局」は `['finished']:False` で認める
- 出口「壊れた記録」は `['broken']:True` で認める

### 4.2b `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readMoveBodies` の処理手順

1. 記録を 1 行ずつ読む
2. ★**「1 手」の行だけを取る**（始まりと終わりの行は取らない）
3. 中身を、古い順に並べて返す

★**並び順が、そのまま何手目かになる。**★**行に番号は書かれていない**ので、**読んだ順が順番**である。

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readMoveBodies` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readMoveBodies`
- 入口の語: `path`
- もし `一手も無い` なら「空」
- それ以外は「手の中身の並び」
- 出口「空」は `[]` で認める
- 出口「手の中身の並び」は `contains:square` で認める

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readMoveBodies` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

### 4.3 `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect` の処理手順

1. 記録の置き場にある記録を 1 本ずつ、`shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne(path: String) -> GameRecord` で読む
2. 壊れた記録は、**壊れた件数として数える**。中身は使わない
3. 途中で終わった対局は、**使わない**。件数だけ数える
4. 段が、渡された一覧に入っていないものを外す
5. 残ったものと、外した件数・壊れた件数を一緒に返す

★**5 で件数も返す。**使えた数だけを返すと、**分母がこちら側の都合で決まる**。
何本読んで、何本使えて、何本外したかを、呼んだ側が見られるようにする。

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect`
- 入口の語: `levels`, `root`
- もし `使える記録が無い` なら「材料なし」
- それ以外は「集めた記録」
- 出口「材料なし」は `['used']:0` で認める
- 出口「集めた記録」は `['used']:3` で認める

#### `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect` の試験材料

- 入力 `levels=[1, 2, 3, 4], root="runs"` のとき 特徴 `使える記録が無い=False`
- 入力 `levels=[5], root="runs"` のとき 特徴 `使える記録が無い=True`
- 出口「集めた記録」は `['used']:3` で認める
- 出口「材料なし」は `['used']:0` で認める

---

## 5. 並びの順を確かめる — `shared/src/main/kotlin/othello/OthelloLogOrder.kt`

**順の決めを持つのは、このファイルだけ。**

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder(events: List<Event>) -> Order` | 1 本分の並び | 順が正しいかと、崩れている場所 |

★**読む側から切り出した。**読む話と、順の決めは別である。
順を足すときに、読む処理を触らなくて済む。

### 5.2 `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder` の処理手順

1. 最初の 1 件が「対局の始まり」かを見る
2. 2 件目から順に、前の種類から見て来てよい種類かを見る
3. 「対局の終わり」の後に何か来ていないかを見る
4. 崩れていれば、何件目かと一緒に返す

#### `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder`
- 入口の語: `events`
- もし `最初が始まりでない` なら「順が崩れている」
- もし `終わりの後に何か来ている` なら「順が崩れている」
- それ以外は「順は正しい」
- 出口「順が崩れている」は `['ok']:False` で認める
- 出口「順は正しい」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloLogOrder.kt:OthelloLogOrder:checkOrder` の試験材料

- 入力 `events=[{"at": "", "kind": "open", "body": {}}, {"at": "", "kind": "move", "body": {}}, {"at": "", "kind": "close", "body": {}}]` のとき 特徴 `最初が始まりでない=False, 終わりの後に何か来ている=False`
- 入力 `events=[{"at": "", "kind": "move", "body": {}}, {"at": "", "kind": "close", "body": {}}]` のとき 特徴 `最初が始まりでない=True, 終わりの後に何か来ている=False`
- 入力 `events=[{"at": "", "kind": "open", "body": {}}, {"at": "", "kind": "close", "body": {}}, {"at": "", "kind": "move", "body": {}}]` のとき 特徴 `最初が始まりでない=False, 終わりの後に何か来ている=True`
- 出口「順は正しい」は `['ok']:True` で認める
- 出口「順が崩れている」は `['ok']:False` で認める

---

---

## 9z. 呼ぶIF（要求インタフェース）

記法の出どころは**開発環境側の設計書** `DD-L4-integration-contract` §4 である（このアプリの設計書ではないので、二重角括弧で結ばない）。

★**この設計書は、他の設計書の関数を 1 つも呼ばない。**
辺が無いことを、空欄でなく**そう書く**（[[DD-L2-othello]] §1.2 — 盤の規則は呼ばれるだけ）。

## 6. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| 追記だけ。書き換えない | 書く側に、行を書き換える関数が 1 つも無い |
| 待ったも 1 行として残す | `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` の種類に「待った」が在る |
| 1 行 1 件 | `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` が行の終わりまでを 1 回で書く |
| 日時は記録する側が取る | `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:openLog` `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent` `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog` の手順 1 |
| 打ち手に日時を渡さない | 読む側が返す形に、時刻を含めない |
| 記録の失敗で対局を止めない | どれも戻り値で返す。例外を投げない |
| 順を確かめるのは読む側だけ | `shared/src/main/kotlin/othello/OthelloLogOrder.kt` は読む側にある。書く側は順を見ない |
| 壊れた記録を黙って捨てない | `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne` が「壊れている」と返し、`collect` が件数を数える |
| 最強の段を母数から外せる | `collect` が段の一覧で絞る |
| 分母をこちらの都合で決めない | `collect` が、使えた数・外した数・壊れた数を返す |

## 7. 素振り — `shared/src/main/kotlin/othello/OthelloDrill.kt`

★**段 5 の材料は、人との対局では貯まらない。**人の強さはばらばらなので、
**勝率が組の強さを表さない**（[[DD-L3-othello-ai]] §3.4b）。
∴ **段どうしを戦わせて、その記録を材料にする。**

★**1 局では足りない。**打ち手は決定的なので、同じ組み合わせは毎回まったく同じ棋譜になる。
**開幕を変えた盤から、色を入れ替えて戦わせる**（[[DD-L1-othello-ai]] §4.3 と同じ形）。

### 7.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries(pairs: List<Step>, boards: Int, root: String) -> Int` | 戦わせる段の組み合わせ、開幕の数、記録を置くところ | 書いた記録の本数 |
| `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings(count: Int) -> List<State>` | 作る盤の数 | 開幕を変えた盤の並び |
| `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite(frm: State, black: Params, blackLevel: Int, white: Params, whiteLevel: Int, root: String) -> Int` | 開始の盤、黒の組と段、白の組と段、記録を置くところ | 書けたら 1、書けなければ 0 |

★`openDrill` の行は §3.1 に在る（記録を書く仲間なので、そちらに置いた）。

### 7.2 `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill` の処理手順

1. いまの日時から、他と重ならない名前を作る
2. 置き場が無ければ作り、**在ることを確かめる**
3. 「対局の始まり」の 1 行に、★**黒の段と組・白の段と組**を書く
4. 記録の在り処を返す

★**両側を書く。**片側しか書かないと、**どちらの組が勝ったのか、あとから分からない**。

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill`
- 入口の語: `black`, `blackLevel`, `white`, `whiteLevel`, `root`
- もし `置き場が空` なら「書けない」
- それ以外は「開いた」
- 出口「書けない」は `['ok']:False` で認める
- 出口「開いた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill` の試験材料

- 入力 `black={"weight": 0, "moves": 0, "stones": 1, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, blackLevel=1, white={"weight": 1, "moves": 10, "stones": 0, "depth": 4, "endgame": 0, "author": False, "fallback": False, "games": 0}, whiteLevel=4, root=""` のとき 特徴 `置き場が空=True`
- 入力 `black={"weight": 0, "moves": 0, "stones": 1, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, blackLevel=1, white={"weight": 1, "moves": 10, "stones": 0, "depth": 4, "endgame": 0, "author": False, "fallback": False, "games": 0}, whiteLevel=4, root="runs"` のとき 特徴 `置き場が空=False`
- 出口「書けない」は `['ok']:False` で認める
- 出口「開いた」は `['ok']:True` で認める

### 7.3 `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries` の処理手順

1. 段の組み合わせのそれぞれについて、★**置き場を渡して**組を取る（`shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams(level: Int, root: String) -> Params?`）
1a. 開幕を変えた盤を、指定された数だけ作る
1b. 盤を `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings(count: Int) -> List<State>` で作る
2. 段の組み合わせのそれぞれについて、盤のそれぞれから、★**色を入れ替えて 2 局**、`shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite(frm: State, black: Params, blackLevel: Int, white: Params, whiteLevel: Int, root: String) -> Int` を呼ぶ
3. 書いた本数を返す

★★**段 5 を戦わせるときは、置き場を渡す。**空を渡すと**記録を見ない段 5**（＝段 4 と同じ）になり、**段 5 を測ったことにならない**。

★**同じ段どうしは戦わせない。**同じ組の勝敗は、組の優劣を語らない。

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries`
- 入口の語: `pairs`, `boards`, `root`
- もし `置き場が空` なら「1 本も書かない」
- それ以外は「書いた本数」
- 出口「1 本も書かない」は `0` で認める
- 出口「書いた本数」は `regex:^[1-9]` で認める

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries` の試験材料

- 入力 `pairs=[{"row": 1, "col": 4}], boards=1, root=""` のとき 特徴 `置き場が空=True`
- 入力 `pairs=[{"row": 1, "col": 4}], boards=1, root="runs"` のとき 特徴 `置き場が空=False`
- 出口「1 本も書かない」は `0` で認める
- 出口「書いた本数」は `regex:^[1-9]` で認める

### 7.4 `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings` の処理手順

1. 初期配置を 1 つ目に入れる
2. 1 手目の置ける升のそれぞれについて、1 手打つ
3. その盤の 2 手目の置ける升のそれぞれについて、もう 1 手打って並びに足す
4. 指定された数だけ返す

★**開幕を変えるのは、打ち手が決定的だからである。**同じ盤から始めれば、毎回まったく同じ棋譜になる。

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings`
- 入口の語: `count`
- もし `一つでよい` なら「初期配置だけ」
- それ以外は「開幕を変えた並び」
- 出口「初期配置だけ」は `1` で認める
- 出口「開幕を変えた並び」は `regex:^[2-9]` で認める

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

### 7.5 `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite` の処理手順

1. `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openDrill(black: Params, blackLevel: Int, white: Params, whiteLevel: Int, root: String) -> LogHandle` で記録を開く。開けなければ 0 を返す
2. 終局まで、手番の側の組で `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove(board: List<String>, turn: String, params: Params?) -> Chosen` を呼んで打つ
3. 置ける升が無ければ `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn(state: State) -> Played` を呼ぶ
4. 1 手ごとに `shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:appendEvent(log: LogHandle, kind: String, body: Body) -> Written` を呼ぶ
5. 終局したら枚数を数え、`shared/src/main/kotlin/othello/OthelloLogWrite.kt:OthelloLogWrite:closeLog(log: LogHandle, result: Result) -> Written` を呼ぶ
6. 1 を返す

★★**素振りは、遊ぶための道ではない。**画面からは呼ばない。**段 5 の材料を作るためだけ**に在る（[[DD-L3-othello-ai]] §3.4b）。

★**同じ段どうしは戦わせない。**同じ組の勝ち負けは、組の優劣を語らないからである。
★**色を入れ替えて 2 局打つ。**片方の色だけで数えると、**先手の有利が勝率に混ざる**。
★**開幕を変える。**打ち手は決まった手を返すので、同じ盤から始めれば毎回同じ棋譜になり、**何局打っても 1 局と同じことしか分からない**。

★**打ち手に聞く前に、規則が「置ける升が無い」と答える。**打ち手に「打てない」を返させると、
**打てないのか、選べなかったのかが混ざる。**

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite`
- 入口の語: `frm`, `black`, `blackLevel`, `white`, `whiteLevel`, `root`
- もし `置き場が空` なら「書けない」
- それ以外は「1 局書いた」
- 出口「書けない」は `0` で認める
- 出口「1 局書いた」は `1` で認める

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★**この関数だけを撃つ Kotlin の試験がまだ無い**（実測2026-08-15）——★**材料を書いても、当たる先が無ければ試験は落ちる**

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:runSeries` の呼ぶIF

- [[DD-L4-othello-ai]] `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:openings` の呼ぶIF

- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:newState` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloDrill.kt:OthelloDrill:playAndWrite` の呼ぶIF

- [[DD-L4-othello-ai]] `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:play` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloGame.kt:OthelloGame:passTurn` を呼ぶ
- [[DD-L4-othello-play]] `shared/src/main/kotlin/othello/OthelloState.kt:OthelloState:countStones` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ