# DD-L4 関数仕様 — オセロの打ち手

- doc_id : DD-L4-othello-ai ／ design_level : L4 ／ 上位 : [[DD-L3-othello-ai]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料**を定める。
- 出典 : DD-L3-othello-ai §2（受け皿）・§3（データ構造）・§6（概要の手順）
- 呼ぶ相手 : [[DD-L4-othello-rules]]（置ける升・置いた後の盤）・[[DD-L4-othello-log]]（過去の記録）。★**呼び方は、呼ばれる側が決めたものをそのまま使う**

---

## 0. L4 と L5 の役割分担

**全部 L4 に書く。L5 は書かない。**差し込みの口を持たないため。


### 0b. ★言語を移したときに、何が変わって何が変わらなかったか

この一式は、共通の実装を別の言語へ移した（[[DD-L2-othello]] §7z.4）。**そのとき何が動いたかを残す。**

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | どのファイルに何を置くか。1 つも動かしていない |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | 段の並びは 1 つも変えていない |
| 挙動の宣言 | 条件も出口も、認めかたも同じ |
| 試験の材料 | 入力の値も、期待値も同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | 綴りの決まりが違う（区切りの記号と、大文字の使い方） |
| メソッドの名 | 同上 |
| クラスの欄 | 擬似のものから、**実在する入れ物の名**へ |
| 型の名 | その言語の型へ |

★★**設計が言語に依っていなかったことが、ここで確かめられた。**
もし手順や宣言まで書き直す必要が出ていたなら、それは**設計に実装の都合が混ざっていた**ということである。

★**型の名だけは、記法の側の都合で調整した**（下の「型の名に読点を入れない」）。
これは設計の内容ではなく、**書き表し方の問題**である。

## 1. ファイルの分け方 — 上限に張り付かせない

規約は 1 ファイル 5 関数・300 行・ネスト 4 まで。**目安は 3 関数・100 行・ネスト 2。**

| ファイル | 関数 | 行数の見込み | ネスト | 何を持つか |
|:---|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloWeight.kt` | 4 | 約 90 | 2 | 升の重みの表と、位置の点。★**段 6 の点の表と、その合計** |
| `shared/src/main/kotlin/othello/OthelloEval.kt` | 2 | 約 50 | 1 | 置ける手の数と、盤の点数 |
| `shared/src/main/kotlin/othello/OthelloSearch.kt` | 2 | 約 90 | 2 | 1 手先へ進む読みと、最善の升 |
| `shared/src/main/kotlin/othello/OthelloParam.kt` | 2 | 約 70 | 2 | 段ごとのパラメータの表と、記録からの選び出し |
| `shared/src/main/kotlin/othello/OthelloAi.kt` | 1 | 約 40 | 1 | 打ち手の入口 |

★**段を足しても、この 5 ファイルは増えない。**増えるのは `shared/src/main/kotlin/othello/OthelloParam.kt` の表の行だけ。

★**記録に触るのは `shared/src/main/kotlin/othello/OthelloParam.kt` だけ。**残り 4 つは、渡された値だけで動く。
**決定的でない部分を、1 ファイルに閉じ込めてある。**

### 1.1 ★ネストを下げるために分けたところ

読みは、素直に書くと深くなる。「置ける升ごとの繰り返し」の中に「相手の応手の読み」が入り、
さらに条件が重なる。

そこで、**1 手進めて相手の番として読む部分**を、別の関数にした。

| 関数 | 何をするか | ネスト |
|:---|:---|:---|
| `search` | 置ける升を順に見て、相手の番として自分を呼ぶ | 1 |
| `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` | `search` を呼び、升だけを取り出す | 0 |

`search` は自分自身を呼んで深さを 1 つ減らす。**繰り返しの入れ子ではなく、呼び出しの繰り返しにする。**
★**点と升を一緒に返すので、読みは 1 回で済む。**

### 1b. ★書いた後の実測（2026-08-12）

見込みと、実際に書いたものを並べる。**見込みだけ書いて確かめないと、上限に張り付いていないことが言えない。**

| ファイル | 関数（見込み→実測） | 行数（見込み→実測） | ネスト（見込み→実測） |
|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloWeight.kt` | 2 → **2** | 50 → **31** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloEval.kt` | 2 → **2** | 50 → **28** | 1 → **0** |
| `shared/src/main/kotlin/othello/OthelloSearch.kt` | 2 → **2** | 90 → **42** | 2 → **2** |
| `shared/src/main/kotlin/othello/OthelloParam.kt` | 2 → **2** | 70 → **47** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloAi.kt` | 1 → **1** | 40 → **24** | 1 → **1** |

★**行数はどれも見込みより短い。**規約（300 行・5 関数・ネスト 4）にも、目安（3 関数・100 行・ネスト 2）にも、**張り付いていない**。

## 2. 綴りの決め

関数を名指す綴りは、**どこでも `コードファイルの相対パス:クラス:メソッド`**。区切りはすべて `:`。
クラスに属さない関数は `(module)`。系の外は `外`。
引数と戻り値の型は、**表と呼び出しにだけ**書く。


★**分岐の無い関数は、特徴を書かない。**条件が無いのだから、「どの条件を撃ったか」も無い。無いものを埋めるために特徴をこしらえると、**試験が何を確かめているのか分からなくなる**。

★**引数を取らない関数は、材料を書かずに免除にする。**★分類は `other_language` を使う——★**免除の分類は述語で裏付くものだけが効く**（[[DD-L4-dsl-exempt-audit]] §免除の法）。`no_args` の述語は Python の構文木を引くので、この一式（Kotlin）では裏付かない。

---


★★**型の名に読点を入れない。**この記法は引数を読点で区切るので、
`Pair<Int, Int>` のような型をそのまま書くと、**引数が 1 つ増えたように読まれる**。
∴ 読点を含む型には**別名を付けて**使う（`Step`＝向きの組、`Body`＝記録の中身、★`Tally`＝組ごとの数え）。
★**記法が読める形にするのは、書き手の仕事である。**読み手を賢くして解決しない。

## 2a. クラスとメソッド

★**クラスの欄を空にしない。**この一式では、モジュールごとに **`object` を 1 つ**置き、
関数はその中に入る。★**クラス名は、その `object` の名である**（`USER_MANUAL` §3.10・`DesignClass`）。
**「クラスを持たない」という状態は無い。**

| クラス | コードファイル | 親クラス | 属するメソッド |
|:---|:---|:---|:---|
| `OthelloWeight` | `shared/src/main/kotlin/othello/OthelloWeight.kt` | 無し（object） | `weightOf` ・ `positionScore` ・ `authorOf` ・ `authorScore` |
| `OthelloEval` | `shared/src/main/kotlin/othello/OthelloEval.kt` | 無し（object） | `mobility` ・ `evaluate` |
| `OthelloSearch` | `shared/src/main/kotlin/othello/OthelloSearch.kt` | 無し（object） | `search` ・ `bestMove` |
| `OthelloParam` | `shared/src/main/kotlin/othello/OthelloParam.kt` | 無し（object） | `levelParams` ・ `bestParams` ・ `add` |
| `OthelloAi` | `shared/src/main/kotlin/othello/OthelloAi.kt` | 無し（object） | `chooseMove` |

★★**この表と、インタフェース表は別物である。**
ここは**どのクラスにどのメソッドが属するか**を決める表であり、
インタフェース表は各メソッドの**入口と出口の項目**（名前・型・順序）を決める表である。
**所属が無ければ呼び先が解けず、項目が無ければ引数が合っているかを照合できない。**

★**親クラスは持たない。**`object` は継承の木に載らない。★**状態を持たない**ので、包む必要が無い。

## 3. 升の重み — `shared/src/main/kotlin/othello/OthelloWeight.kt`

**升の重みの表を持つのは、このファイルだけ。**

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf(row: Int, col: Int) -> Int` | 行、列 | その升の重み。角は大きく正、角の隣は大きく負 |
| `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore(board: List<String>, turn: String) -> Int` | 盤、手番 | 自分の石の重みの合計から、相手の石の重みの合計を引いた数 |
| `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorOf(row: Int, col: Int) -> Int` | 行、列 | ★**段 6 の点**（[[DD-L3-othello-ai]] §3.1b の表） |
| `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorScore(board: List<String>, turn: String) -> Int` | 盤、手番 | ★**自分の石の点の合計から、相手の石の点の合計を引いた数** |

### 3.2 `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf` の処理手順

1. 行か列が 0 から 7 の外なら、0 を返す
2. 表から、その升の重みを取って返す

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf`
- 入口の語: `row`, `col`
- もし `盤の外` なら「重みなし」
- それ以外は「その升の重み」
- 出口「重みなし」は `0` で認める
- 出口「その升の重み」は `120` で認める

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf` の試験材料

- 入力 `row=0, col=0` のとき 特徴 `盤の外=False`
- 入力 `row=9, col=0` のとき 特徴 `盤の外=True`
- 出口「その升の重み」は `120` で認める
- 出口「重みなし」は `0` で認める

### 3.3 `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore` の処理手順

1. 盤の全ての升を 1 つずつ見る
2. 自分の石なら `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf(row: Int, col: Int) -> Int` の値を足す
3. 相手の石なら同じ値を引く
4. 合計を返す

★**手番の側から見た点にする。**黒から見た点で通すと、白の番のたびに符号を入れ替える場所が増える。

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore`
- 入口の語: `board`, `turn`
- もし `両者の重みが釣り合う` なら「差なし」
- それ以外は「位置の点」
- 出口「差なし」は `0` で認める
- 出口「位置の点」は `regex:^-?\d+$` で認める

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B"` のとき 特徴 `両者の重みが釣り合う=True`
- 入力 `board=["B.......", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B"` のとき 特徴 `両者の重みが釣り合う=False`
- 出口「差なし」は `0` で認める
- 出口「位置の点」は `regex:^-?\d+$` で認める

---

### 3.3 `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorOf` の処理手順

1. 段 6 の表（[[DD-L3-othello-ai]] §3.1b）の、その行・その列を引く
2. 引いた点を返す

★★**式で作らない。**この表は**利用者が升ごとに与えたもの**であって、
距離や歩数から導けるものではない。★**実測 2026-08-13**: 歩数の式で作ろうとして 3 度読み違えた。
**与えられた表は、表のまま持つ。**

★**表は 1 か所にだけ持つ**（[[DD-L3-othello]] §3.3 の「2 か所に書かない」と同じ理由）。

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorOf` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorOf`
- 入口の語: `row`, `col`
- もし `隅` なら「いちばん高い」
- もし `隅に接する` なら「大きく負」
- それ以外は「表の点」
- 出口「いちばん高い」は `10` で認める
- 出口「大きく負」は `-9` で認める
- 出口「表の点」は `regex:^-?[468]$` で認める

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorOf` の試験材料

- 入力 `row=0, col=0` のとき 特徴 `隅=True`
- 入力 `row=1, col=1` のとき 特徴 `隅=False, 隅に接する=True`
- 入力 `row=0, col=2` のとき 特徴 `隅=False, 隅に接する=False`
- 出口「いちばん高い」は `10` で認める
- 出口「大きく負」は `-9` で認める
- 出口「表の点」は `regex:^-?[468]$` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorScore` の処理手順

1. 盤の升を 1 つずつ見る
2. 自分の石なら、その升の点を足す
3. 相手の石なら、その升の点を引く
4. 合計を返す

★**石の数も、置ける升の数も見ない。**段 6 は**この表だけ**が決めである
（[[DD-L3-othello-ai]] §3.1b）。

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorScore` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorScore`
- 入口の語: `board`, `turn`
- もし `石が1つも無い` なら「差は無い」
- それ以外は「差」
- 出口「差は無い」は `0` で認める
- 出口「差」は `regex:^-?\d+$` で認める

#### `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:authorScore` の試験材料

- 入力 `board=["........", "........", "........", "........", "........", "........", "........", "........"], turn="B"` のとき 特徴 `石が1つも無い=True`
- 入力 `board=["B.......", "........", "........", "........", "........", "........", "........", "........"], turn="B"` のとき 特徴 `石が1つも無い=False`
- 出口「差は無い」は `0` で認める
- 出口「差」は `regex:^-?\d+$` で認める

## 4. 盤の点数 — `shared/src/main/kotlin/othello/OthelloEval.kt`

盤の良さを 1 つの数にする。**何を見るかは、渡された語で決める。**

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility(board: List<String>, turn: String) -> Int` | 盤、手番 | 自分が置ける升の数から、相手が置ける升の数を引いた数 |
| `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate(board: List<String>, turn: String, params: Params) -> Int` | 盤、手番、パラメータの組 | 盤の良さ。手番の側から見た点 |

### 4.2 `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility` の処理手順

1. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を自分の手番で呼ぶ
2. 同じものを相手の手番で呼ぶ
3. 自分の置ける升の数から、相手の置ける升の数を引いて返す

#### `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility`
- 入口の語: `board`, `turn`
- もし `盤に石が無い` なら「どちらも置けない」
- それ以外は「手の数の差」
- 出口「どちらも置けない」は `0` で認める
- 出口「手の数の差」は `regex:^-?\d+$` で認める

#### `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility` の試験材料

- 入力 `board=["........", "........", "........", "........", "........", "........", "........", "........"], turn="B"` のとき 特徴 `盤に石が無い=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B"` のとき 特徴 `盤に石が無い=False`
- 出口「どちらも置けない」は `0` で認める
- 出口「手の数の差」は `regex:^-?\d+$` で認める

### 4.3 `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate` の処理手順

1. 点を 0 から始める
2. `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:positionScore(board: List<String>, turn: String) -> Int` を呼び、**重みの係数を掛けて**足す
3. `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility(board: List<String>, turn: String) -> Int` を呼び、**手の数の係数を掛けて**足す
4. 自分の石の数から相手の石の数を引き、**枚数の係数を掛けて**足す
5. 合計を返す

★**語で切り替えず、係数を掛ける。**係数が 0 なら効かない。
**語の組み合わせを探す形にすると、記録から選ぶときに比べられなくなる**（数なら比べられる）。

★**繰り返しも入れ子も無い。**見方が増えても、行が 1 つ増えるだけである。

#### `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate`
- 入口の語: `board`, `turn`, `params`
- もし `係数が全部0` なら「点なし」
- それ以外は「盤の点」
- 出口「点なし」は `0` で認める
- 出口「盤の点」は `0` で認める

#### `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", params={"weight": 0, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}` のとき 特徴 `係数が全部0=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", params={"weight": 1, "moves": 10, "stones": 0, "depth": 4, "endgame": 0, "author": False, "fallback": False, "games": 0}` のとき 特徴 `係数が全部0=False`
- 出口「点なし」は `0` で認める
- 出口「盤の点」は `0` で認める

---

## 5. 先読み — `shared/src/main/kotlin/othello/OthelloSearch.kt`

決めた深さまで読む。★**手を選ぶことと点を出すことを、同じ 1 回の読みで行う**（[[DD-L3-othello-ai]] §3.3）。

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search(board: List<String>, turn: String, depth: Int, params: Params, alpha: Int, beta: Int, until: Long) -> Searched` | 盤、手番、残りの深さ、パラメータ、枝刈りの下限と上限、★**打ち切りの時刻** | ★**点と升を一緒に**返す器。点は**その盤で手番の側から見た数** |
| `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove(board: List<String>, turn: String, depth: Int, params: Params, alpha: Int, beta: Int, until: Long) -> String` | 同上 | 最も良い升。置ける升が無ければ空 |

★★**`score_after` は廃止した。**手を選ぶ読みと、点を出す読みが別々になっていたためである。
分けると**同じ枝を 2 度読む**うえ、枝刈りの上下限が別々に効いて、
**選んだ手と返す点が別々の読みの結果**になりうる。

★**深さは 1 手が 1。**深さ 0 は「読まずに、その盤をそのまま点にする」。

### 5.2 `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search` の処理手順

1. 深さが0 なら `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:evaluate(board: List<String>, turn: String, params: Params) -> Int` を呼び、その点と**空の升**を返す
2. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を呼ぶ
3. 置ける升が 1 つも無ければ、同じく `evaluate` を呼び、その点と**空の升**を返す
4. 置ける升を**升の順**に並べる
5. それぞれについて `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove(board: List<String>, move: String, turn: String) -> List<String>` で新しい盤を作り、**相手の番**として `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search(board: List<String>, turn: String, depth: Int, params: Params, alpha: Int, beta: Int, until: Long) -> Searched` を、深さを 1 減らし**上下限を入れ替えて**呼び、返った点の**符号を反転する**
6. その点が下限より高ければ、最良の升と点を入れ替える。★**同点なら入れ替えない**
7. 下限が上限以上になったら、そこで止める
8. 最良の点と升を、器に入れて返す

★**5 の反転を落とさない。**落とすと、**相手にとって良い手を、自分にとって良い手として選ぶ**。
エラーは出ない。ただ弱くなるだけなので、対局してみるまで気付けない。

★**6 の「同点なら入れ替えない」が、升の順を効かせている。**並べる順を決めずに最大を取ると、
点数が並んだ瞬間に非決定になる。★**この決めは読みの全段で効く。**

★**渡された盤は書き換えない。**規則が新しい盤を返すので、戻す処理が要らない。

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search`
- 入口の語: `board`, `turn`, `depth`, `params`, `alpha`, `beta`, `until`
- もし `深さが0` なら「読まずの点」
- もし `置ける升が無い` なら「読まずの点」
- それ以外は「読んだ点と升」
- 出口「読まずの点」は `['move']:regex:^$` で認める
- 出口「読んだ点と升」は `['move']:c4` で認める

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", depth=0, params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, alpha=-100000, beta=100000` のとき 特徴 `深さが0=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", depth=1, params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, alpha=-100000, beta=100000` のとき 特徴 `深さが0=False, 置ける升が無い=False`
- 入力 `board=["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], turn="W", depth=1, params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, alpha=-100000, beta=100000` のとき 特徴 `置ける升が無い=True`
- 出口「読んだ点と升」は `['move']:c4` で認める
- 出口「読まずの点」は `['move']:regex:^$` で認める

### 5.3 `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` の処理手順

1. `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search(board: List<String>, turn: String, depth: Int, params: Params, alpha: Int, beta: Int, until: Long) -> Searched` を呼ぶ
2. 返った器から升を取り出して返す

★**この関数は読みを持たない。**升だけが欲しい呼び手のための口である。

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove`
- 入口の語: `board`, `turn`, `depth`, `params`, `alpha`, `beta`, `until`
- もし `置ける升が無い` なら「置けない」
- それ以外は「最も良い升」
- 出口「置けない」は `regex:^$` で認める
- 出口「最も良い升」は `c4` で認める

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", depth=1, params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, alpha=-100000, beta=100000` のとき 特徴 `置ける升が無い=False`
- 入力 `board=["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], turn="W", depth=1, params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, alpha=-100000, beta=100000` のとき 特徴 `置ける升が無い=True`
- 出口「最も良い升」は `c4` で認める
- 出口「置けない」は `regex:^$` で認める

---

## 6. パラメータを選ぶ — `shared/src/main/kotlin/othello/OthelloParam.kt`

**段ごとのパラメータの表を持つのは、このファイルだけ。**そして、★**記録に触るのもここだけ。**

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams(level: Int, root: String) -> Params?` | 段（1 から 6）、記録の置き場 | パラメータの組。段が範囲の外なら空の器 |
| `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:add(tally: Tally, key: Params, won: Int) -> Unit` | 組ごとの数え、組、勝ったか | ★**その組に、勝ち数と局数を 1 つずつ積む**（戻り値は無し） |
| `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams(root: String) -> Params?` | 記録の置き場 | 記録の中で勝率が最も高かった組。★**選ぶのに使った対局の数と、選べたかどうかを添える**。選べなければ空の器 |

### 6.2 `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams` の処理手順

1. 段が 1 から 6 の外なら、空の器を返す
2. 段が 5 なら `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams(root: String) -> Params?` を呼ぶ
3. 空の器が返ったら、段 4 の組をそのまま使い、**選べなかったという印を付ける**
4. 段が 1 から 4 なら、表からその段の組を返す

★**近い段に丸めない。**6 を渡されたら 5 として扱う作りにすると、**呼ぶ側の間違いが黙って通る**。

★**3 で段 4 に落とすとき、印を付ける。**黙って落とすと、記録には「段 5 で打った」と残るのに
**中身は段 4** という食い違いができる。

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams`
- 入口の語: `level`, `root`
- もし `段が範囲の外` なら「設定なし」
- もし `段が5で選べない` なら「段 4 に落とした組」
- それ以外は「段の組」
- 出口「設定なし」は `is_none` で認める
- 出口「段 4 に落とした組」は `['fallback']:True` で認める
- 出口「段の組」は `['depth']:4` で認める

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:levelParams` の試験材料

- 入力 `level=4, root="runs"` のとき 特徴 `段が範囲の外=False, 段が5で選べない=False`
- 入力 `level=9, root="runs"` のとき 特徴 `段が範囲の外=True`
- 入力 `level=5, root="runs"` のとき 特徴 `段が範囲の外=False, 段が5で選べない=True`
- 出口「段の組」は `['depth']:4` で認める
- 出口「設定なし」は `is_none` で認める
- 出口「段 4 に落とした組」は `['fallback']:True` で認める

### 6.2b `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:add` の処理手順

1. その組が、まだ数えに無ければ 0 勝 0 局として置く
2. 勝ったなら勝ち数に 1 を足す
3. 局数に 1 を足す

★**積むところを 1 か所にする。**段どうしの対局と、人と計算機の対局で**2 度書くと、
片方だけ直す事故**が起きる（[[DD-L3-othello-ai]] §3.4b）。

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:add` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:add`
- 入口の語: `tally`, `key`, `won`
- もし `まだ数えに無い` なら「置いて積む」
- それ以外は「積む」
- 出口「置いて積む」は `is_none` で認める
- 出口「積む」は `is_none` で認める

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:add` の試験材料

- 入力 `tally=[], key={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, won=1` のとき 特徴 `まだ数えに無い=True`
- 入力 `tally=[[{"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, [1, 1]]], key={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}, won=0` のとき 特徴 `まだ数えに無い=False`
- 出口「置いて積む」は `is_none` で認める
- 出口「積む」は `is_none` で認める

### 6.3 `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams` の処理手順

1. `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect(levels: List<Int>, root: String) -> Collected` を、★**段 1 から 4 だけ**を指定して呼ぶ
2. 使えた対局が 1 本も無ければ、空の器を返す
3. 同じパラメータの組ごとに、勝った数と、終わった対局の数を数える
4. ★**勝率**（勝った数 ÷ 終わった対局の数）が最も高い組を選ぶ
5. 同率なら、対局の数が多いほうを選ぶ。それも同じなら、先に出てきたほうを残す
6. 選んだ組を返す

★**1 で段 5 を外すのが、この関数の要点である。**外さないと、
**自分が選んだ組の結果を、自分を裏付ける証拠として使う**ことになる。

★**5 の同率の決め方を書いておく。**書かないと、記録の並び順が変わるたびに選ばれる組が変わる。

★★**勝ちは「計算機が受け持った側の勝ち」で数える**（[[DD-L3-othello-ai]] §3.4b）。黒の勝ちで数えると、★**計算機が白のときだけ、勝ちが負けになる**。

★**両方とも計算機の対局は使わない。**同じ組どうしなので、組の優劣を語らない。
★**添える対局の数は、こうして残った数**である。

★★**材料は DB へ問い合わせて集める**（CR-11）。**全部読んで数え直さない**——記録が増えるほど重くなるからである。
★**DB に 1 本も入っていなければ、ファイルの記録を読む**——**両方に在るときは DB を見る**（CR-11 の 11-2）。

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams`
- 入口の語: `root`
- もし `使える記録が無い` なら「選べない」
- それ以外は「最も勝率の高い組」
- 出口「選べない」は `is_none` で認める
- 出口「最も勝率の高い組」は `['depth']:4` で認める

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★中身としても過去の記録を読むので、**記録を読む側（[[DD-L4-othello-log]]）で確かめる**——ここで模した記録を置くと、**読み出しの決めが 2 か所に生まれる**

---

## 7. 打ち手の入口 — `shared/src/main/kotlin/othello/OthelloAi.kt`

**パラメータを受け取り、升を 1 つ返す。**★**記録も段も知らない。**

### 7.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove(board: List<String>, turn: String, params: Params?) -> Chosen` | 盤、手番、パラメータの組 | 次に置く升と、決められたかどうか |

★**この表が、呼ばれ方の定めである。**呼ぶ側（`shared/src/main/kotlin/othello/OthelloTurn.kt`）は、この形をそのまま使う。

★**段ではなくパラメータを受け取る。**段のままだと、段 5 の手が記録の増減で変わり、
**同じ盤面に同じ手**が崩れる。**この関数は、同じパラメータなら必ず同じ升を返す。**

★**戻り値を升そのものにせず器にした。**「置けないので手が無い」と
「パラメータが空で決められない」を、呼んだ側が言い分けられるようにするためである。

### 7.2 `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` の処理手順

1. パラメータが空の器なら、決められないと分かる形で返す
2. `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を呼ぶ
3. 置ける升が 1 つも無ければ、手が無いと分かる形で返す
4. 空いている升の数が、パラメータの「読み切りに入る空きの数」以下なら、深さを空きの数に置き換える
4b. ★**打ち切りの時刻を作る**——いまから 5 秒後（[[DD-L1-othello-ai]] §4.4）
5. `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove(board: List<String>, turn: String, depth: Int, params: Params, alpha: Int, beta: Int, until: Long) -> String` を、上下限を目一杯に開いて呼ぶ
6. 返った升を器に入れて返す

★**4 が終盤の読み切りである。**深さを増やすのではなく、**残りの空きの数と同じにする**。
こうすると、終局まで読み切ったことが数で分かる。

#### `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove`
- 入口の語: `board`, `turn`, `params`
- もし `パラメータが空` なら「決められない」
- もし `置ける升が無い` なら「手が無い」
- それ以外は「次の手」
- 出口「決められない」は `['ok']:False` で認める
- 出口「手が無い」は `['move']:regex:^$` で認める
- 出口「次の手」は `['move']:c4` で認める

#### `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}` のとき 特徴 `パラメータが空=False, 置ける升が無い=False`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B", params=None` のとき 特徴 `パラメータが空=True`
- 入力 `board=["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], turn="W", params={"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}` のとき 特徴 `置ける升が無い=True`
- 出口「次の手」は `['move']:c4` で認める
- 出口「決められない」は `['ok']:False` で認める
- 出口「手が無い」は `['move']:regex:^$` で認める

---

## 9z. 呼ぶIF（要求インタフェース）

記法の出どころは**開発環境側の設計書** `DD-L4-integration-contract` §4 である（このアプリの設計書ではないので、二重角括弧で結ばない）。

> 本節はインタフェース表（＝**呼ばれるIF**）の**対**である。契約は相手の設計書の表に既に書かれているので、
> **二重に持たない**——宣言するのは**辺だけ**である。契約も、呼ぶ順序も、ここには書かない。

★**同じ設計書の中の呼び出しは、ここに書かない。**相手の表が同じ本の中に在るので、辺を宣言する相手がいない。
書くのは**設計書をまたぐ依存**だけである。

#### `shared/src/main/kotlin/othello/OthelloAi.kt:OthelloAi:chooseMove` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloEval.kt:OthelloEval:mobility` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams` の呼ぶIF

- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:collect` を呼ぶ
- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` を呼ぶ
- [[DD-L4-othello-log]] `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames` を呼ぶ

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` の呼ぶIF

★**他の設計書を呼ばない。**同じ設計書の `search` を呼ぶだけの口である。

#### `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:search` の呼ぶIF

- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` を呼ぶ
- [[DD-L4-othello-rules]] `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove` を呼ぶ

| 決め | どこで守っているか |
|:---|:---|
| 同じパラメータなら同じ手を返す | 乱数を使わない。`shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` が升の順に並べて、同点なら入れ替えない |
| 決定的でない部分を 1 か所に閉じ込める | ★記録に触るのは `shared/src/main/kotlin/othello/OthelloParam.kt` だけ |
| 枝刈りは結果を変えない | `shared/src/main/kotlin/othello/OthelloSearch.kt:OthelloSearch:bestMove` の手順 6。浅い深さで有無を切り替えて確かめられる |
| 段が上がるほど強い（未確認） | `level_config` の表で、深さと見るものが単調に増える |
| 段を足しても、コードは増えない | 増えるのは `shared/src/main/kotlin/othello/OthelloParam.kt` の表の行だけ |
| 升の重みの表は 1 か所 | `shared/src/main/kotlin/othello/OthelloWeight.kt` だけが持つ |
| 段の表は 1 か所 | `shared/src/main/kotlin/othello/OthelloParam.kt` だけが持つ |
| 段 5 の対局を母数から外す | `shared/src/main/kotlin/othello/OthelloParam.kt:OthelloParam:bestParams` が段 1〜4 だけを指定して記録を読む |
| 盤を書き換えない | 規則が新しい盤を返す。読みの中でも戻す処理が要らない |
| 呼ばれ方は呼ばれる側が決める | §6.1 のインタフェース表が定め |

★**「段が上がるほど強い」は未確認である。**段どうしを戦わせて確かめるまで、そう書いておく。
確かめる方法は [[DD-L1-othello-ai]] §4.3 に決めてある。
