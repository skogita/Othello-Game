# DD-L4 関数仕様 — 打ち手（Flutter 版）

- doc_id : DD-L4-othello-flutter-ai ／ design_level : L4 ／ 上位 : [[DD-L3-othello-ai]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **打ち手**（升の重み・盤の良さ・読み・段の組・次の手）を、**Dart／Flutter の側**で持つ
- 出典 : [[DD-L3-othello-ai]] §3.1・§3.1b・§3.2・§6.1
- 呼ぶ相手 : `flutter/lib/othello_rules.dart`（置ける升・置く）

---

## 0. なぜこの設計書が要るか

★★**Flutter 版のコードを、どの設計書も名乗っていなかった。**
[[DD-L4-othello-ai]] が名乗るのは Kotlin のファイルであって、`flutter/lib/*.dart` ではない。
★**姉妹として分ける**。★**対象コードが違うので二重所有にならない。**

## 0b. 言語を移したときに、何が変わって何が変わらなかったか

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | **1 つも動かしていない** |
| 2 つの表の値 | ★**1 つも変えていない** |
| 処理手順 | ★**段の並びは 1 つも変えていない** |
| 挙動の宣言・試験の材料 | 同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | `OthelloWeight.kt` から `othello_weight.dart` へ |
| 時刻の渡し方 | ★**いまの時刻を、引数で渡す形にした**（§7.2 の注） |

## 0c. この版で持っていないもの

★★**段 5（記録から選ぶ）は持っていない。**★記録の読み書きが要るためである。
★**段 5 を渡されたら、段 4 の組を返し、「選べなかった」の印を立てる。**
★★**黙って落とさない。**★印が無いと、記録には「段 5 で打った」と残るのに
**中身は段 4** という食い違いができる。

## 1. ファイルの分け方

| Dart のファイル | 何を持つか |
|:---|:---|
| `flutter/lib/othello_weight.dart` | ★**2 つの表**と、盤を点にする 2 つ |
| `flutter/lib/othello_param.dart` | 段ごとの組 |
| `flutter/lib/othello_eval.dart` | 置ける升の数の差・盤の良さ |
| `flutter/lib/othello_search.dart` | 読み・最良の升 |
| `flutter/lib/othello_ai.dart` | 次の手を決める |

★**実測（2026-08-23）**: 5 本とも **5 関数以内**、**81 行以内**。

## 2. 綴りの決め

名指しは**三要素**で書く。クラスの欄は実在する入れ物の名を書く。

## 3. 升の重み — `flutter/lib/othello_weight.dart`

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_weight.dart:OthelloWeight:weightOf(row: int, col: int) -> int` | 行、列 | その升の重み。角は大きく正、角の隣は大きく負 |
| `flutter/lib/othello_weight.dart:OthelloWeight:authorOf(row: int, col: int) -> int` | 行、列 | ★**段 6 の点** |
| `flutter/lib/othello_weight.dart:OthelloWeight:positionScore(board: List<String>, turn: String) -> int` | 盤、手番 | 自分の石の重みの合計から、相手の石の重みの合計を引いた数 |
| `flutter/lib/othello_weight.dart:OthelloWeight:authorScore(board: List<String>, turn: String) -> int` | 盤、手番 | 自分の石の点の合計から、相手の石の点の合計を引いた数 |

### 3.2 `flutter/lib/othello_weight.dart:OthelloWeight:weightOf` の処理手順

1. 行か列が 0 から 7 の外なら、0 を返す
2. 表から、その升の重みを取って返す

★★**表を 2 か所に書かない。**★片方の角の隣の符号を書き間違えると、
**その段だけが静かに弱くなる**。弱くなったことは、対局してみるまで分からない。

#### `flutter/lib/othello_weight.dart:OthelloWeight:weightOf` の挙動宣言

- 対象コード: `flutter/lib/othello_weight.dart:OthelloWeight:weightOf`
- 入口の語: `weightOf`
- もし 行か列が盤の外 なら「0」
- それ以外は「重み」
- 出口「0」は `contains:False` で認める
- 出口「重み」は `contains:True` で認める

#### `flutter/lib/othello_weight.dart:OthelloWeight:weightOf` の試験材料

- 入力 `row=0, col=0` のとき 特徴 `重み=120`
- 入力 `row=1, col=1` のとき 特徴 `重み=-40`
- 入力 `row=-1, col=0` のとき 特徴 `重み=0`

### 3.3 `flutter/lib/othello_weight.dart:OthelloWeight:authorOf` の処理手順

1. 段 6 の表の、その行・その列を引く
2. 引いた点を返す

★★**式で作らない。**★この表は**利用者が升ごとに与えたもの**であって、
距離や歩数から導けるものではない。★**実測 2026-08-13: 歩数の式で作ろうとして 3 度読み違えた。**
★**与えられた表は、表のまま持つ。**

#### `flutter/lib/othello_weight.dart:OthelloWeight:authorOf` の挙動宣言

- 対象コード: `flutter/lib/othello_weight.dart:OthelloWeight:authorOf`
- 入口の語: `authorOf`
- もし 行か列が盤の外 なら「0」
- それ以外は「点」
- 出口「0」は `contains:False` で認める
- 出口「点」は `contains:True` で認める

#### `flutter/lib/othello_weight.dart:OthelloWeight:authorOf` の試験材料

- 入力 `row=0, col=0` のとき 特徴 `点=25`
- 入力 `row=0, col=1` のとき 特徴 `点=-16`
- 入力 `row=0, col=3` のとき 特徴 `点=-1`
- 入力 `row=2, col=2` のとき 特徴 `点=9`

### 3.4 `flutter/lib/othello_weight.dart:OthelloWeight:positionScore` の処理手順

1. 盤の全ての升を 1 つずつ見る
2. 自分の石なら重みを足す
3. 相手の石なら同じ値を引く
4. 合計を返す

★**手番の側から見た点にする。**★黒から見た点で通すと、白の番のたびに符号を入れ替える場所が増える。

#### `flutter/lib/othello_weight.dart:OthelloWeight:positionScore` の挙動宣言

- 対象コード: `flutter/lib/othello_weight.dart:OthelloWeight:positionScore`
- 入口の語: `positionScore`
- 分岐は無い
- 出口「点」は `contains:True` で認める

#### `flutter/lib/othello_weight.dart:OthelloWeight:positionScore` の試験材料

- 入力 `board=初期配置, turn="B"` のとき 特徴 `点=0`

### 3.5 `flutter/lib/othello_weight.dart:OthelloWeight:authorScore` の処理手順

1. 盤の升を 1 つずつ見る
2. 自分の石なら、その升の点を足す
3. 相手の石なら、その升の点を引く
4. 合計を返す

★★**石の数も、置ける升の数も見ない。**★段 6 は**この表だけ**が決めである。

#### `flutter/lib/othello_weight.dart:OthelloWeight:authorScore` の挙動宣言

- 対象コード: `flutter/lib/othello_weight.dart:OthelloWeight:authorScore`
- 入口の語: `authorScore`
- 分岐は無い
- 出口「点」は `contains:True` で認める

#### `flutter/lib/othello_weight.dart:OthelloWeight:authorScore` の試験材料

- 入力 `board=初期配置, turn="B"` のとき 特徴 `点=0`

## 4. 段ごとの組 — `flutter/lib/othello_param.dart`

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_param.dart:OthelloParam:levelParams(level: int) -> Params?` | 段（1 から 6） | パラメータの組。段が範囲の外なら持たない |

### 4.2 `flutter/lib/othello_param.dart:OthelloParam:levelParams` の処理手順

1. 段が 1 から 6 の外なら、持たないことが分かる形で返す
2. 段が 5 なら、★**段 4 の組を返し、「選べなかった」の印を立てる**
3. 段が 6 なら、★**著者方式の印を立てた組**を返す
4. 段が 1 から 4 なら、表からその段の組を返す

★★**近い段に丸めない。**★6 を渡されたら 5 として扱う作りにすると、
**呼ぶ側の間違いが黙って通る**。

★**表**（[[DD-L3-othello-ai]] §3.2 と同じ値）:

| 段 | 重み | 手の数 | 枚数 | 深さ | 読み切り |
|:---|---:|---:|---:|---:|---:|
| 1 | 0 | 0 | 1 | 1 | 0 |
| 2 | 0 | 0 | 0 | 1 | 0 |
| 3 | 1 | 0 | 0 | 1 | 0 |
| 4 | 1 | 10 | 0 | 4 | 0 |
| 6 | 著者方式の表 | | | 4 | |

#### `flutter/lib/othello_param.dart:OthelloParam:levelParams` の挙動宣言

- 対象コード: `flutter/lib/othello_param.dart:OthelloParam:levelParams`
- 入口の語: `levelParams`
- もし 段が範囲の外 なら「無し」
- もし 段が 5 なら「落とした組」
- もし 段が 6 なら「著者方式の組」
- それ以外は「表の組」
- 出口「無し」は `is_none` で認める
- 出口「落とした組」は `contains:True` で認める
- 出口「著者方式の組」は `contains:True` で認める
- 出口「表の組」は `contains:True` で認める

#### `flutter/lib/othello_param.dart:OthelloParam:levelParams` の試験材料

- 入力 `level=0` のとき 特徴 `無し=True`
- 入力 `level=7` のとき 特徴 `無し=True`
- 入力 `level=1` のとき 特徴 `枚数=1`・`深さ=1`
- 入力 `level=4` のとき 特徴 `重み=1`・`手の数=10`・`深さ=4`
- 入力 `level=5` のとき 特徴 `落とした=True`
- 入力 `level=6` のとき 特徴 `著者方式=True`・`深さ=4`

## 5. 盤の良さ — `flutter/lib/othello_eval.dart`

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_eval.dart:OthelloEval:mobility(board: List<String>, turn: String) -> int` | 盤、手番 | 自分が置ける升の数から、相手が置ける升の数を引いた数 |
| `flutter/lib/othello_eval.dart:OthelloEval:evaluate(board: List<String>, turn: String, params: Params) -> int` | 盤、手番、パラメータの組 | 盤の良さ。手番の側から見た点 |

### 5.2 `flutter/lib/othello_eval.dart:OthelloEval:mobility` の処理手順

1. 置ける升を自分の手番で聞く
2. 同じものを相手の手番で聞く
3. 自分の数から相手の数を引いて返す

#### `flutter/lib/othello_eval.dart:OthelloEval:mobility` の挙動宣言

- 対象コード: `flutter/lib/othello_eval.dart:OthelloEval:mobility`
- 入口の語: `mobility`
- 分岐は無い
- 出口「差」は `contains:True` で認める

#### `flutter/lib/othello_eval.dart:OthelloEval:mobility` の試験材料

- 入力 `board=初期配置, turn="B"` のとき 特徴 `差=0`

### 5.3 `flutter/lib/othello_eval.dart:OthelloEval:evaluate` の処理手順

1. ★**著者方式の印が立っていれば、`authorScore` の点だけを返す**
2. 点を 0 から始める
3. `positionScore` を呼び、**重みの係数を掛けて**足す
4. `mobility` を呼び、**手の数の係数を掛けて**足す
5. 自分の石の数から相手の石の数を引き、**枚数の係数を掛けて**足す
6. 合計を返す

★★**語で切り替えず、係数を掛ける。**★係数が 0 なら効かない。
★**語の組み合わせを探す形にすると、記録から選ぶときに比べられなくなる**（数なら比べられる）。

★**繰り返しも入れ子も無い。**★見方が増えても、行が 1 つ増えるだけである。

#### `flutter/lib/othello_eval.dart:OthelloEval:evaluate` の挙動宣言

- 対象コード: `flutter/lib/othello_eval.dart:OthelloEval:evaluate`
- 入口の語: `evaluate`
- もし 著者方式の印が立っている なら「著者方式の点」
- それ以外は「係数を掛けた点」
- 出口「著者方式の点」は `contains:True` で認める
- 出口「係数を掛けた点」は `contains:True` で認める

#### `flutter/lib/othello_eval.dart:OthelloEval:evaluate` の試験材料

- 入力 `board=初期配置, turn="B", params=段 4 の組` のとき 特徴 `点=0`
- 入力 `board=初期配置, turn="B", params=段 6 の組` のとき 特徴 `点=0`

## 6. 読み — `flutter/lib/othello_search.dart`

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_search.dart:OthelloSearch:search(board: List<String>, turn: String, depth: int, params: Params, alpha: int, beta: int, until: int) -> Searched` | 盤、手番、深さ、組、下限、上限、打ち切りの時刻 | 最良の点と、そのときの升 |
| `flutter/lib/othello_search.dart:OthelloSearch:bestMove(board: List<String>, turn: String, depth: int, params: Params, alpha: int, beta: int, until: int) -> String` | 同上 | 最良の升だけ |

### 6.2 `flutter/lib/othello_search.dart:OthelloSearch:search` の処理手順

1. 深さが 0 なら `evaluate` を呼び、その点と**空の升**を返す
2. 置ける升を聞く
3. 置ける升が 1 つも無ければ、同じく `evaluate` を呼び、その点と**空の升**を返す
4. 置ける升を**升の順**に並べる
5. それぞれについて置いた盤を作り、相手の手番で読み、★**点の符号を入れ替える**
6. その点が下限より高ければ、最良の升と点を入れ替える。★**同点なら入れ替えない**
7. 下限が上限以上になったら、そこで止める
8. 最良の点と升を、器に入れて返す

★★**5 の反転を落とさない。**★落とすと、**相手にとって良い手を、自分にとって良い手として選ぶ**。
★**エラーは出ない。**ただ弱くなるだけなので、対局してみるまで気付けない。

★★**6 の「同点なら入れ替えない」が、升の順を効かせている。**★並べる順を決めずに最大を取ると、
点数が並んだ瞬間に非決定になる。★**この決めは読みの全段で効く。**

★**渡された盤は書き換えない。**規則が新しい盤を返すので、戻す処理が要らない。

#### `flutter/lib/othello_search.dart:OthelloSearch:search` の挙動宣言

- 対象コード: `flutter/lib/othello_search.dart:OthelloSearch:search`
- 入口の語: `search`
- もし 深さが 0 なら「葉の点」
- もし 置ける升が 1 つも無い なら「葉の点」
- それ以外は「最良の升と点」
- 出口「葉の点」は `contains:False` で認める
- 出口「最良の升と点」は `contains:True` で認める

#### `flutter/lib/othello_search.dart:OthelloSearch:search` の試験材料

- 入力 `board=初期配置, turn="B", depth=0, params=段 4 の組` のとき 特徴 `升=""`
- 入力 `board=初期配置, turn="B", depth=1, params=段 4 の組` のとき 特徴 `升が置ける升の中=True`

### 6.3 `flutter/lib/othello_search.dart:OthelloSearch:bestMove` の処理手順

1. `search` を呼ぶ
2. 返った器から升を取り出して返す

★**この関数は読みを持たない。**★升だけが欲しい呼び手のための口である。

#### `flutter/lib/othello_search.dart:OthelloSearch:bestMove` の挙動宣言

- 対象コード: `flutter/lib/othello_search.dart:OthelloSearch:bestMove`
- 入口の語: `bestMove`
- 分岐は無い
- 出口「升」は `contains:True` で認める

#### `flutter/lib/othello_search.dart:OthelloSearch:bestMove` の試験材料

- 入力 `board=初期配置, turn="B", depth=1, params=段 4 の組` のとき 特徴 `升が置ける升の中=True`

## 7. 次の手 — `flutter/lib/othello_ai.dart`

### 7.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_ai.dart:OthelloAi:chooseMove(board: List<String>, turn: String, params: Params?, nowMs: int) -> Chosen` | 盤、手番、パラメータの組、いまの時刻 | 次に置く升と、決められたかどうか |

### 7.2 `flutter/lib/othello_ai.dart:OthelloAi:chooseMove` の処理手順

1. パラメータを持たないなら、決められないと分かる形で返す
2. 置ける升を聞く
3. 置ける升が 1 つも無ければ、手が無いと分かる形で返す
4. 空いている升の数が、組の「読み切りに入る空きの数」以下なら、★**深さを空きの数に置き換える**
5. ★**打ち切りの時刻を作る**——渡された時刻から 5 秒後
6. `bestMove` を呼ぶ
7. 返った升を器に入れて返す

★★**4 が終盤の読み切りである。**★深さを増やすのではなく、**残りの空きの数と同じにする**。
こうすると、終局まで読み切ったことが数で分かる。

★★**時刻は引数で渡す。**★**この関数は時計を見ない**。★見ると、同じ入力で同じ答えが返らなくなり、
試験が書けなくなる（[[DD-L1-othello]] §4）。★**時計を見るのは、呼ぶ側（入口）である。**

#### `flutter/lib/othello_ai.dart:OthelloAi:chooseMove` の挙動宣言

- 対象コード: `flutter/lib/othello_ai.dart:OthelloAi:chooseMove`
- 入口の語: `chooseMove`
- もし パラメータを持たない なら「決められない」
- もし 置ける升が 1 つも無い なら「手が無い」
- それ以外は「升」
- 出口「決められない」は `ok=False` で認める
- 出口「手が無い」は `ok=False` で認める
- 出口「升」は `ok=True` で認める

#### `flutter/lib/othello_ai.dart:OthelloAi:chooseMove` の試験材料

- 入力 `board=初期配置, turn="B", params=無し, nowMs=0` のとき 特徴 `ok=False`
- 入力 `board=置ける升が無い盤, turn="B", params=段 4 の組, nowMs=0` のとき 特徴 `ok=False`
- 入力 `board=初期配置, turn="B", params=段 4 の組, nowMs=0` のとき 特徴 `ok=True`
- 入力 `board=初期配置, turn="B", params=段 1 の組, nowMs=0` のとき 特徴 `ok=True`
- 入力 `board=初期配置, turn="B", params=段 6 の組, nowMs=0` のとき 特徴 `ok=True`

## 8. 試験

★試験は `flutter/test/` に在る。★★**登録はしていない**（owner 指示 2026-08-23）。
