# DD-L4 関数仕様 — 画面（見た目と操作）

- name : DD-L4-othello-ui
- parent : DD-L3-othello
- doc_id : DD-L4-othello-ui ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **関数ごとのインタフェース表・処理手順**を定める。
- 出典 : [[DD-L3-othello]] ／ [[DD-L1-othello]] §3（F-1〜F-12）／ owner 指摘 2026-08-17

---

## 0. なぜこの設計書が要るか

★★**実測 2026-08-17: 画面の 7 本が、設計書に一行も書かれていなかった**——
★**オセロの見た目と操作を決めている本体**が、★**丸ごと設計の外**に在った。

★**法「Code は親に DD を取る」ゆえ、書かれていないものは登録できない**（★関所は正しく撃っていた）。
∴ ★**ここに書く**。★**名指しは道つき**（法 §4-1）。

## 1. ファイルの分け方

| ファイル | 何を持つか |
|:---|:---|
| `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt` | ★**3 つを並べ**、触られたことを渡す |
| `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt` | ★**盤を描く**・升が押されたことを返す |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt` | ★**わきの補助情報とボタン** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt` | ★**盤の下に形勢の線を描く**（★判定を持たない） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt` | ★**始める前の窓**（誰が黒か・強さ） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt` | ★**控えから選ぶ窓** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt` | ★**遊び方を読む画面**（F-12） |

★★**画面は判定を持たない**（[[DD-L2-othello]]）——★**受け取った一式を描き、触られたことを渡すだけ**。

## 2. 綴りの決め

名指しは**三要素**で書く——`道つきコード名:クラス:メソッド`（法 §4-1）。
★**画面の関数はクラスに属さない**ので、クラスの欄は `(module)` と書く。


## 2b. ★★触られたことを渡す口は、器で持つ（★抽象でなく合成・C 規約）

★★**`interface` は使わない**（★C 規約「interface 禁止（抽象・合成せよ）」）——
★**実測 2026-08-17: `OthelloScreen.kt` が `interface OthelloTouch` を持ち、登録を拒まれた**。

★**なぜ器でよいか**——★**入れ替えたいのは「振る舞い」ではなく「渡し先」**である。
★**画面は判定を持たない**ので、★**渡す口の束を、そのまま器で受け取ればよい**。

| 欄 | 型 | 何を渡すか |
|:---|:---|:---|
| `onSquare` | `(square: String) -> Unit` | 押された升（`a1` の形） |
| `onPass` | `() -> Unit` | パス |
| `onUndo` | `() -> Unit` | 待った |
| `onNewGame` | `() -> Unit` | ★**新しい対局**（★いつでも押せる・DD-L1-othello §6.5c） |
| `onMachineStep` | `() -> Unit` | ★**計算機の 1 手**（★間を置いてから送る・CR-6） |
| `onReplayList` | `() -> Unit` | 控えの一覧を出す |
| `onReplayPick` | `(gameId: Int) -> Unit` | 控えから選んだ対局 |
| `onReplayNext` | `() -> Unit` | 再生の 1 手 |
| `onImport` | `() -> Unit` | 取り込み |
| `onDump` | `() -> Unit` | 書き出し |
| `onHelp` | `() -> Unit` | ヘルプを出す |
| `onCloseHelp` | `() -> Unit` | ヘルプを閉じる |
| `onStart` | `(black: String, white: String, blackLevel: Int, whiteLevel: Int, name: String) -> Unit` | ★**始める決め**（誰が黒か・強さ・名） |
| `onCancelSetup` | `() -> Unit` | 始める窓をやめる |

★**器の名は `OthelloTouch`**（`ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt`）。
★★**14 の口を 1 つの器で渡す**——★**引数を 14 個並べない**（★並べると、呼ぶ側が順を覚える）。

## 3. 関数

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt:(module):OthelloScreen(view: View?, choosing: Boolean, touch: OthelloTouch, modifier: Modifier) -> Unit` | `view` = 受け取った一式（★**無ければ対局が無い**）／`choosing` = ★**選び直しの窓を出しているか**／`touch` = 触られたことの渡し先／`modifier` = 置き方 | ★**無し**（描くだけ） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt:(module):OthelloBoardView(view: View, onSquare: (String) -> Unit, modifier: Modifier) -> Unit` | `view` = 一式／`onSquare` = ★**押された升を渡す口**（`a1` の形）／`modifier` = 置き方 | ★**無し**（描くだけ） |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt:(module):OthelloSidePanel(view: View, onPass: () -> Unit, onUndo: () -> Unit, onNewGame: () -> Unit, onReplay: () -> Unit, onImport: () -> Unit, onDump: () -> Unit, onHelp: () -> Unit, modifier: Modifier) -> Unit` | `view` = 一式／`onPass`〜`onHelp` = ★**押されたことを渡す口**（★**判定はしない**） | ★**無し** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt:(module):OthelloGraphView(trend: Trend, modifier: Modifier) -> Unit` | `trend` = 形勢の並び（★**重みの積算値**を手数で） | ★**無し** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt:(module):OthelloSetupDialog(onStart: (String, String, Int, Int, String) -> Unit, onCancel: () -> Unit, canCancel: Boolean) -> Unit` | `onStart` = ★**決めたことを渡す口**（黒は誰か・白は誰か・黒の強さ・白の強さ・先手）／`canCancel` = ★**やめられるか**（★**対局が無いときはやめられない**） | ★**無し** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt:(module):OthelloReplayDialog(games: List<GameHead>, onPick: (Int) -> Unit, onCancel: () -> Unit) -> Unit` | `games` = 控えの一覧／`onPick` = ★**選んだ対局の番号を渡す口** | ★**無し** |
| `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt:(module):OthelloHelpScreen(onClose: () -> Unit) -> Unit` | `onClose` = ★**閉じられたことを渡す口** | ★**無し** |

### 3.2 `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt:(module):OthelloScreen` の処理手順

1. ★**一式が無ければ、始める窓を出す**（★盤は描かない）
2. ★**在れば、盤・わき・グラフの 3 つを並べる**
3. ★**触られたことを、そのまま渡す**（★**画面は判定しない**）
4. ★★**「対局が無い」と「選び直し中」を、同じ欄で兼ねない**——
   ★**兼ねると、やめても対局が無いことになり、また同じ窓が出る**（BUG-31・実測 2026-08-12）

### 3.3 `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt:(module):OthelloBoardView` の処理手順

1. ★**8×8 の升を描く**（★升の名は `a1` の形）
2. ★**石を描く**（黒・白）
3. ★**置ける升に印を付ける**（★一式が持っている一覧から。★**画面は数えない**）
4. ★**押された升を、名前で渡す**

### 3.4 `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt:(module):OthelloSidePanel` の処理手順

1. ★**手番・枚数・手数・直前の手・置ける升の数・強さを出す**
2. ★**ボタンを並べる**（パス・待った・新しい対局・再生・取り込み・書き出し・★**ヘルプはいちばん下**）
3. ★**押されたことを、そのまま渡す**（★**押せるかどうかの判定も、ここではしない**）

### 3.5 `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt:(module):OthelloGraphView` の処理手順

1. ★**手数を横、重みの積算値を縦にして線を引く**
2. ★★**判定を持たない**——★**優劣を書かない**（★見る人が読む）

### 3.6 `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt:(module):OthelloSetupDialog` の処理手順

1. ★**黒と白のそれぞれを、人か計算機か選ばせる**（F-6・4 通り）
2. ★**強さを 6 段階から選ばせる**（F-8）
3. ★**先手と後手を決めさせる**（F-7）
4. ★**やめられるかは、渡された印で決める**（★**対局が無いときはやめられない**）

### 3.7 `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt:(module):OthelloReplayDialog` の処理手順

1. ★**控えの一覧を並べる**（★**終わった対局だけ**）
2. ★**選ばれた番号を渡す**

### 3.8 `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt:(module):OthelloHelpScreen` の処理手順

1. ★**遊び方・操作・ボタンの意味を並べる**（F-12・★**対局する人に向けたもの**）
2. ★**閉じられたことを渡す**


## 5. 挙動の宣言（DSL）と試験材料

★★**画面は判定を持たない**——★**出口は「何を出したか」で分ける**（★優劣や可否は書かない）。

#### `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt:(module):OthelloScreen` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt:(module):OthelloScreen`
- 入口の語: `view`
- もし `一式なし` なら「始める窓」
- それ以外は「三つ並ぶ」
- 出口「始める窓」は `regex:^始める窓$` で認める
- 出口「三つ並ぶ」は `regex:^三つ並ぶ$` で認める
- ★**錨**: ★一式が無ければ盤を描かない（3.2 の 1）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloScreen.kt:(module):OthelloScreen` の試験材料

- 入力 `view=None` のとき 特徴 `一式なし=True`
- 入力 `view={"turn": "B"}` のとき 特徴 `一式なし=False`
- 出口「始める窓」は `regex:^始める窓$` で認める
- 出口「三つ並ぶ」は `regex:^三つ並ぶ$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt:(module):OthelloBoardView` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt:(module):OthelloBoardView`
- 入口の語: `view`
- もし `置ける升なし` なら「石だけ」
- それ以外は「石と印」
- 出口「石だけ」は `regex:^石だけ$` で認める
- 出口「石と印」は `regex:^石と印$` で認める
- ★**錨**: ★置ける升の印は、一式が持つ一覧から（3.3 の 3）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloBoardView.kt:(module):OthelloBoardView` の試験材料

- 入力 `view={"can": []}` のとき 特徴 `置ける升なし=True`
- 入力 `view={"can": ["f5"]}` のとき 特徴 `置ける升なし=False`
- 出口「石だけ」は `regex:^石だけ$` で認める
- 出口「石と印」は `regex:^石と印$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt:(module):OthelloSidePanel` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt:(module):OthelloSidePanel`
- 入口の語: `view`
- もし `終わった` なら「押せぬ形」
- それ以外は「押せる形」
- 出口「押せぬ形」は `regex:^押せぬ形$` で認める
- 出口「押せる形」は `regex:^押せる形$` で認める
- ★**錨**: ★押されたことは、そのまま渡す（3.4 の 3）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloSidePanel.kt:(module):OthelloSidePanel` の試験材料

- 入力 `view={"state": "終わった"}` のとき 特徴 `終わった=True`
- 入力 `view={"state": "打っている"}` のとき 特徴 `終わった=False`
- 出口「押せぬ形」は `regex:^押せぬ形$` で認める
- 出口「押せる形」は `regex:^押せる形$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt:(module):OthelloGraphView` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt:(module):OthelloGraphView`
- 入口の語: `trend`
- もし `手なし` なら「線なし」
- それ以外は「線」
- 出口「線なし」は `regex:^線なし$` で認める
- 出口「線」は `regex:^線$` で認める
- ★**錨**: ★判定を持たない（3.5 の 2）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt:(module):OthelloGraphView` の試験材料

- 入力 `trend={"black": []}` のとき 特徴 `手なし=True`
- 入力 `trend={"black": [0, 3]}` のとき 特徴 `手なし=False`
- 出口「線なし」は `regex:^線なし$` で認める
- 出口「線」は `regex:^線$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt:(module):OthelloSetupDialog` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt:(module):OthelloSetupDialog`
- 入口の語: `canCancel`
- もし `やめられぬ` なら「釦なし」
- それ以外は「釦あり」
- 出口「釦なし」は `regex:^釦なし$` で認める
- 出口「釦あり」は `regex:^釦あり$` で認める
- ★**錨**: ★対局が無いときはやめられない（3.6 の 4）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloSetupDialog.kt:(module):OthelloSetupDialog` の試験材料

- 入力 `canCancel=False` のとき 特徴 `やめられぬ=True`
- 入力 `canCancel=True` のとき 特徴 `やめられぬ=False`
- 出口「釦なし」は `regex:^釦なし$` で認める
- 出口「釦あり」は `regex:^釦あり$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt:(module):OthelloReplayDialog` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt:(module):OthelloReplayDialog`
- 入口の語: `games`
- もし `控えなし` なら「空の一覧」
- それ以外は「選べる一覧」
- 出口「空の一覧」は `regex:^空の一覧$` で認める
- 出口「選べる一覧」は `regex:^選べる一覧$` で認める
- ★**錨**: ★終わった対局だけ（3.7 の 1）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloReplayDialog.kt:(module):OthelloReplayDialog` の試験材料

- 入力 `games=[]` のとき 特徴 `控えなし=True`
- 入力 `games=[{"id": 1}]` のとき 特徴 `控えなし=False`
- 出口「空の一覧」は `regex:^空の一覧$` で認める
- 出口「選べる一覧」は `regex:^選べる一覧$` で認める

#### `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt:(module):OthelloHelpScreen` の挙動宣言

- 対象コード: `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt:(module):OthelloHelpScreen`
- 入口の語: `onClose`
- もし `閉じた` なら「閉じる」
- それ以外は「読める形」
- 出口「閉じる」は `regex:^閉じる$` で認める
- 出口「読める形」は `regex:^読める形$` で認める
- ★**錨**: ★対局する人に向けたもの（3.8 の 1）

#### `ui/src/commonMain/kotlin/othello/ui/OthelloHelpScreen.kt:(module):OthelloHelpScreen` の試験材料

- 入力 `onClose="押された"` のとき 特徴 `閉じた=True`
- 入力 `onClose="押されていない"` のとき 特徴 `閉じた=False`
- 出口「閉じる」は `regex:^閉じる$` で認める
- 出口「読める形」は `regex:^読める形$` で認める

## 4. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| ★**画面は判定を持たない**（DD-L2-othello） | 3.2 の 3 ・ 3.4 の 3 ・ 3.5 の 2 |
| ★**F-11 形勢を線グラフで見る** | 3.5 |
| ★**F-12 ヘルプを画面で読む** | 3.8 |
| ★**「対局が無い」と「選び直し中」を兼ねない**（BUG-31） | 3.2 の 4 |
| ★**名指しは道つき**（法 §4-1） | 2 節・IF 表 |

## 下に来る設計書

★**無し。**L4 が末端である。
