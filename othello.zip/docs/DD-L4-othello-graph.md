# DD-L4 関数仕様 — 形勢のグラフ

- doc_id : DD-L4-othello-graph ／ design_level : L4 ／ 上位 : [[DD-L3-othello-graph]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **形勢のグラフ**について、関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料を定める。
- 出典 : DD-L3-othello-graph §3・§5 ／ CR-8
- 呼ぶ相手 : [[DD-L4-othello-ai]]（升の重みの表）

---

## 0. L4 と L5 の役割分担

このアプリは**全部 L4 に書く**。L5 は書かない。

| 層 | 何を書く層か | ここではどうか |
|:---|:---|:---|
| L4 | 関数単位の仕様。インタフェース・挙動・手順 | ★**ここに全部書く** |
| L5 | 拡張として差し込む実装のプロトコル仕様 | ★**書かない。**差し込みの口を持たないから |

---

## 1. ファイルの分け方

| ファイル | 関数の数 | 行の目安 | 分岐の深さ | 何を持つか |
|:---|---:|---:|---:|:---|
| `shared/src/main/kotlin/othello/OthelloGraph.kt` | 3 | 約 45 | 2 | 積算を数える・末尾へ足す・手数に合わせて切り詰める |
| `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt` | — | 約 60 | — | 盤の下に線を描く（★**判定を持たない**） |

★**数える所と描く所を分ける。**描く側に重みの表を写すと、
**段を足したときに片方だけ古くなる**（[[DD-L2-othello-graph]] §1）。

## 2. 綴りの決め

名指しは**三要素**で書く——`コードファイル名:クラス:メソッド`。
型と引数は、インタフェース表と呼び出しにだけ書く。

∴ 読点を含む型には**別名を付けて**使う（`Trend`＝形勢の 2 本の並び）。

## 2a. クラスとメソッド

| クラス | ファイル | 親 | メソッド |
|:---|:---|:---|:---|
| `OthelloGraph` | `shared/src/main/kotlin/othello/OthelloGraph.kt` | 無し（object） | `weightSum` ・ `appended` ・ `trimmed` |

★**画面の 1 本はクラスを持たない。**描く関数を並べるだけである。

## 2b. 試験材料の値は、実体で書く

材料の値は、**呼び名ではなく中身**で書く。`board=initial` のようには書かない。

---

## 3. 形勢を数え、並びに足す — `shared/src/main/kotlin/othello/OthelloGraph.kt`

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum(board: List<String>, side: String) -> Int` | 盤、どちらの側か | ★**その側の石が乗っている升の、重みの積算値**（★**物差しはいつも同じ表**。CR-12） |
| `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended(now: Trend, board: List<String>, machine: Boolean) -> Trend` | いままでの 2 本、いまの盤、★**計算機が居るか** | 末尾へ 1 つずつ足した 2 本。★**居なければ、そのまま返す** |
| `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed(now: Trend, moves: Int) -> Trend` | いままでの 2 本、いまの手数 | ★**手数に合わせて切り詰めた 2 本** |

★**引くのではなく、2 本のまま返す。**差にすると、**どちらが持っているかが消える**（[[DD-L3-othello-graph]] §3.2）。

### 3.2 `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum` の処理手順

1. 盤の升を 1 つずつ見る
2. その升に**その側の石**が乗っていれば、升の重みを足す
3. ★**いつも `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf(row: Int, col: Int) -> Int` を使う**（★**段から切り離した物差し**。CR-12）
4. 合計を返す

★**相手の石を引かない。**2 本の線で見せるので、**それぞれの側の合計**が要る。

★★**表を段で切り替えない。**黒と白で段が違えば表も違うので、切り替えると★**2 本の線が違う基準になる**（CR-8「違う基準では比べられない」）。
∴ **どの対局でも、同じ 1 つの表で測る。**

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum`
- 入口の語: `board`, `side`
- もし `その側の石が無い` なら「積むものが無い」
- それ以外は「積算値」
- 出口「積むものが無い」は `0` で認める
- 出口「積算値」は `regex:^-?\d+$` で認める

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum` の試験材料

- 入力 `board=["........", "........", "........", "........", "........", "........", "........", "........"], side="B"` のとき 特徴 `その側の石が無い=True`
- 入力 `board=["B.......", "........", "........", "........", "........", "........", "........", "........"], side="B"` のとき 特徴 `その側の石が無い=False`
- 出口「積むものが無い」は `0` で認める
- 出口「積算値」は `regex:^-?\d+$` で認める

### 3.3 `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended` の処理手順

1. 計算機が居なければ、★**そのまま返す**（人どうしの対局。[[DD-L1-othello]] §5.2c）
2. `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum(board: List<String>, side: String) -> Int` を、黒と白について 1 回ずつ呼ぶ
3. 2 本の並びの末尾へ、1 つずつ足して返す

★**作り直さない。**手が進むほど数え直す量が増える（[[DD-L3-othello-graph]] §3.3）。

★**2 本を同じ長さに保つ。**片方だけ足すと、**横軸のどこを指すか**が分からなくなる。

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended`
- 入口の語: `now`, `board`, `machine`
- もし `計算機が居ない` なら「そのまま」
- それ以外は「1 つ伸びる」
- 出口「そのまま」は `['black']:[]` で認める
- 出口「1 つ伸びる」は `regex:^Trend` で認める

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:appended` の試験材料

- 入力 `now={"black": [], "white": []}, board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], machine=False` のとき 特徴 `計算機が居ない=True`
- 入力 `now={"black": [], "white": []}, board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], machine=True` のとき 特徴 `計算機が居ない=False`
- 出口「そのまま」は `['black']:[]` で認める
- 出口「1 つ伸びる」は `regex:^Trend` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed` の処理手順

1. 残す数を出す——★**手数 ＋ 1**（0 手目を含むから）
2. 2 本とも、先頭からその数だけ残して返す
3. いまの長さのほうが短ければ、★**そのまま返す**（伸ばさない）

★★**足すのと切り詰めるのを、同じファイルに置く。**離すと、**片方だけ直す事故**が起きる
（[[DD-L3-othello-graph]] §5.2）。

★**1 で「＋1」を忘れない。**忘れると、★**待ったのたびに線が 1 つずつ短くなる**。

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed`
- 入口の語: `now`, `moves`
- もし `手数のほうが長い` なら「そのまま」
- それ以外は「切り詰める」
- 出口「そのまま」は `['black']:[10, 20]` で認める
- 出口「切り詰める」は `['black']:[10]` で認める

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:trimmed` の試験材料

- 入力 `now={"black": [10, 20], "white": [5, 8]}, moves=5` のとき 特徴 `手数のほうが長い=True`
- 入力 `now={"black": [10, 20], "white": [5, 8]}, moves=0` のとき 特徴 `手数のほうが長い=False`
- 出口「そのまま」は `['black']:[10, 20]` で認める
- 出口「切り詰める」は `['black']:[10]` で認める

#### `shared/src/main/kotlin/othello/OthelloGraph.kt:OthelloGraph:weightSum` の呼ぶIF

- [[DD-L4-othello-ai]] `shared/src/main/kotlin/othello/OthelloWeight.kt:OthelloWeight:weightOf` を呼ぶ

---

## 4. 線を描く — `ui/src/commonMain/kotlin/othello/ui/OthelloGraphView.kt`

盤の下に、2 本の線を描く。★**判定を持たない。**受け取った並びを描くだけ。

| 何 | どう描くか |
|:---|:---|
| 横軸 | ★**手数。0 手から 60 手までで、目盛りは固定**——★**並びの長さで引き伸ばさない** |
| ★**線の伸び方** | ★**1 手ごとに右へ伸びていく。終端が右端に来るのは、対局が終わったときだけ** |
| 縦軸 | ★**自動で伸縮**（2 本の最大と最小に合わせる。CR-8） |
| 線の色 | ★**黒の側は赤、白の側は青** |
| ★**終端の印** | ★**線の先に丸を置く。****黒の側は黒丸、白の側は白丸** |
| ★**高さ** | ★**盤の幅の 3 分の 1**（幅に対する比で決める。決め打ちの高さを持たない） |
| ★**軸** | ★**縦と横の軸を描く**（左に縦軸、下に横軸）。薄い色で、線より細く |
| ★**白丸の見え方** | ★**黒の縁の中を白で塗る**——**縁が無いと、明るい背景に隠れる** |
| ★**盤との重なり** | ★**重ねない。**盤の下に置き、**盤とグラフで高さを分け合う** |
| 空のとき | ★**何も描かない**（計算機が居ない対局） |
| 点が 1 つのとき | 線が引けないので、★**何も描かない** |

★★**自動試験を書かないのは「描くこと」だけである。**この 1 本が持つのは描画だけなので、
テストの終端として宣言する（分類は、対話的な画面で人手の確認が要るもの）。

★★**横軸を、並びの長さで引き伸ばさない。**引き伸ばすと、★**終端がいつも右端に来る**——**伸びていくように見えない**（CR-8「1 手ごとにグラフは伸びていく」）。
∴ **右端は 60 手で固定する**（盤は 64 升、置いてある 4 つを除いて **60 手**が上限）。
★**実測 2026-08-13**: 引き伸ばして作り、利用者に指摘された（BUG-40）。

★**軸を出す。**軸が無いと、**線がどこを基準に上下しているのか**が分からない。
★**目盛りの数字は出さない**——値そのものではなく、**上がったか下がったか**を見るものだから。

★★**線の色と、終端の丸は、別のことを表す。**——**線の色**は 2 本を見分けるためであり、★**終端の丸は「どちらの側か」**を表す（黒丸＝黒の側、白丸＝白の側）。
**色だけだと、赤と青のどちらが黒なのか、盤を見ないと分からない。**

★**高さを決め打ちにしない。**盤の幅に対する比（3 分の 1）で決める——**窓の大きさが変わっても、釣り合いが崩れない**。

★**縦の目盛りを画面が決める。**値の幅は対局ごとに違うので、**決め打ちの上下限を持たない**。

---

## 5. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| 枚数ではなく重みの積算 | `weightSum` が重みを足す |
| 両方の側を同じ表で | ★**`weightSum` は段を受け取らない**（物差しは 1 つ） |
| 1 手ごとに伸びる | `appended` が末尾へ足す |
| 待ったで戻る | `trimmed` が手数に合わせる |
| 人どうしでは出さない | `appended` の出口「そのまま」 |
| 記録に残さない | どの関数も**書かない・読まない** |
