# DD-L4 関数仕様 — 盤の規則

- doc_id : DD-L4-othello-rules ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **盤の規則**（升の名前・盤という値・走査・置ける升）について、関数ごとのインタフェース表・処理手順・挙動宣言（DSL）・試験材料を定める。
- 出典 : DD-L3-othello §2（受け皿のうち規則の側）・§3（データ構造）
- 呼ぶ相手 : ★**無い。**盤の規則は、進行も画面も打ち手も知らない（呼ばれるだけ・[[DD-L2-othello]] §1.2）

---

## 0. L4 と L5 の役割分担

このアプリは**全部 L4 に書く**。L5 は書かない。

| 層 | 何を書く層か | オセロではどうか |
|:---|:---|:---|
| L4 | 関数単位の仕様。インタフェース・挙動・手順 | ★**ここに全部書く** |
| L5 | 拡張として差し込む実装のプロトコル仕様 | ★**書かない。**差し込みの口を持たないアプリだから |


### 0b. ★言語を移したときに、何が変わって何が変わらなかったか

この一式は、共通の実装を別の言語へ移した（[[DD-L2-othello]] §7z.4）。**そのとき何が動いたかを残す。**

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | どのファイルに何を置くか。1 つも動かしていない |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | 段の並びは 1 つも変えていない |
| 挙動の宣言 | 条件も出口も、認めかたも同じ |
| 試験の材料 | 入力の値も、期待値も同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | 綴りの決まりが違う（区切りの記号と、大文字の使い方） |
| メソッドの名 | 同上 |
| クラスの欄 | 擬似のものから、**実在する入れ物の名**へ |
| 型の名 | その言語の型へ |

★★**設計が言語に依っていなかったことが、ここで確かめられた。**
もし手順や宣言まで書き直す必要が出ていたなら、それは**設計に実装の都合が混ざっていた**ということである。

★**型の名だけは、記法の側の都合で調整した**（下の「型の名に読点を入れない」）。
これは設計の内容ではなく、**書き表し方の問題**である。

## 1. ファイルの分け方 — 上限に張り付かせない

規約は、Python が 1 ファイル 300 行・5 関数まで、ネストは 4 まで、分岐は 20 まで。
**上限ちょうどで設計しない。**上限に張り付いた設計は、次に 1 つ足した瞬間に超え、割り直しになる。

**目安は、1 ファイル 3 関数まで・100 行まで・ネスト 2 まで**とする。

| ファイル | 関数 | 行数の見込み | ネストの深さ | 何を持つか |
|:---|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloSquare.kt` | 3 | 約 50 | 1 | 升の名前と行・列の行き来 |
| `shared/src/main/kotlin/othello/OthelloBoard.kt` | 2 | 約 40 | 2 | 盤を作る・写す |
| `shared/src/main/kotlin/othello/OthelloScan.kt` | 2 | 約 60 | 2 | 1 方向の走査と、8 方向をまとめた裏返り |
| `shared/src/main/kotlin/othello/OthelloRules.kt` | 3 | 約 70 | 2 | 置ける升・置いた後の盤・終局か |

### 1.1 ★ネストを下げるために分けたところ

深くなるのは、**8 方向の走査**である。素直に書くと「方向ごとの繰り返し」の中に「隣へ進む繰り返し」が入り、
さらに条件が重なって 4 段になる。

そこで、**1 方向だけを見る関数を切り出した。**

| 関数 | 何をするか | ネスト |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` | **1 方向だけ**見て、挟めるならその升を返す | 2（繰り返し 1 つと条件） |
| `flips` | 8 方向について `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` を呼び、つなぐ | 1（繰り返し 1 つ） |

同じ理由で、**盤の全升を並べる関数**も切り出した。これで `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` は二重の繰り返しにならない。

深さを下げる切り方には、決まった形がある。**内側の繰り返しを、名前のある関数にして外へ出す**。出した関数は外の事情を知らないので、そこだけを取り出して確かめられる。逆に、外に置いたままで深さだけ下げようとすると、途中で抜ける書き方や、番兵の値を置く書き方に頼ることになり、読んで何が起きるのか分からなくなる。分けるほうが、いつでも安い。

**上限に張り付かせないのは、次に足すときのためでもある。**この設計は、まだ盤の規則しか持っていない。この後に、対戦相手と棋譜の取り込みが加わる。そのとき 1 ファイルに 5 関数まで詰めてあると、足す先が無くなって割り直しになる。割り直しは、書いたものを捨てる作業である。**先に余りを残しておけば、足すだけで済む。**

### 1b. ★書いた後の実測（2026-08-12）

見込みと、実際に書いたものを並べる。**見込みだけ書いて確かめないと、上限に張り付いていないことが言えない。**

| ファイル | 関数（見込み→実測） | 行数（見込み→実測） | ネスト（見込み→実測） |
|:---|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloSquare.kt` | 3 → **3** | 50 → **31** | 1 → **1** |
| `shared/src/main/kotlin/othello/OthelloBoard.kt` | 2 → **2** | 40 → **20** | 2 → **0** |
| `shared/src/main/kotlin/othello/OthelloScan.kt` | 2 → **2** | 60 → **37** | 2 → **1** |
| `shared/src/main/kotlin/othello/OthelloRules.kt` | 3 → **3** | 70 → **34** | 2 → **1** |

★**行数はどれも見込みより短い。**規約（300 行・5 関数・ネスト 4）にも、目安（3 関数・100 行・ネスト 2）にも、**張り付いていない**。

## 2. 綴りの決め

関数を名指す綴りは、**この設計書のどこでも `コードファイルの相対パス:クラス:メソッド`** とする。区切りはすべて `:`。
クラスに属さない関数は `(module)` と書く。系の外は `外` と書く。
引数と戻り値の型は、**表と呼び出しにだけ**書く。

★**分岐の無い関数は、特徴を書かない。**条件が無いのだから、「どの条件を撃ったか」も無い。無いものを埋めるために特徴をこしらえると、**試験が何を確かめているのか分からなくなる**。

★**引数を取らない関数は、材料を書かずに免除にする。**★分類は `other_language` を使う——★**免除の分類は述語で裏付くものだけが効く**（[[DD-L4-dsl-exempt-audit]] §免除の法）。`no_args` の述語は Python の構文木を引くので、この一式（Kotlin）では裏付かない。


★★**型の名に読点を入れない。**この記法は引数を読点で区切るので、
`Pair<Int, Int>` のような型をそのまま書くと、**引数が 1 つ増えたように読まれる**。
∴ 読点を含む型には**別名を付けて**使う（`Step`＝向きの組、`Body`＝記録の中身）。
★**記法が読める形にするのは、書き手の仕事である。**読み手を賢くして解決しない。

## 2a. クラスとメソッド

★**クラスの欄を空にしない。**この一式では、モジュールごとに **`object` を 1 つ**置き、
関数はその中に入る。★**クラス名は、その `object` の名である**（`USER_MANUAL` §3.10・`DesignClass`）。
**「クラスを持たない」という状態は無い。**

| クラス | コードファイル | 親クラス | 属するメソッド |
|:---|:---|:---|:---|
| `OthelloSquare` | `shared/src/main/kotlin/othello/OthelloSquare.kt` | 無し（object） | `squareToRc` ・ `rcToSquare` ・ `allSquares` |
| `OthelloBoard` | `shared/src/main/kotlin/othello/OthelloBoard.kt` | 無し（object） | `initialBoard` ・ `copyBoard` |
| `OthelloScan` | `shared/src/main/kotlin/othello/OthelloScan.kt` | 無し（object） | `scanLine` ・ `flips` |
| `OthelloRules` | `shared/src/main/kotlin/othello/OthelloRules.kt` | 無し（object） | `legalMoves` ・ `applyMove` ・ `isOver` |

★★**この表と、インタフェース表は別物である。**
ここは**どのクラスにどのメソッドが属するか**を決める表であり、
インタフェース表は各メソッドの**入口と出口の項目**（名前・型・順序）を決める表である。
**所属が無ければ呼び先が解けず、項目が無ければ引数が合っているかを照合できない。**

★**親クラスは持たない。**`object` は継承の木に載らない。★**状態を持たない**ので、包む必要が無い。

## 2b. 試験材料の値は、実体で書く

★**射影（`['名']` や `[番号]`）は「その名の項目」「その番目」を指す。**
辞書の鍵でも、器の項目でも、同じ読み方をする——**言語が変わっても、指すものは変わらない**。

★**期待値の綴りは、その言語の見え方に合わせる。**同じ値でも、言語によって表示が違う
（升の一覧が `['d4']` と出る言語もあれば、`[d4]` と出る言語もある）。
★**値が同じであることと、綴りが同じであることは別**である。


★**材料の値に呼び名を書かない。**「初期の盤」「人と計算機の設定」のような名で置くと、
**その名が何を指すのかは、どこにも書かれていない**ことになる。読む側が想像で埋めるしかなく、
書いた本人の頭の中にしか正しい値が無い。★**試験は、その想像の上に立つことになる。**

| 書き方 | 可否 | なぜ |
|:---|:---|:---|
| 呼び名（`board=initial`） | ★**不可** | 中身が無い。試験を起こす材料にならない |
| 実体（8 行の並びをそのまま） | 可 | そのまま渡せる。読めば何を試しているかが分かる |

盤は **8 つの文字列**で持つ。1 文字が 1 升で、`.` が空、`B` が黒、`W` が白である。
上から 4 行目と 5 行目の真ん中に、白と黒が斜めに 2 つずつ置かれているのが、対局の始まりの形である。

★**値が長くなることを嫌がらない。**長いのは、盤という物が実際に 64 升あるからであって、
書き方が悪いからではない。**短く書くために名前で逃げると、その名前の中身を誰も確かめられなくなる。**

★**同じ値を 2 か所に書くことは避けられない。**材料は行ごとに独立していなければならないからである。
ここで大事なのは、**食い違ったときに気付ける形**であることで、
どの行も**そのまま読めば何の盤か分かる**なら、突き合わせは目で足りる。

---

---

## 3. 升の名前 — `shared/src/main/kotlin/othello/OthelloSquare.kt`

升の名前と、行・列の行き来だけを持つ。盤も規則も知らない。

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc(square: String) -> Step` | 升（`f5` の形） | 行と列の組。盤の外なら負の値 |
| `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare(row: Int, col: Int) -> String` | 行、列 | 升の名前。盤の外なら空 |
| `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares() -> List<String>` | 無し | 盤の 64 升の名前を並べたもの |

### 3.2 `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc` の処理手順

1. 升の長さが 2 でなければ、負の値の組を返す
2. 先頭の 1 文字を列に、次の 1 文字を行に直す
3. どちらかが 0 から 7 の外なら、負の値の組を返す
4. 行と列の組を返す

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc`
- 入口の語: `square`
- もし `盤の外` なら「範囲の外」
- それ以外は「行と列」
- 出口「範囲の外」は `(-1, -1)` で認める
- 出口「行と列」は `(4, 5)` で認める

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc` の試験材料

- 入力 `square="f5"` のとき 特徴 `盤の外=False`
- 入力 `square="z9"` のとき 特徴 `盤の外=True`
- 出口「行と列」は `(4, 5)` で認める
- 出口「範囲の外」は `(-1, -1)` で認める

### 3.3 `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare` の処理手順

1. 行か列が 0 から 7 の外なら、空を返す
2. 列を英字に、行を数字に直してつなぎ、返す

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare`
- 入口の語: `row`, `col`
- もし `盤の外` なら「空」
- それ以外は「升の名前」
- 出口「空」は `regex:^$` で認める
- 出口「升の名前」は `f5` で認める

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare` の試験材料

- 入力 `row=4, col=5` のとき 特徴 `盤の外=False`
- 入力 `row=9, col=0` のとき 特徴 `盤の外=True`
- 出口「升の名前」は `f5` で認める
- 出口「空」は `regex:^$` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares` の処理手順

1. 行と列の全ての組について `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare(row: Int, col: Int) -> String` を呼ぶ
2. 得た名前を並べて返す

★この関数が在るので、升を走る側は**繰り返しを 1 つで済ませられる**。

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares`
- それ以外は「升の一覧」
- 出口「升の一覧」は `[0]:a1` で認める

#### `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★引数も無いので材料で変えられる入力が無い。★中身は `shared/src/test/kotlin/othello/OthelloRulesGroupTest.kt` が現に確かめている

---

## 4. 盤という値 — `shared/src/main/kotlin/othello/OthelloBoard.kt`

盤を作る、写す。**判定は持たない。**

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard() -> List<String>` | 無し | 初期配置の盤。8 行、各行 8 文字 |
| `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard(board: List<String>) -> List<String>` | 盤 | 中身の同じ**新しい**盤 |

### 4.2 `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard` の処理手順

1. 空の升だけの 8 行 8 列を作る
2. 中央 4 升に、白・黒・黒・白の順で置く
3. その盤を返す

#### `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard`
- それ以外は「初期配置の盤」
- 出口「初期配置の盤」は `[3]:contains:WB` で認める

#### `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:initialBoard` の試験材料

- 免除: 分類: other_language — ★対象コードが Kotlin であり、Python として解決できない（生成器が呼べない）。★引数も無いので材料で変えられる入力が無い。★中身は `shared/src/test/kotlin/othello/OthelloRulesGroupTest.kt` が現に確かめている

### 4.3 `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard` の処理手順

1. 盤の各行を 1 つずつ写して、新しい並びを作る
2. 新しい盤を返す

★**受け取った盤に触らない。**待ったのときに 1 手前の盤をそのまま使えるようにするため。

#### `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard`
- 入口の語: `board`
- もし `中央の行が空` なら「空のまま写す」
- それ以外は「写した盤」
- 出口「空のまま写す」は `[3]:........` で認める
- 出口「写した盤」は `[3]:contains:WB` で認める

#### `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard` の試験材料

- 入力 `board=["........", "........", "........", "........", "........", "........", "........", "........"]` のとき 特徴 `中央の行が空=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"]` のとき 特徴 `中央の行が空=False`
- 出口「空のまま写す」は `[3]:........` で認める
- 出口「写した盤」は `[3]:contains:WB` で認める

---

## 5. 走査 — `shared/src/main/kotlin/othello/OthelloScan.kt`

**8 方向の定めを持つのは、このファイルだけ。**

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine(board: List<String>, row: Int, col: Int, step: Step, turn: String) -> List<String>` | 盤、置く升の行と列、進む向き、手番 | その向きで挟める升の一覧。挟めなければ空 |
| `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips(board: List<String>, move: String, turn: String) -> List<String>` | 盤、升、手番 | 裏返る升の一覧。置けないときは空 |

### 5.2 `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` の処理手順

1. 置く升から、渡された向きへ 1 つ進む
2. 相手の石が続くあいだ、`shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:rcToSquare(row: Int, col: Int) -> String` で升の名前に直し、集めながら進む
3. 止まった先が自分の石で、かつ 1 つ以上集めていれば、集めた升を返す
4. そうでなければ、空を返す

★**この関数は 1 方向しか見ない。**だから繰り返しが 1 つで済み、深くならない。

#### `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine`
- 入口の語: `board`, `row`, `col`, `step`, `turn`
- もし `その向きで挟めない` なら「挟めない」
- それ以外は「挟んだ升の一覧」
- 出口「挟めない」は `[]` で認める
- 出口「挟んだ升の一覧」は `[d4]` で認める

#### `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], row=2, col=3, step={"row": 1, "col": 0}, turn="B"` のとき 特徴 `その向きで挟めない=False`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], row=0, col=0, step={"row": 1, "col": 0}, turn="B"` のとき 特徴 `その向きで挟めない=True`
- 出口「挟んだ升の一覧」は `[d4]` で認める
- 出口「挟めない」は `[]` で認める

### 5.3 `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips` の処理手順

1. `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc(square: String) -> Step` を呼ぶ
2. 返った組が負なら、空を返す
3. その升に既に石が在れば、空を返す
4. 8 つの向きのそれぞれについて `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine(board: List<String>, row: Int, col: Int, step: Step, turn: String) -> List<String>` を呼び、返った升をつなぐ
5. つないだ一覧を返す

★4 は繰り返しが 1 つだけ。**中の走査は `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:scanLine` が持っている。**

#### `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips`
- 入口の語: `board`, `move`, `turn`
- もし `升が盤の外` なら「裏返らない」
- もし `升に石が在る` なら「裏返らない」
- もし `どの向きでも挟めない` なら「裏返らない」
- それ以外は「挟んだ升の一覧」
- 出口「裏返らない」は `[]` で認める
- 出口「挟んだ升の一覧」は `[d4]` で認める

#### `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="d3", turn="B"` のとき 特徴 `どの向きでも挟めない=False`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="d4", turn="B"` のとき 特徴 `升に石が在る=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="a1", turn="B"` のとき 特徴 `どの向きでも挟めない=True`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="z9", turn="B"` のとき 特徴 `升が盤の外=True`
- 出口「挟んだ升の一覧」は `[d4]` で認める
- 出口「裏返らない」は `[]` で認める

---

## 6. 盤の規則 — `shared/src/main/kotlin/othello/OthelloRules.kt`

盤と手番を受け取り、答えを返す。状態を持たない。

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` | 盤、手番（`B` か `W`） | 置ける升と、数えたことの印を持つ器 |
| `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove(board: List<String>, move: String, turn: String) -> List<String>` | 盤、升、手番 | 置いた後の**新しい**盤 |
| `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver(board: List<String>) -> Boolean` | 盤 | 両者とも置ける升が無ければ真 |

★`shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` の戻り値を一覧そのものにせず器にしたのは、**数えた結果が 0 件であること**と、
**呼ばれていないこと**を、受け取った側が言い分けられるようにするためである。
器の中身は `moves`（升の一覧）と `counted`（数えたかどうか）の 2 つ。

### 6.2 `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` の処理手順

1. `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:allSquares() -> List<String>` を呼ぶ
2. 得た升のそれぞれについて `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips(board: List<String>, move: String, turn: String) -> List<String>` を呼び、空でなければ集める
3. 集めた升と、数えたという印を器に入れて返す

★1 が在るので、**繰り返しは 1 つで済む。**行と列の二重の繰り返しにならない。

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves`
- 入口の語: `board`, `turn`
- もし `どの升も挟めない` なら「置ける升なし」
- それ以外は「置ける升あり」
- 出口「置ける升なし」は `['moves']:[]` で認める
- 出口「置ける升あり」は `['moves']:contains:d3` で認める

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], turn="B"` のとき 特徴 `どの升も挟めない=False`
- 入力 `board=["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"], turn="W"` のとき 特徴 `どの升も挟めない=True`
- 出口「置ける升あり」は `['moves']:contains:d3` で認める
- 出口「置ける升なし」は `['moves']:[]` で認める

### 6.3 `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove` の処理手順

1. `shared/src/main/kotlin/othello/OthelloScan.kt:OthelloScan:flips(board: List<String>, move: String, turn: String) -> List<String>` を呼ぶ
2. 返った一覧が空なら、置けないので**盤を変えずに**そのまま返す
3. `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard(board: List<String>) -> List<String>` を呼んで新しい盤を作る
4. 置いた升と裏返る升のそれぞれを `shared/src/main/kotlin/othello/OthelloSquare.kt:OthelloSquare:squareToRc(square: String) -> Step` で行と列に直し、新しい盤のその升を手番の色にする
5. 新しい盤を返す

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove`
- 入口の語: `board`, `move`, `turn`
- もし `裏返る升が無い` なら「盤は変わらない」
- それ以外は「置いた後の盤」
- 出口「置いた後の盤」は `[3]:contains:BB` で認める
- 出口「盤は変わらない」は `[3]:contains:WB` で認める

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:applyMove` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="d3", turn="B"` のとき 特徴 `裏返る升が無い=False`
- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"], move="a1", turn="B"` のとき 特徴 `裏返る升が無い=True`
- 出口「置いた後の盤」は `[3]:contains:BB` で認める
- 出口「盤は変わらない」は `[3]:contains:WB` で認める

### 6.4 `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver` の処理手順

1. 黒について `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` を呼ぶ
2. 白について同じものを呼ぶ
3. どちらも置ける升が無ければ真、そうでなければ偽を返す

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver`
- 入口の語: `board`
- もし `両方とも置ける升が無い` なら「終局」
- それ以外は「対局中」
- 出口「終局」は `True` で認める
- 出口「対局中」は `False` で認める

#### `shared/src/main/kotlin/othello/OthelloRules.kt:OthelloRules:isOver` の試験材料

- 入力 `board=["........", "........", "........", "...WB...", "...BW...", "........", "........", "........"]` のとき 特徴 `両方とも置ける升が無い=False`
- 入力 `board=["BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB"]` のとき 特徴 `両方とも置ける升が無い=True`
- 出口「対局中」は `False` で認める
- 出口「終局」は `True` で認める

---

## 9z. 呼ぶIF（要求インタフェース）

記法の出どころは**開発環境側の設計書** `DD-L4-integration-contract` §4 である（このアプリの設計書ではないので、二重角括弧で結ばない）。

★**この設計書は、他の設計書の関数を 1 つも呼ばない。**
辺が無いことを、空欄でなく**そう書く**（[[DD-L2-othello]] §1.2 — 盤の規則は呼ばれるだけ）。

## 7. この設計書が満たすもの

| 決め | どこで守っているか |
|:---|:---|
| 盤を書き換えない | `shared/src/main/kotlin/othello/OthelloBoard.kt:OthelloBoard:copyBoard` を通してから書き換える |
| 升の名前と行・列の変換は 1 か所 | `shared/src/main/kotlin/othello/OthelloSquare.kt` だけが持つ |
| 8 方向の定めは 1 か所 | `shared/src/main/kotlin/othello/OthelloScan.kt` だけが持つ |
