# DD-L4 関数仕様 — 対戦記録のデータベース

- doc_id : DD-L4-othello-db ／ design_level : L4 ／ 上位 : [[DD-L3-othello-db]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **DB を開く・入れる・問い合わせる**について、インタフェース表・処理手順・挙動宣言（DSL）・試験材料を定める。
- 出典 : DD-L3-othello-db ／ CR-9・CR-10・CR-11
- 呼ぶ相手 : [[DD-L4-othello-log]]（記録を読む）

---

## 0. L4 と L5 の役割分担

| 層 | 何を書く層か | ここではどうか |
|:---|:---|:---|
| L4 | 関数単位の仕様 | ★**ここに全部書く** |
| L5 | 拡張の差し込み口 | ★**書かない** |

## 1. ファイルの分け方

| ファイル | 関数の数 | 行の目安 | 分岐の深さ | 何を持つか |
|:---|---:|---:|---:|:---|
| `shared/src/main/kotlin/othello/OthelloDb.kt` | 5 | 約 115 | 2 | 開く・始める・1 手足す・終わらせる・手を読む |
| ★**`shared/src/main/kotlin/othello/OthelloDbKeep.kt`** | 4 | 約 75 | 2 | ★**残すことと、外から入れること**——控え・1 局を丸ごと・取り込み |
| ★**`shared/src/main/kotlin/othello/OthelloDbView.kt`** | 4 | 約 100 | 2 | ★**見ることと、外へ出すこと**——一覧・段ごとの数え・中身の並び・書き出し |
| ★**`shared/src/main/kotlin/othello/OthelloDump.kt`** | — | 約 12 | — | ★**中身を見る道具の口。`shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll` を呼び、画面へ出す**（`gradlew :shared:dump -Proot=…`） |

## 2. 綴りの決め

名指しは**三要素**で書く——`コードファイル名:クラス:メソッド`。

★**DB の欄の名前は英語**、意味は日本語で書く（利用者の裁定 2026-08-13）。

## 2a. クラスとメソッド

| クラス | ファイル | 親 | メソッド |
|:---|:---|:---|:---|
| `OthelloDb` | `shared/src/main/kotlin/othello/OthelloDb.kt` | 無し（object） | `openDb` ・ `startGame` ・ `addMove` ・ `finishGame` ・ `readMoves` |
| ★**`OthelloDbKeep`** | `shared/src/main/kotlin/othello/OthelloDbKeep.kt` | 無し（object） | `backupDb` ・ `saveGame` ・ `importFolder` |
| ★**`OthelloDbView`** | `shared/src/main/kotlin/othello/OthelloDbView.kt` | 無し（object） | `collectGames` ・ `listGames` ・ `dumpAll` ・ `writeDump` |

★★**割ったのは 2026-08-15**（[[DD-L3-othello-db]] §2）。`shared/src/main/kotlin/othello/OthelloDb.kt` が **266 行**になり、
規約（Kotlin は 1 ファイル 200 行まで）を超えた。★**切れ目は、まずコード単位**（owner 指示 2026-08-15）——
★**超えていたのは行数であって、どれか 1 つの関数ではない**ので、ファイルを割れば収まる。
★**どこで割るかは行数で決めない**（変わる理由で決める）。

★**クラスの名も動く。**`shared/src/main/kotlin/othello/OthelloDb.kt` に置いたままの 5 つ以外は、**呼び先が `OthelloDbKeep` ／ `OthelloDbView` に変わる**
——★**呼ぶ側も直す**（[[DD-L4-othello-bridge]] §3.2）。★**片側だけ直すと、静かに古いほうが残る。**

## 2c. ★この設計書が持つ関数の並び

| 何をするとき | 呼ぶもの | いつ |
|:---|:---|:---|
| 開く | `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` | ★**起動して、置き場が決まった直後に 1 回** |
| 対局を作る | `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` | 対局の頭で 1 回 |
| 手を足す | `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` | ★**1 手ごと** |
| 終わらせる | `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame` | ★**終局のときに 1 回。ここで永続化する** |
| 控えを取る | `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb` | ★**永続化のすぐ後に 1 回**（3 代前まで残す） |
| 丸ごと入れる | `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` | ★**取り込みのときだけ**（終わった記録を後から入れる） |
| 材料を集める | `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames` | 段 5 が組を選ぶとき |
| 一覧を出す | `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames` | 再生する対局を選ぶとき（★**窓口が呼ぶ**） |
| 取り込む | `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` | ★**起動のたびに 1 回は口が**、★**ボタンのときは窓口が**呼ぶ |
| 手を読む | `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves` | 再生を始めるとき |
| ★**中身を出す** | `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll` | ★**人が中身を見たいとき**（形を作るだけ） |
| ★**書き出す** | `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump` | ★**「DB を書き出す」を押したとき**（先を決める。CR-13 の 13-5） |

★**同じことを 2 通りで入れられる**——**対局しながら入れる道**（`shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` → `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` → `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame`）と、
**終わった記録を後から入れる道**（`shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame`）である。
★**どちらも、在り処が同じなら 2 度入らない。**

## 2b. 試験材料の値は、実体で書く

材料の値は、**呼び名ではなく中身**で書く。

---

## 3. 関数 — `shared/src/main/kotlin/othello/OthelloDb.kt`

★**ファイルの記録は変えない**（CR-9 の 9-4）。**閉じた記録を 1 本ずつ DB へ入れる**——
**探すのは DB、配るのはファイル。**

★★**試験は、試験用の DB に対して行う**（単体試験）。

| 決め | 内容 |
|:---|:---|
| どこに作るか | ★**試験ごとの一時の置き場**（本番の記録の置き場を使わない） |
| 何を使うか | ★**同じ `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb`**——**試験のためだけの入口を作らない** |
| メモリの上 | ★**置き場を空にすれば、メモリの上に開く**（§8.2）。**後片づけが要らない** |
| ★**本番の置き場** | ★**試験は触らない。**触ると、**段 5 の材料が試験で汚れる** |

★**試験データは「その DB に入れた記録」である。**——**試験の中で作って、試験の中で読む。**
★**外に在るものを当てにしない**（在る／無いで結果が変わる試験になる）。

★**復旧を自分で作らない。**書き込みの記録も、開いたときの自動復旧も、
**ライブラリ（SQLite）が持っている**（9-3）。★**持っているものを使い、使っていると書く。**

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb(root: String) -> DbHandle` | 記録の置き場。★**空ならメモリの上** | DB の在り処と、開けたかどうか |
| `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame(db: DbHandle, setup: Setup, path: String, name: String) -> Int` | DB、対局の設定、記録の在り処、名前 | ★**対局の番号**（DB が付ける）。入れられなければ 0 |
| `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove(db: DbHandle, gameId: Int, seq: Int, body: Body) -> Written` | DB、対局の番号、何手目か、手の中身 | 足せたかどうか。★**1 手ごとに呼ぶ** |
| `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame(db: DbHandle, gameId: Int, result: Result) -> Written` | DB、対局の番号、勝敗と枚数 | 終われたかどうか。★**ここで永続化する** |
| `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb(db: DbHandle, root: String, keep: Int) -> Int` | DB、置き場、★**残す代の数** | 残っている控えの数。★**古いものは消す** |
| `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame(db: DbHandle, path: String, name: String) -> Written` | DB、記録 1 本の在り処、★**対局の名前** | 入れられたかどうか（★**取り込み専用**。終わった記録を丸ごと入れる） |
| `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames(db: DbHandle, levels: List<Int>) -> Collected` | DB、対象の段 | ★**問い合わせで集めた対局**（段 5 の材料。CR-11） |
| `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames(db: DbHandle, limit: Int) -> List<GameHead>` | DB、出す数 | ★**新しい順の一覧**（再生で選ぶため。CR-10） |
| `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder(db: DbHandle, root: String) -> Int` | DB、記録の置き場 | ★**入れた本数**（★**同じ在り処は 2 度入らない**） |
| `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll(db: DbHandle) -> List<String>` | DB | ★**中身を人が読める形で、1 行ずつ**（対局と、その手） |
| `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump(db: DbHandle, root: String) -> String` | DB、置き場 | ★**書き出した在り処**。★**置き場が空なら、空の文字**（書かない） |
| `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves(db: DbHandle, gameId: Int) -> List<String>` | DB、対局の番号 | ★**置いた升の並び**（再生に使う） |

★**入れる単位は「終わった対局 1 本」である。**途中の対局は入れない——**閉じるまでは、まだ記録ではない。**

### 3.2 `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` の処理手順

1. 置き場が空なら、★**メモリの上に開く**（本で説明するため。CR-9 の 9-5）
1b. ★★**置き場そのものが無ければ、先に作る**——★**DB は「無ければ作る」が、置き場までは作らない**
2. 置き場が在れば、その下の `othello.db` を開く。無ければ作る。
   ★**このとき、書き込みの記録を取る方式を指定する**（§8.2b。★**開いた後では無視される**）
3. ★**`games` の表が無ければ作る**（§8.1b の欄のとおり。`id` は自動で番号が付く）
4. ★**`moves` の表が無ければ作る**（`game_id` が `games` の `id` を指す）
5. 在り処と、開けたかどうかを返す

★★**「無ければ作る」の範囲を取り違えない。**DB は作られるが、★**その入れ物（置き場）は作られない**——
★**置き場が無いと、開いた瞬間に落ちる。**

★**記録の口は置き場を作っていた**（対局を始めるとき）。★**だが起動の取り込みは、それより先に走る**——
∴ **新しい機械では、1 度も対局しないまま落ちる。**
★**実測 2026-08-13**: `path to '…\othello.db': '…\othello' does not exist`（BUG-49）。

★**表を作るのは、開くときの 1 か所である。**書くたびに作らない。

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb`
- 入口の語: `root`
- もし `置き場が空` なら「メモリの上」
- それ以外は「ファイルの上」
- 出口「メモリの上」は `contains:memory` で認める
- 出口「ファイルの上」は `contains:othello.db` で認める

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:openDb` の試験材料

- 入力 `root=""` のとき 特徴 `置き場が空=True`
- 入力 `root="runs"` のとき 特徴 `置き場が空=False`
- 出口「メモリの上」は `contains:memory` で認める
- 出口「ファイルの上」は `contains:othello.db` で認める

### 3.3b `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` の処理手順

1. `games` に 1 行入れる（打ち手・段・組・在り処・名前。★**勝敗はまだ空**）
2. ★**DB が付けた番号を返す**
3. 名前が空なら、時刻から作る

★**勝敗をまだ入れないのは、終わっていないからである。**★**終わっていない対局は、段 5 の材料にならない**（勝敗が空なので、問い合わせで外れる）。

★**対局の頭で 1 回だけ呼ぶ。**★**番号を、その対局のあいだ持ち回る。**

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame`
- 入口の語: `db`, `setup`, `path`, `name`
- もし `DBが開いていない` なら「入れない」
- それ以外は「番号」
- 出口「入れない」は `0` で認める
- 出口「番号」は `regex:^[1-9]` で認める

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:startGame` の試験材料

- 入力 `db={"path": "", "ok": False, "reason": ""}, setup={"black": "human", "white": "machine", "blackLevel": None, "blackParams": None, "whiteLevel": 3, "whiteParams": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, path="runs/g1.jsonl", name=""` のとき 特徴 `DBが開いていない=True`
- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, setup={"black": "human", "white": "machine", "blackLevel": None, "blackParams": None, "whiteLevel": 3, "whiteParams": {"weight": 1, "moves": 0, "stones": 0, "depth": 1, "endgame": 0, "author": False, "fallback": False, "games": 0}}, path="runs/g1.jsonl", name="ためし"` のとき 特徴 `DBが開いていない=False`
- 出口「入れない」は `0` で認める
- 出口「番号」は `regex:^[1-9]` で認める

### 3.3c `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` の処理手順

1. `moves` に 1 行入れる（対局の番号・何手目か・打った側・打ったのは誰か・升・裏返った数）
2. 足せたかどうかを返す

★**手の中身は、記録に書くものと同じである。**同じ言葉（打った側・打ったのは誰か・升・裏返った数）を、**記録にも DB にも入れる**——★**言い方を変えない**。

★★**1 手ごとに呼ぶ。**★**まとめて呼ばない**——**落ちたときに、打った手が消える**。
★**ここでは永続化しない**（書き込みの記録に出るところまで。[[DD-L3-othello-db]] §4.1b）。

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove`
- 入口の語: `db`, `gameId`, `seq`, `body`
- もし `対局の番号が無い` なら「足さない」
- それ以外は「足した」
- 出口「足さない」は `['ok']:False` で認める
- 出口「足した」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:addMove` の試験材料

- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, gameId=0, seq=1, body={"turn": "B", "by": "human", "square": "d3", "flips": "1"}` のとき 特徴 `対局の番号が無い=True`
- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, gameId=1, seq=1, body={"turn": "B", "by": "human", "square": "d3", "flips": "1"}` のとき 特徴 `対局の番号が無い=False`
- 出口「足さない」は `['ok']:False` で認める
- 出口「足した」は `['ok']:True` で認める

### 3.3d `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame` の処理手順

1. その対局の行に、勝敗と枚数を入れる
2. ★★**永続化する**（書き込みの記録を本体へ移す。[[DD-L3-othello-db]] §4.1）
3. 終われたかどうかを返す

★★**3 つに分けた理由。**——**対局の頭で 1 回、1 手ごとに 1 回、終わりに 1 回**、**やることが違う**からである。
**1 つの関数にまとめると、「いつ永続化するのか」が中に隠れる**——★**外から見て、いつ残るのかが分からなくなる**。

★**番号を持ち回るのは、窓口である。**対局の頭で受け取り、終わるまで持つ。
★**持ち回らずに毎回探すと、探す手がかり（在り処）を渡し続けることになる**。

★★**永続化するのは、ここだけである。**——★**1 ゲームの終わりに 1 回**。
**1 手ごとにやると遅くなり、やらないと落ちたときに戻せない。**

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame`
- 入口の語: `db`, `gameId`, `result`
- もし `対局の番号が無い` なら「終われない」
- それ以外は「終わった」
- 出口「終われない」は `['ok']:False` で認める
- 出口「終わった」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:finishGame` の試験材料

- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, gameId=0, result={"winner": "B", "black": 34, "white": 30}` のとき 特徴 `対局の番号が無い=True`
- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, gameId=1, result={"winner": "B", "black": 34, "white": 30}` のとき 特徴 `対局の番号が無い=False`
- 出口「終われない」は `['ok']:False` で認める
- 出口「終わった」は `['ok']:True` で認める

### 3.3e `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb` の処理手順

1. 置き場が空なら、★**何もしない**（控えの置き場が無い）
2. ★**古いほうから、番号をずらす**（2 代目を 3 代目へ、1 代目を 2 代目へ）
3. ★**残す代を超えたものは消す**
4. いまの DB を、いちばん新しい控えとして書き出す
5. 残っている控えの数を返す

★★**ずらしてから書く。**先に書くと、★**いちばん新しい控えが 2 つになる**か、**古いものが消えないまま溜まる**。

★**控えが取れなくても、対局は止めない**（[[DD-L2-othello-db]] §5）。
★**記録ファイルが残っているので、作り直せる**からである。

★**代の数は渡してもらう。**★**決め打ちにしない**——**試験で 1 代にして確かめられる**ようにするため。

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb`
- 入口の語: `db`, `root`, `keep`
- もし `置き場が空` なら「控えない」
- それ以外は「控えた数」
- 出口「控えない」は `0` で認める
- 出口「控えた数」は `regex:^[1-9]` で認める

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:backupDb` の試験材料

- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, root="", keep=3` のとき 特徴 `置き場が空=True`
- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, root="runs", keep=3` のとき 特徴 `置き場が空=False`
- 出口「控えない」は `0` で認める
- 出口「控えた数」は `regex:^[1-9]` で認める

### 3.3f `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll` の処理手順

1. 対局を**古い順に**取る
2. 1 対局につき 1 行にする（番号・時刻・名前・打ち手・段・勝敗・枚数）
2b. ★★**まだ終わっていない対局は「まだ」と出す**——★**引き分けの `-` と同じ顔にしない**
3. ★**その対局の手を、`seq` の順に 1 行で添える**
4. 並びにして返す

★★**書き出し先を、この関数が決めない。**★**返すだけ**である——
**画面に出すのか、ファイルにするのかは、呼ぶ側が決める。**

★**古い順に出す。**★**一覧（`shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames`）は新しい順**だが、**中身を読むときは起きた順のほうが追える。**

★★**空の欄を、決めた印で埋めない。**記録の側では★**引き分けを `-` と書く**と決めてある
（[[DD-L4-othello-log]]。**空にすると書き落としと見分けが付かない**から）。
∴ ★**ダンプで「勝者が無い」を `-` と出すと、引き分けと未完が同じ顔になる**。

★**実測 2026-08-13**: 対局中の 1 本が `winner=-` と出ており、引き分けと見分けが付かなかった（BUG-51）。

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll`
- 入口の語: `db`
- もし `一本も無い` なら「空」
- それ以外は「行の並び」
- 出口「空」は `[]` で認める
- 出口「行の並び」は `contains:games` で認める

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll` の試験材料

- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}` のとき 特徴 `一本も無い=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}` のとき 特徴 `一本も無い=False`
- 出口「空」は `[]` で認める
- 出口「行の並び」は `contains:games` で認める

### 3.3g `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump` の処理手順

1. 置き場が空なら、★**何もせず空の文字を返す**（書く先が無い）
2. `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:dumpAll(db: DbHandle) -> List<String>` を呼ぶ
3. 置き場の `othello-dump.txt` へ、1 行ずつ書く。★**上書きする**
4. 書いた在り処を返す

★**代を持たない。**★**中身は DB が持っている**ので、書き出したものは**いつでも作り直せる**——
控えを取るのは DB のほうであって、この写しではない（[[DD-L3-othello-db]] §4.1 の 7）。

★**形と先を、2 つの関数に分ける**（CR-13 の 13-3）——★**形だけを試験できる。**

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump`
- 入口の語: `db`, `root`
- もし `置き場が空` なら「書かない」
- それ以外は「在り処」
- 出口「書かない」は `regex:^$` で認める
- 出口「在り処」は `contains:othello-dump.txt` で認める

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:writeDump` の試験材料

- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, root=""` のとき 特徴 `置き場が空=True`
- 入力 `db={"path": ":memory:", "ok": True, "reason": ""}, root="C:/tmp"` のとき 特徴 `置き場が空=False`
- 出口「書かない」は `regex:^$` で認める
- 出口「在り処」は `contains:othello-dump.txt` で認める

### 3.3 `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` の処理手順

1. `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne(path: String) -> GameRecord` で、記録 1 本を読む
2. 壊れているか、終わっていなければ、★**入れない**
3. 名前が空なら、★**時刻から自動で付ける**（CR-9 の 9-2）
4. 同じ在り処が既に入っていれば、★★**撃つ前に見て、入れずに返す**（二重に数えないため）
5. 1 行入れて、入れられたかどうかを返す

★**4 が要る。**同じ対局を 2 度入れると、★**段 5 の勝率が二重に数えられる**。

★★**「撃って弾かれる」で済ませない。**入らないという結果は同じでも、★**番号だけは消費される**——
★**弾かれた分も、自動採番は進む**。
∴ **起動のたびに全部を撃ち直すと、番号がどんどん飛ぶ。**

★**実測 2026-08-13**: 対局 51 本に対し、いちばん大きい番号が **549** だった（BUG-50）。
★**入っている数は正しいのに、番号だけが 10 倍**である。

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame`
- 入口の語: `db`, `path`, `name`
- もし `終わっていない` なら「入れない」
- それ以外は「入れた」
- 出口「入れない」は `['ok']:False` で認める
- 出口「入れた」は `['ok']:True` で認める

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` の試験材料

- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, path="runs/none.jsonl", name=""` のとき 特徴 `終わっていない=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, path="runs/g1.jsonl", name="ためし"` のとき 特徴 `終わっていない=False`
- 出口「入れない」は `['ok']:False` で認める
- 出口「入れた」は `['ok']:True` で認める

### 3.4 `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames` の処理手順

1. ★**問い合わせで、終わった対局のうち、どちらかの側の段が対象のものを取る**
2. 取った行を、対局の器に組み直す。★**組の文字は、`Params` に戻す**
3. ★**ファイルから集めるときと同じ器**で返す（`Collected`）
4. 使えた数・壊れた数・外した数を添えて返す

★**返す形を、ファイルから集めるときと同じにする。**——★**呼ぶ側が「どちらから来たか」を知らなくてよい**ようにするため。

★★**数えるのは DB の仕事である**（CR-11）。**全部読んで数え直さない**——記録が増えるほど重くなるからである。

★**ファイルと DB の両方に在るときは、DB を見る**（CR-11 の 11-2）。

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames`
- 入口の語: `db`, `levels`
- もし `一本も無い` なら「空」
- それ以外は「集めた」
- 出口「空」は `['used']:0` で認める
- 出口「集めた」は `regex:^Collected` で認める

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:collectGames` の試験材料

- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, levels=[1, 2, 3, 4]` のとき 特徴 `一本も無い=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, levels=[3]` のとき 特徴 `一本も無い=False`
- 出口「空」は `['used']:0` で認める
- 出口「集めた」は `regex:^Collected` で認める

### 3.5 `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames` の処理手順

1. ★**新しい順に、決めた数だけ問い合わせる**（`id`・時刻・名前・黒白の段・勝敗）
2. 取った行を、一覧の器に組み直す
3. 並びにして返す

★**`id` を必ず入れる。**★**選ばれた対局を、番号で窓口へ渡す**からである（[[DD-L3-othello]] §7.1c の 3）。

★**全部は返さない。**記録は増え続けるので、**選ぶ窓に出せるだけ**を返す。

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames`
- 入口の語: `db`, `limit`
- もし `一本も無い` なら「空」
- それ以外は「並び」
- 出口「空」は `[]` で認める
- 出口「並び」は `regex:^\[` で認める

#### `shared/src/main/kotlin/othello/OthelloDbView.kt:OthelloDbView:listGames` の試験材料

- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, limit=20` のとき 特徴 `一本も無い=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, limit=1` のとき 特徴 `一本も無い=False`
- 出口「空」は `[]` で認める
- 出口「並び」は `regex:^\[` で認める

### 3.6 `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` の処理手順

1. 置き場に在る記録を 1 本ずつ見る
2. `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame(db: DbHandle, path: String, name: String) -> Written` を呼ぶ
3. 入った数を返す

★★**取り込みは、何度押しても安全である。**同じ対局が二重に入ると、**段 5 の勝率が二重に数えられ、選ばれる組が変わってしまう**。
∴ ★**記録の在り処を鍵にして、同じものは入れない**——**押した回数を利用者に数えさせない。**

★**取り込みは「置き場に在るものを、いまの DB に合わせる」だけである。**消したり、書き換えたりはしない。

★★**同じ在り処は 2 度入らない**（[[DD-L3-othello-log]] の「重複を避ける」）。
∴ **何度押しても、増えるのは新しい分だけ**である。

★**終わっていない記録は入らない。**入れる単位は「終わった対局 1 本」だから。

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder`
- 入口の語: `db`, `root`
- もし `置き場が空` なら「入れない」
- それ以外は「入れた数」
- 出口「入れない」は `0` で認める
- 出口「入れた数」は `regex:^[0-9]+$` で認める

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:importFolder` の試験材料

- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, root=""` のとき 特徴 `置き場が空=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, root="runs"` のとき 特徴 `置き場が空=False`
- 出口「入れない」は `0` で認める
- 出口「入れた数」は `regex:^[0-9]+$` で認める

### 3.7 `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves` の処理手順

1. ★**その対局の手を、`seq` の順に問い合わせる**（`game_id` で絞る）
2. 置いた升を、古い順に並べて返す

★**並べ替えを、こちら側でやらない。**★**`seq` の順に取る**と問い合わせに書く——
**取ってから並べ直すと、並べ直しを忘れても気づけない。**

★**再生は、この並びを使う**（CR-10）。★**記録ファイルを開き直さない**——
**入れるときに 1 度読んで、DB へ移してある。**

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves`
- 入口の語: `db`, `gameId`
- もし `一手も無い` なら「空」
- それ以外は「升の並び」
- 出口「空」は `[]` で認める
- 出口「升の並び」は `contains:d3` で認める

#### `shared/src/main/kotlin/othello/OthelloDb.kt:OthelloDb:readMoves` の試験材料

- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, gameId=999` のとき 特徴 `一手も無い=True`
- 入力 `db={"path": "othello.db", "ok": True, "reason": ""}, gameId=1` のとき 特徴 `一手も無い=False`
- 出口「空」は `[]` で認める
- 出口「升の並び」は `contains:d3` で認める

#### `shared/src/main/kotlin/othello/OthelloDbKeep.kt:OthelloDbKeep:saveGame` の呼ぶIF

- ★**同じ設計書の中の `shared/src/main/kotlin/othello/OthelloLogRead.kt:OthelloLogRead:readOne` を呼ぶだけ**なので、辺は宣言しない

---

## 3z2. ★書き出しの関数（★道つき・DSL）

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `shared/src/main/kotlin/othello/OthelloDump.kt:(module):main(args: Array<String>) -> Unit` | `args` = ★**書き出し先**（★空なら既定） | ★**無し**（★書き出すだけ） |

#### `shared/src/main/kotlin/othello/OthelloDump.kt:(module):main` の挙動宣言

- 対象コード: `shared/src/main/kotlin/othello/OthelloDump.kt:(module):main`
- 入口の語: `args`
- もし `行き先なし` なら「既定へ書く」
- それ以外は「指された所へ書く」
- 出口「既定へ書く」は `regex:^既定へ書く$` で認める
- 出口「指された所へ書く」は `regex:^指された所へ書く$` で認める
- ★**錨**: ★**記録を行にして書き出す**（DD-L3-othello-db §書き出し）

#### `shared/src/main/kotlin/othello/OthelloDump.kt:(module):main` の試験材料

- 入力 `args=[]` のとき 特徴 `行き先なし=True`
- 入力 `args=["C:/tmp/dump.txt"]` のとき 特徴 `行き先なし=False`
- 出口「既定へ書く」は `regex:^既定へ書く$` で認める
- 出口「指された所へ書く」は `regex:^指された所へ書く$` で認める

