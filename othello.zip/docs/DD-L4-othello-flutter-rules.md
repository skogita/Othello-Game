# DD-L4 関数仕様 — 盤の規則（Flutter 版）

- doc_id : DD-L4-othello-flutter-rules ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **盤の規則**（升の名前・盤という値・走査・置ける升）を、**Dart／Flutter の側**で持つ
- 出典 : [[DD-L3-othello]] §2（受け皿のうち規則の側）・§3（データ構造）
- 呼ぶ相手 : ★**無い。**盤の規則は、進行も画面も打ち手も知らない（呼ばれるだけ・[[DD-L2-othello]] §1.2）

---

## 0. なぜこの設計書が要るか

★★**Flutter 版のコードを、どの設計書も名乗っていなかった**（実測 2026-08-23）。
[[DD-L4-othello-rules]] が名乗るのは `shared/src/main/kotlin/othello/*.kt` であって、
`flutter/lib/*.dart` ではない。★**名乗る書が無いまま在るコードは、法の外に在る。**

★**姉妹として分ける**（[[DD-L3-rules]] §6.2）——★**対象コードが違うので二重所有にならない**。
★Kotlin 版は [[DD-L4-othello-rules]] が、★Dart 版は本書が名乗る。

## 0b. 言語を移したときに、何が変わって何が変わらなかったか

Kotlin の実装を Dart へ移した。**そのとき何が動いたかを残す**
（[[DD-L4-othello-rules]] §0b と同じ形で数える）。

| 変わらなかったもの | |
|:---|:---|
| 関数の分け方 | どのファイルに何を置くか。**1 つも動かしていない** |
| 入口と出口の項目 | 引数の名前も、並びも、意味も同じ |
| 処理手順 | ★**段の並びは 1 つも変えていない** |
| 挙動の宣言 | 条件も出口も、認めかたも同じ |
| 試験の材料 | 入力の値も、期待値も同じ |

| 変わったもの | |
|:---|:---|
| ファイルの名 | 綴りの決まりが違う（`OthelloSquare.kt` から `othello_square.dart` へ） |
| クラスの欄 | 同じ名の入れ物を Dart 側にも置いた |
| 型の名 | `List<String>` は同じ。`Int` は `int` になった |

★★**設計が言語に依っていなかったことが、ここでも確かめられた。**
手順を書き直す必要が出ていたなら、それは**設計に実装の都合が混ざっていた**ということである。

## 1. ファイルの分け方

| Dart のファイル | 何を持つか | Kotlin 版 |
|:---|:---|:---|
| `flutter/lib/othello_square.dart` | 升の名前と、行・列の行き来 | `OthelloSquare.kt` |
| `flutter/lib/othello_board.dart` | 盤という値 | `OthelloBoard.kt` |
| `flutter/lib/othello_scan.dart` | 走査（1 方向・8 方向） | `OthelloScan.kt` |
| `flutter/lib/othello_rules.dart` | 置ける升・置く・終局 | `OthelloRules.kt` |

★**規約は 1 ファイル 5 関数まで。**実測（2026-08-23）: 4 本とも **3 関数以内**、**60 行以内**。

## 2. 綴りの決め

名指しは**三要素**で書く。`道つきコード名:クラス:メソッド` である（法 §4-1）。
★Dart は入れ物を持つので、クラスの欄は**実在する入れ物の名**を書く。

## 3. 升の名前 — `flutter/lib/othello_square.dart`

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_square.dart:OthelloSquare:squareToRc(square: String) -> Step` | 升の名（`a1` の形） | 行と列と、読めたかどうか |
| `flutter/lib/othello_square.dart:OthelloSquare:rcToSquare(row: int, col: int) -> String` | 行、列 | 升の名。盤の外なら空の文字 |
| `flutter/lib/othello_square.dart:OthelloSquare:allSquares() -> List<String>` | 無し | 64 升の名を、決めた順で並べたもの |

### 3.2 `flutter/lib/othello_square.dart:OthelloSquare:squareToRc` の処理手順

1. 長さが 2 でなければ、読めなかったと分かる形で返す
2. 1 文字目を列に、2 文字目を行に直す
3. どちらかが範囲の外なら、読めなかったと分かる形で返す
4. 行と列を器に入れて返す

#### `flutter/lib/othello_square.dart:OthelloSquare:squareToRc` の挙動宣言

- 対象コード: `flutter/lib/othello_square.dart:OthelloSquare:squareToRc`
- 入口の語: `squareToRc`
- もし 升の名が 2 文字でない なら「読めない」
- もし 列か行が盤の外 なら「読めない」
- それ以外は「読めた」
- 出口「読めない」は `ok=False` で認める
- 出口「読めた」は `ok=True` で認める

#### `flutter/lib/othello_square.dart:OthelloSquare:squareToRc` の試験材料

- 入力 `square="a1"` のとき 特徴 `ok=True`・`row=0`・`col=0`
- 入力 `square="h8"` のとき 特徴 `ok=True`・`row=7`・`col=7`
- 入力 `square="z9"` のとき 特徴 `ok=False`
- 入力 `square="a"` のとき 特徴 `ok=False`

### 3.3 `flutter/lib/othello_square.dart:OthelloSquare:rcToSquare` の処理手順

1. 行か列が 0 から 7 の外なら、空の文字を返す
2. 列を文字に、行を数字に直してつなげ、返す

#### `flutter/lib/othello_square.dart:OthelloSquare:rcToSquare` の挙動宣言

- 対象コード: `flutter/lib/othello_square.dart:OthelloSquare:rcToSquare`
- 入口の語: `rcToSquare`
- もし 行か列が盤の外 なら「空」
- それ以外は「升の名」
- 出口「空」は `contains:False` で認める
- 出口「升の名」は `contains:True` で認める

#### `flutter/lib/othello_square.dart:OthelloSquare:rcToSquare` の試験材料

- 入力 `row=0, col=0` のとき 特徴 `名="a1"`
- 入力 `row=7, col=7` のとき 特徴 `名="h8"`
- 入力 `row=-1, col=0` のとき 特徴 `名=""`

### 3.4 `flutter/lib/othello_square.dart:OthelloSquare:allSquares` の処理手順

1. 行を 0 から 7 まで、列を 0 から 7 まで順に見る
2. その行・列の升の名を並びに積む
3. 並びを返す

★**順を決めておく。**決めないと、置ける升の並びが実行のたびに変わり、
**同じ盤面に同じ手を返す**という決め（[[DD-L1-othello]] §4）が守れない。

#### `flutter/lib/othello_square.dart:OthelloSquare:allSquares` の挙動宣言

- 対象コード: `flutter/lib/othello_square.dart:OthelloSquare:allSquares`
- 入口の語: `allSquares`
- 分岐は無い
- 出口「並び」は `contains:True` で認める

#### `flutter/lib/othello_square.dart:OthelloSquare:allSquares` の試験材料

- 入力 無し のとき 特徴 `件数=64`・`先頭="a1"`・`末尾="h8"`

## 4. 盤という値 — `flutter/lib/othello_board.dart`

### 4.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_board.dart:OthelloBoard:initialBoard() -> List<String>` | 無し | 初期配置の盤。中央の 4 石、黒が先手 |
| `flutter/lib/othello_board.dart:OthelloBoard:copyBoard(board: List<String>) -> List<String>` | 盤 | 同じ中身の**新しい**盤 |

### 4.2 `flutter/lib/othello_board.dart:OthelloBoard:initialBoard` の処理手順

1. 8 行 8 列の空の盤を作る
2. 中央の 4 升に、決めた並びで石を置く
3. 盤を返す

#### `flutter/lib/othello_board.dart:OthelloBoard:initialBoard` の挙動宣言

- 対象コード: `flutter/lib/othello_board.dart:OthelloBoard:initialBoard`
- 入口の語: `initialBoard`
- 分岐は無い
- 出口「盤」は `contains:True` で認める

#### `flutter/lib/othello_board.dart:OthelloBoard:initialBoard` の試験材料

- 入力 無し のとき 特徴 `行数=8`・`黒=2`・`白=2`

### 4.3 `flutter/lib/othello_board.dart:OthelloBoard:copyBoard` の処理手順

1. 行ごとに、同じ中身の新しい行を作る
2. 新しい盤を返す

★**渡された盤は書き換えない。**規則が新しい盤を返すので、戻す処理が要らない。

#### `flutter/lib/othello_board.dart:OthelloBoard:copyBoard` の挙動宣言

- 対象コード: `flutter/lib/othello_board.dart:OthelloBoard:copyBoard`
- 入口の語: `copyBoard`
- 分岐は無い
- 出口「新しい盤」は `contains:True` で認める

#### `flutter/lib/othello_board.dart:OthelloBoard:copyBoard` の試験材料

- 入力 `board=初期配置` のとき 特徴 `中身が同じ=True`・`同じ器=False`

## 5. 走査 — `flutter/lib/othello_scan.dart`

### 5.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_scan.dart:OthelloScan:scanLine(board: List<String>, row: int, col: int, dr: int, dc: int, turn: String) -> List<String>` | 盤、置く行・列、進む向き、手番 | その 1 方向で裏返る升の並び。無ければ空 |
| `flutter/lib/othello_scan.dart:OthelloScan:flips(board: List<String>, move: String, turn: String) -> List<String>` | 盤、置く升、手番 | 8 方向を合わせた、裏返る升の並び |

### 5.2 `flutter/lib/othello_scan.dart:OthelloScan:scanLine` の処理手順

1. 1 つ隣へ進む
2. 盤の外へ出たら、空を返す
3. 空升なら、空を返す
4. 相手の石なら、候補に積んでさらに進む
5. 自分の石に当たったら、積んだ候補を返す

★★**1 方向だけを見る関数として切り出す。**これを外に置かずに書くと、
「方向ごとの繰り返し」の中に「隣へ進む繰り返し」が入り、**4 段**になる。

#### `flutter/lib/othello_scan.dart:OthelloScan:scanLine` の挙動宣言

- 対象コード: `flutter/lib/othello_scan.dart:OthelloScan:scanLine`
- 入口の語: `scanLine`
- もし 盤の外へ出た なら「無し」
- もし 空升に当たった なら「無し」
- もし 自分の石に当たった なら「裏返る升」
- 出口「無し」は `contains:False` で認める
- 出口「裏返る升」は `contains:True` で認める

#### `flutter/lib/othello_scan.dart:OthelloScan:scanLine` の試験材料

- 入力 `board=初期配置, row=3, col=2, dr=0, dc=1, turn="B"` のとき 特徴 `件数=1`
- 入力 `board=初期配置, row=0, col=0, dr=0, dc=1, turn="B"` のとき 特徴 `件数=0`

### 5.3 `flutter/lib/othello_scan.dart:OthelloScan:flips` の処理手順

1. 升の名を行・列に直す。読めなければ空を返す
2. 8 方向それぞれについて `scanLine` を呼ぶ
3. 返った並びを 1 本につなげて返す

#### `flutter/lib/othello_scan.dart:OthelloScan:flips` の挙動宣言

- 対象コード: `flutter/lib/othello_scan.dart:OthelloScan:flips`
- 入口の語: `flips`
- もし 升の名が読めない なら「無し」
- それ以外は「裏返る升」
- 出口「無し」は `contains:False` で認める
- 出口「裏返る升」は `contains:True` で認める

#### `flutter/lib/othello_scan.dart:OthelloScan:flips` の試験材料

- 入力 `board=初期配置, move="d3", turn="B"` のとき 特徴 `件数=1`
- 入力 `board=初期配置, move="a1", turn="B"` のとき 特徴 `件数=0`

## 6. 置ける升 — `flutter/lib/othello_rules.dart`

### 6.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_rules.dart:OthelloRules:legalMoves(board: List<String>, turn: String) -> Moves` | 盤、手番 | 置ける升の並びと、その数 |
| `flutter/lib/othello_rules.dart:OthelloRules:applyMove(board: List<String>, move: String, turn: String) -> List<String>` | 盤、置く升、手番 | 置いて裏返した**新しい**盤 |
| `flutter/lib/othello_rules.dart:OthelloRules:isOver(board: List<String>) -> bool` | 盤 | 終局か |

### 6.2 `flutter/lib/othello_rules.dart:OthelloRules:legalMoves` の処理手順

1. 全ての升を順に見る
2. 空升でなければ飛ばす
3. `flips` を呼び、1 枚も裏返らなければ飛ばす
4. 裏返るなら、その升を並びに積む
5. 並びと数を器に入れて返す

★★**「置ける升が 1 つも無い」を、空の並びで返す。**呼ぶ側が数えるのではない
（[[DD-L1-othello]] §6.2）。

#### `flutter/lib/othello_rules.dart:OthelloRules:legalMoves` の挙動宣言

- 対象コード: `flutter/lib/othello_rules.dart:OthelloRules:legalMoves`
- 入口の語: `legalMoves`
- もし 1 つも置けない なら「無し」
- それ以外は「置ける升」
- 出口「無し」は `contains:False` で認める
- 出口「置ける升」は `contains:True` で認める

#### `flutter/lib/othello_rules.dart:OthelloRules:legalMoves` の試験材料

- 入力 `board=初期配置, turn="B"` のとき 特徴 `件数=4`
- 入力 `board=満杯の盤, turn="B"` のとき 特徴 `件数=0`

### 6.3 `flutter/lib/othello_rules.dart:OthelloRules:applyMove` の処理手順

1. `flips` を呼ぶ。1 枚も裏返らなければ、**渡された盤をそのまま返す**
2. 盤を写す
3. 置く升に自分の石を置く
4. 裏返る升を、自分の石に変える
5. 新しい盤を返す

★**渡された盤を書き換えない。**書き換えると、待ったのために**戻す処理**が要る。

#### `flutter/lib/othello_rules.dart:OthelloRules:applyMove` の挙動宣言

- 対象コード: `flutter/lib/othello_rules.dart:OthelloRules:applyMove`
- 入口の語: `applyMove`
- もし 1 枚も裏返らない なら「そのまま」
- それ以外は「置いた盤」
- 出口「そのまま」は `contains:False` で認める
- 出口「置いた盤」は `contains:True` で認める

#### `flutter/lib/othello_rules.dart:OthelloRules:applyMove` の試験材料

- 入力 `board=初期配置, move="d3", turn="B"` のとき 特徴 `黒=4`・`白=1`
- 入力 `board=初期配置, move="a1", turn="B"` のとき 特徴 `変わらない=True`

### 6.4 `flutter/lib/othello_rules.dart:OthelloRules:isOver` の処理手順

1. 黒の置ける升を数える
2. 白の置ける升を数える
3. どちらも 0 なら終局。そうでなければ終局でない

★★**「両者パス」で終わる。**盤が埋まったかどうかでは決めない
（[[DD-L1-othello]] §6.3）。

#### `flutter/lib/othello_rules.dart:OthelloRules:isOver` の挙動宣言

- 対象コード: `flutter/lib/othello_rules.dart:OthelloRules:isOver`
- 入口の語: `isOver`
- もし 黒も白も置けない なら「終局」
- それ以外は「続く」
- 出口「終局」は `is_true` で認める
- 出口「続く」は `is_false` で認める

#### `flutter/lib/othello_rules.dart:OthelloRules:isOver` の試験材料

- 入力 `board=初期配置` のとき 特徴 `終局=False`
- 入力 `board=満杯の盤` のとき 特徴 `終局=True`

## 7. 試験

★この一式の試験は `flutter/test/` に在る（`flutter test` で走る）。
★★**登録はしていない**（owner 指示 2026-08-23）。
★**実測 2026-08-23: 盤の規則と対局の進行で 42 件、全部合格。**
