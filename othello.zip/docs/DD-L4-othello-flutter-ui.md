# DD-L4 関数仕様 — 画面（Flutter 版）

- doc_id : DD-L4-othello-flutter-ui ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : **画面**（盤・わき・グラフ・始める窓・控えの窓・ヘルプ）を、**Dart／Flutter の側**で持つ
- 出典 : [[DD-L2-othello]]（画面は判定を持たない）・[[DD-L4-othello-ui]]（Kotlin 版の姉妹）
- 呼ぶ相手 : ★**無い。**画面は、受け取った一式を描き、触られたことを渡すだけ

---

## 0. なぜこの設計書が要るか

★★**Flutter 版のコードを、どの設計書も名乗っていなかった。**
[[DD-L4-othello-ui]] が名乗るのは `ui/src/commonMain/kotlin/othello/ui/*.kt` であって、
`flutter/lib/othello_*.dart` ではない。
★**姉妹として分ける**。★**対象コードが違うので二重所有にならない。**

## 0b. 言語を移したときに、何が変わって何が変わらなかったか

| 変わらなかったもの | |
|:---|:---|
| 画面の分け方 | ★**7 つのまま。1 つも動かしていない** |
| 触られたことを渡す口の数 | ★**14 のまま** |
| 処理手順 | ★**段の並びは 1 つも変えていない** |
| 画面は判定を持たない | 変わらない |

| 変わったもの | |
|:---|:---|
| ファイルの名 | `OthelloScreen.kt` から `othello_screen.dart` へ |
| 入れ物の種類 | Compose の関数から、Flutter の部品へ |
| 継承 | ★**Flutter の部品は継承で作る**。★これは枠組みの決まりであって、こちらの抽象ではない |

## 1. ファイルの分け方

| Dart のファイル | 何を持つか |
|:---|:---|
| `flutter/lib/othello_screen.dart` | ★**3 つを並べ**、触られたことを渡す |
| `flutter/lib/othello_board_view.dart` | ★**盤を描く**・升が押されたことを返す |
| `flutter/lib/othello_side_panel.dart` | ★**わきの補助情報とボタン** |
| `flutter/lib/othello_graph_view.dart` | ★**盤の下に形勢の線を描く**（★判定を持たない） |
| `flutter/lib/othello_setup_dialog.dart` | ★**始める前の窓**（誰が黒か・強さ） |
| `flutter/lib/othello_replay_dialog.dart` | ★**控えから選ぶ窓** |
| `flutter/lib/othello_help_screen.dart` | ★**遊び方を読む画面** |
| `flutter/lib/othello_touch.dart` | ★**触られたことを渡す口の束** |

★**実測（2026-08-23）**: 8 本とも **121 行以内**。

## 2. 綴りの決め

名指しは**三要素**で書く。★**Flutter の部品は入れ物を持つ**ので、クラスの欄は
**その部品の名**を書く（Kotlin 版が `(module)` と書いたところ）。

## 2b. 触られたことを渡す口は、器で持つ

★★**`interface` は使わない**（C 規約「interface 禁止（抽象・合成せよ）」）。
★**入れ替えたいのは「振る舞い」ではなく「渡し先」**である。
★**画面は判定を持たない**ので、★**渡す口の束を、そのまま器で受け取ればよい**。

| 欄 | 何を渡すか |
|:---|:---|
| `onSquare` | 押された升（`a1` の形） |
| `onPass` | パス |
| `onUndo` | 待った |
| `onNewGame` | ★**新しい対局**（★いつでも押せる） |
| `onMachineStep` | ★**計算機の 1 手**（★間を置いてから送る） |
| `onReplayList` | 控えの一覧を出す |
| `onReplayPick` | 控えから選んだ対局 |
| `onReplayNext` | 再生の 1 手 |
| `onImport` | 取り込み |
| `onDump` | 書き出し |
| `onHelp` | ヘルプを出す |
| `onCloseHelp` | ヘルプを閉じる |
| `onStart` | ★**始める決め**（誰が黒か・強さ・名） |
| `onCancelSetup` | 始める窓をやめる |

★**器の名は `OthelloTouch`**。★★**14 の口を 1 つの器で渡す**。★**引数を 14 個並べない**
（★並べると、呼ぶ側が順を覚える）。

## 3. 関数

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/othello_screen.dart:OthelloScreen:build(context: BuildContext) -> Widget` | 描く場 | 3 つを並べた画面。一式が無ければ始める窓 |
| `flutter/lib/othello_board_view.dart:OthelloBoardView:build(context: BuildContext) -> Widget` | 描く場 | 8 かける 8 の盤 |
| `flutter/lib/othello_side_panel.dart:OthelloSidePanel:build(context: BuildContext) -> Widget` | 描く場 | わきの補助情報とボタン |
| `flutter/lib/othello_graph_view.dart:OthelloGraphView:build(context: BuildContext) -> Widget` | 描く場 | 形勢の線 |
| `flutter/lib/othello_setup_dialog.dart:OthelloSetupDialog:build(context: BuildContext) -> Widget` | 描く場 | 始める前の窓 |
| `flutter/lib/othello_replay_dialog.dart:OthelloReplayDialog:build(context: BuildContext) -> Widget` | 描く場 | 控えから選ぶ窓 |
| `flutter/lib/othello_help_screen.dart:OthelloHelpScreen:build(context: BuildContext) -> Widget` | 描く場 | 遊び方の画面 |

★**渡すものは、部品の欄で受け取る**（一式・選び直し中か・控えの一覧・触られたことを渡す口）。

### 3.2 `flutter/lib/othello_screen.dart:OthelloScreen:build` の処理手順

1. ★**ヘルプを出す印が立っていれば、ヘルプの画面だけを出す**
2. ★**一式が無ければ、始める窓を出す**（★盤は描かない）
3. ★**選び直し中の印が立っていれば、始める窓を重ねて出す**
4. ★**控えの一覧を出す印が立っていれば、控えの窓を重ねて出す**
5. ★**在れば、盤・わき・グラフの 3 つを並べる**
6. ★**触られたことを、そのまま渡す**（★**画面は判定しない**）

★★**「対局が無い」と「選び直し中」を、同じ欄で兼ねない**。
★**兼ねると、やめても対局が無いことになり、また同じ窓が出る**（BUG-31・実測 2026-08-12）。

#### `flutter/lib/othello_screen.dart:OthelloScreen:build` の挙動宣言

- 対象コード: `flutter/lib/othello_screen.dart:OthelloScreen:build`
- 入口の語: `build`
- もし ヘルプの印が立っている なら「ヘルプ」
- もし 一式が無い なら「始める窓」
- もし 選び直し中 なら「始める窓」
- それ以外は「盤とわきとグラフ」
- 出口「ヘルプ」は `contains:True` で認める
- 出口「始める窓」は `contains:True` で認める
- 出口「盤とわきとグラフ」は `contains:True` で認める

#### `flutter/lib/othello_screen.dart:OthelloScreen:build` の試験材料

- 入力 `view=無し, choosing=False, helping=False` のとき 特徴 `始める窓=True`
- 入力 `view=初期の一式, choosing=False, helping=False` のとき 特徴 `盤=True`
- 入力 `view=初期の一式, choosing=True, helping=False` のとき 特徴 `始める窓=True`
- 入力 `view=初期の一式, choosing=False, helping=True` のとき 特徴 `ヘルプ=True`

### 3.3 `flutter/lib/othello_board_view.dart:OthelloBoardView:build` の処理手順

1. ★**8 かける 8 の升を描く**（★升の名は `a1` の形）
2. ★**石を描く**（黒・白）
3. ★**置ける升に印を付ける**（★一式が持っている一覧から。★**画面は数えない**）
4. ★**押された升を、名前で渡す**

#### `flutter/lib/othello_board_view.dart:OthelloBoardView:build` の挙動宣言

- 対象コード: `flutter/lib/othello_board_view.dart:OthelloBoardView:build`
- 入口の語: `build`
- 分岐は無い
- 出口「盤」は `contains:True` で認める

#### `flutter/lib/othello_board_view.dart:OthelloBoardView:build` の試験材料

- 入力 `view=初期の一式` のとき 特徴 `升=64`・`石=4`・`印=4`

### 3.4 `flutter/lib/othello_side_panel.dart:OthelloSidePanel:build` の処理手順

1. ★**手番・枚数・手数・直前の手・置ける升の数・強さを出す**
2. ★**ボタンを並べる**（パス・待った・新しい対局・計算機の 1 手・再生・取り込み・書き出し・★**ヘルプはいちばん下**）
3. ★**押されたことを、そのまま渡す**（★**押せるかどうかの判定も、ここではしない**）

★**押せるかどうかは、一式が持っている**（[[DD-L4-othello-flutter-play]] §7.2）。

#### `flutter/lib/othello_side_panel.dart:OthelloSidePanel:build` の挙動宣言

- 対象コード: `flutter/lib/othello_side_panel.dart:OthelloSidePanel:build`
- 入口の語: `build`
- 分岐は無い
- 出口「わき」は `contains:True` で認める

#### `flutter/lib/othello_side_panel.dart:OthelloSidePanel:build` の試験材料

- 入力 `view=初期の一式` のとき 特徴 `手番="B"`・`パスが押せる=False`・`待ったが押せる=False`

### 3.5 `flutter/lib/othello_graph_view.dart:OthelloGraphView:build` の処理手順

1. ★**手数を横、重みの積算値を縦にして線を引く**
2. ★★**判定を持たない**。★**優劣を書かない**（★見る人が読む）

#### `flutter/lib/othello_graph_view.dart:OthelloGraphView:build` の挙動宣言

- 対象コード: `flutter/lib/othello_graph_view.dart:OthelloGraphView:build`
- 入口の語: `build`
- 分岐は無い
- 出口「線」は `contains:True` で認める

#### `flutter/lib/othello_graph_view.dart:OthelloGraphView:build` の試験材料

- 入力 `trend=[0]` のとき 特徴 `点=1`
- 入力 `trend=[]` のとき 特徴 `点=0`

### 3.6 `flutter/lib/othello_setup_dialog.dart:OthelloSetupDialog:build` の処理手順

1. ★**黒と白のそれぞれを、人か計算機か選ばせる**（4 通り）
2. ★**強さを 6 段階から選ばせる**
3. ★**先手と後手を決めさせる**
4. ★**やめられるかは、渡された印で決める**（★**対局が無いときはやめられない**）

#### `flutter/lib/othello_setup_dialog.dart:OthelloSetupDialog:build` の挙動宣言

- 対象コード: `flutter/lib/othello_setup_dialog.dart:OthelloSetupDialog:build`
- 入口の語: `build`
- もし やめられる印が立っていない なら「やめる口の無い窓」
- それ以外は「やめられる窓」
- 出口「やめる口の無い窓」は `contains:False` で認める
- 出口「やめられる窓」は `contains:True` で認める

#### `flutter/lib/othello_setup_dialog.dart:OthelloSetupDialog:build` の試験材料

- 入力 `canCancel=False` のとき 特徴 `やめる口=False`
- 入力 `canCancel=True` のとき 特徴 `やめる口=True`

### 3.7 `flutter/lib/othello_replay_dialog.dart:OthelloReplayDialog:build` の処理手順

1. ★**控えの一覧を並べる**（★**終わった対局だけ**）
2. ★**選ばれた番号を渡す**

#### `flutter/lib/othello_replay_dialog.dart:OthelloReplayDialog:build` の挙動宣言

- 対象コード: `flutter/lib/othello_replay_dialog.dart:OthelloReplayDialog:build`
- 入口の語: `build`
- もし 控えが 1 件も無い なら「空の窓」
- それ以外は「一覧の窓」
- 出口「空の窓」は `contains:False` で認める
- 出口「一覧の窓」は `contains:True` で認める

#### `flutter/lib/othello_replay_dialog.dart:OthelloReplayDialog:build` の試験材料

- 入力 `games=[]` のとき 特徴 `件数=0`
- 入力 `games=[1 件]` のとき 特徴 `件数=1`

### 3.8 `flutter/lib/othello_help_screen.dart:OthelloHelpScreen:build` の処理手順

1. ★**遊び方・操作・ボタンの意味を並べる**（★**対局する人に向けたもの**）
2. ★**閉じられたことを渡す**

#### `flutter/lib/othello_help_screen.dart:OthelloHelpScreen:build` の挙動宣言

- 対象コード: `flutter/lib/othello_help_screen.dart:OthelloHelpScreen:build`
- 入口の語: `build`
- 分岐は無い
- 出口「ヘルプ」は `contains:True` で認める

#### `flutter/lib/othello_help_screen.dart:OthelloHelpScreen:build` の試験材料

- 入力 無し のとき 特徴 `閉じる口=True`

## 4. 試験

★★**画面の試験は、自動では作れない**（[[DD-L4-kt-unit-gen]] の決めと同じ形。
★**`@Composable` にあたるものが対象外**）。★**Flutter でも、部品を描く関数は
引数だけでは駆動できない**ので、★**部品の試験の枠組みで書く**。

★★**登録はしていない**（owner 指示 2026-08-23）。
