# DD-L4 関数仕様 — 入口（Flutter 版）

- doc_id : DD-L4-othello-flutter-bridge ／ design_level : L4 ／ 上位 : [[DD-L3-othello]]
- level_consumer : 実装する言語モデル／照合の契約
- 役割 : 端末の側の起点。状態を 1 か所で持ち、画面へ一式を渡し、触られたことを受ける
- 出典 : [[DD-L1-othello]] §6.4・§6.5・[[DD-L2-othello]] §7z・CR-6
- 呼ぶ相手 : `flutter/lib/othello_game.dart`・`othello_undo.dart`・`othello_view.dart`・
  `othello_ai.dart`・`othello_param.dart`・`othello_setup.dart`・`othello_weight.dart`

---

## 0. なぜこの設計書が要るか

★★**Flutter 版のコードを、どの設計書も名乗っていなかった。**
[[DD-L4-othello-bridge]] が名乗るのは Kotlin のファイルであって、`flutter/lib/main.dart` ではない。
★**姉妹として分ける**。★**対象コードが違うので二重所有にならない。**

## 0b. ここで一度、法を破った（是正の記録・2026-08-23）

★★**実測**: ★**計算機どうしにしても、手が打たれなかった**（owner が実機で確認）。

★**根**。★**[[DD-L1-othello]] §6.4「計算機どうしは終局まで自分で進む。1 手ごとに間を置く」を実装していなかった。**
★**押されたときに 1 手だけ進む形にしていた。**

★★**これは BUG-24 として一度直された欠陥である**（CR-6）。
★**Kotlin 版で直したものを、Dart 版で作り直した。**

★★**同時に、[[DD-L2-othello]] §7z の「次も計算機の番か」という欄を落としていた。**
★**この欄が無いと、画面が自分で判断することになる。**
★**「画面は判断しない」という決めが、実装で無効になっていた。**

★**是正**。★**一式に欄を足し**（[[DD-L4-othello-flutter-play]] §7.3 の段 5）、
★**入口が間を置いて次を送る**形にする（下の §3.4）。

## 1. ファイルの分け方

| Dart のファイル | 何を持つか |
|:---|:---|
| `flutter/lib/main.dart` | ★**状態を持つ 1 か所**。触られたことを受け、進行と打ち手へ渡す |

★**実測（2026-08-23）**: **190 行**。

★★**状態を持つのはここだけ。**★規則も進行も打ち手も画面も、状態を持たない。

## 2. 綴りの決め

名指しは三要素で書く。クラスの欄は実在する入れ物の名を書く。

## 3. 関数

### 3.1 インタフェース表

| 関数 | 引数の意味 | 戻り値の意味 |
|:---|:---|:---|
| `flutter/lib/main.dart:OthelloHost:build(context: BuildContext) -> Widget` | 描く場 | 一式を作って画面へ渡したもの |
| `flutter/lib/main.dart:OthelloHost:onStart(black: String, white: String, blackLevel: int, whiteLevel: int, name: String) -> void` | 誰が黒か・強さ・名 | 無し（状態を入れ替える） |
| `flutter/lib/main.dart:OthelloHost:onSquare(square: String) -> void` | 押された升 | 無し（状態を入れ替える） |
| `flutter/lib/main.dart:OthelloHost:onMachineStep() -> void` | 無し | 無し（計算機の 1 手を進める） |
| `flutter/lib/main.dart:OthelloHost:scheduleMachine(view: View) -> void` | いまの一式 | 無し（★**次も計算機なら、間を置いて次を送る**） |

### 3.2 `flutter/lib/main.dart:OthelloHost:build` の処理手順

1. 状態が無ければ、一式も無いものとして画面へ渡す
2. 状態が在れば、`buildView` を呼んで一式を作る
3. ★**その一式を見て、次も計算機の番なら、間を置いて次の 1 手を送る段取りをする**
4. 一式と、触られたことを渡す口の束を、画面へ渡す

#### `flutter/lib/main.dart:OthelloHost:build` の挙動宣言

- 対象コード: `flutter/lib/main.dart:OthelloHost:build`
- 入口の語: `build`
- もし 状態が無い なら「一式なしの画面」
- それ以外は「一式つきの画面」
- 出口「一式なしの画面」は `contains:False` で認める
- 出口「一式つきの画面」は `contains:True` で認める

#### `flutter/lib/main.dart:OthelloHost:build` の試験材料

- 入力 `state=無し` のとき 特徴 `一式=None`
- 入力 `state=初期状態` のとき 特徴 `一式=あり`

### 3.3 `flutter/lib/main.dart:OthelloHost:onSquare` の処理手順

1. 状態が無ければ、何もしない
2. 進行に打たせる
3. 打てたなら状態を入れ替え、★**重みの積算値を積む**
4. 打てなかったなら、返ってきた文言を画面へ出す

★**画面は数えない**ので、形勢の値はここで作って渡す。

#### `flutter/lib/main.dart:OthelloHost:onSquare` の挙動宣言

- 対象コード: `flutter/lib/main.dart:OthelloHost:onSquare`
- 入口の語: `onSquare`
- もし 状態が無い なら「何もしない」
- もし 打てなかった なら「文言だけ」
- それ以外は「進んだ」
- 出口「何もしない」は `contains:False` で認める
- 出口「文言だけ」は `contains:True` で認める
- 出口「進んだ」は `contains:True` で認める

#### `flutter/lib/main.dart:OthelloHost:onSquare` の試験材料

- 入力 `state=無し, square="d3"` のとき 特徴 `変わらない=True`
- 入力 `state=初期状態, square="d3"` のとき 特徴 `手数=1`
- 入力 `state=初期状態, square="a1"` のとき 特徴 `手数=0`・`文言=あり`

### 3.4 `flutter/lib/main.dart:OthelloHost:scheduleMachine` の処理手順

1. ★**一式が「次も計算機の番」と言っていなければ、何もしない**
2. ★**終局していれば、何もしない**
3. ★**すでに段取り済みなら、二重に段取りしない**
4. ★**間を置く**（盤が見えるだけの長さ）
5. ★**間を置いたあと、計算機の 1 手を送る**

★★**間を置くのは画面の側である。**★**共通は時計を見ない。**★**ここが「画面の側」にあたる。**

★★**3 が要る。**★同じ手番で二度段取りすると、**1 手のあいだに 2 回打つ**ことになる。

★★**1 の判断を、ここでしない。**★**一式が言う**（[[DD-L2-othello]] §7z）。
★**ここで手番と設定を見比べると、判断が 2 か所になる。**

#### `flutter/lib/main.dart:OthelloHost:scheduleMachine` の挙動宣言

- 対象コード: `flutter/lib/main.dart:OthelloHost:scheduleMachine`
- 入口の語: `scheduleMachine`
- もし 次も計算機でない なら「送らない」
- もし 終局している なら「送らない」
- もし すでに段取り済み なら「送らない」
- それ以外は「間を置いて送る」
- 出口「送らない」は `contains:False` で認める
- 出口「間を置いて送る」は `contains:True` で認める

#### `flutter/lib/main.dart:OthelloHost:scheduleMachine` の試験材料

- 入力 `view=(次も計算機=False)` のとき 特徴 `送る=False`
- 入力 `view=(次も計算機=True, 終局=True)` のとき 特徴 `送る=False`
- 入力 `view=(次も計算機=True, 終局=False), 段取り済み=True` のとき 特徴 `送る=False`
- 入力 `view=(次も計算機=True, 終局=False), 段取り済み=False` のとき 特徴 `送る=True`

### 3.5 `flutter/lib/main.dart:OthelloHost:onMachineStep` の処理手順

1. 状態が無ければ、何もしない
2. ★**いまの時刻を取り**、`machineStep` を呼ぶ（[[DD-L4-othello-flutter-play]] §8）
3. 進められなければ、返ってきた理由を出して終わる
4. 進められたら、新しい状態に入れ替え、★**打った手なら重みの積算値を積む**

★★**時計を見るのはここである**（[[DD-L4-othello-flutter-ai]] §7.2）。
★**打ち手は時計を見ない**ので、★**入口が取って渡す。**

★★**手が無いときのパスは、`machineStep` の中で起きる。**★**ここで分岐を持たない**
——★**置けない番の担当がパスする**という決めは、進行の側が持つ。

★★**是正 2026-08-23**: ★**前は「手が決められなければ文言だけ」と書いていた。**
★**それだと、計算機どうしのとき、置ける升が無くなった時点で止まる。**
★**Kotlin 版は `OthelloTurn.machineStep` の中でパスしている**（owner 指摘「kt の実装みよ」）。

#### `flutter/lib/main.dart:OthelloHost:onMachineStep` の挙動宣言

- 対象コード: `flutter/lib/main.dart:OthelloHost:onMachineStep`
- 入口の語: `onMachineStep`
- もし 状態が無い なら「何もしない」
- もし 手番が計算機でない なら「文言だけ」
- もし 手が決められない なら「文言だけ」
- それ以外は「打った」
- 出口「何もしない」は `contains:False` で認める
- 出口「文言だけ」は `contains:True` で認める
- 出口「打った」は `contains:True` で認める

#### `flutter/lib/main.dart:OthelloHost:onMachineStep` の試験材料

- 入力 `state=無し` のとき 特徴 `変わらない=True`
- 入力 `state=初期状態, setup=(human, machine, 4, 4)` のとき 特徴 `文言=あり`・`手数=0`
- 入力 `state=初期状態, setup=(machine, machine, 4, 4)` のとき 特徴 `手数=1`

### 3.6 `flutter/lib/main.dart:OthelloHost:onStart` の処理手順

1. 渡された決めで設定を作る
2. 新しい状態を作る
3. 選び直し中の印を下ろす
4. 形勢の並びを空にして、0 を 1 つ置く

★★**「対局が無い」と「選び直し中」を、別の欄で持つ**（BUG-31）。

#### `flutter/lib/main.dart:OthelloHost:onStart` の挙動宣言

- 対象コード: `flutter/lib/main.dart:OthelloHost:onStart`
- 入口の語: `onStart`
- 分岐は無い
- 出口「始まった」は `contains:True` で認める

#### `flutter/lib/main.dart:OthelloHost:onStart` の試験材料

- 入力 `black="human", white="machine", blackLevel=4, whiteLevel=4, name="test"` のとき 特徴 `手数=0`・`選び直し中=False`

## 4. この版で持っていないもの

| 何 | どうしているか |
|:---|:---|
| 取り込み | ★**「この版では持ちません」と画面に出す**。★**黙って何もしない、をしない** |
| 書き出し | 同上 |
| 控えの一覧 | ★**空の一覧を渡す**（窓は出るが、並ぶものが無い） |
| 再生の 1 手 | ★**持たない** |

★★**持っていないことを、持っている顔にしない。**★押しても何も起きないと、
**壊れているのか、無いのかが分からない。**

## 5. 試験

★試験は `flutter/test/` に在る。★★**登録はしていない**（owner 指示 2026-08-23）。
