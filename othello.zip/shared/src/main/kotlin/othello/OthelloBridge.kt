package othello

/**
 * 境の窓口。出来事を 1 つ受け取り、一式を 1 つ返す。
 *
 * 設計: DD-L4-othello-bridge §3 ／ 決めは DD-L2-othello §7z
 * ★判定を持たない。画面を知らない。状態を抱え込まない。
 * ★受理されなかったときも一式を返す——画面が古い一式を持ったままにならないように。
 */
object OthelloBridge {

    // ★窓口が受けるのは 5 つ（DD-L4-othello-bridge §3）。「新しい対局」は口が受ける
    /** ★控えを残す代の数（DD-L2-othello-db §5）。 */
    const val KEEP = 3

    // ★ヘルプも「決めた出来事」である（DD-L4-othello-bridge §3.2 の 5i・5j／RF-64）。
    //   ★入れ忘れると手順 1 で断られ、押しても何も起きない形になる。
    private val KINDS = listOf("square", "pass", "undo", "start", "machine",
        "replay", "next", "games", "import", "dump", "help", "closeHelp")
    /** ★一覧に出す数の上限（DD-L4-othello-bridge §3.2 の 5f）。 */
    private const val SHOWN = 50

    /** 新しい状態と一式を返す。受理されなければ、状態を変えずに理由を返す。 */
    fun handle(state: State, setup: Setup, event: Command, root: String): Handled {
        if (!KINDS.contains(event.kind)) {
            return Handled(false, state, "決めていない出来事なので受け付けない",
                OthelloView.buildView(state, setup))
        }
        val before = state.history.size
        // ★枝は外へ出した（DD-L4-othello-bridge §2）。★ここは「通る道」だけを持つ
        val got = OthelloBridgeEvent.apply(state, setup, event, root)
        val moved = if (got.ok && got.state != null) got.state else state
        // ★計算機の番なら 1 手だけ進める（CR-6）。続けて回すと一瞬で終わり、何も見えない。
        //   次も計算機なら、一式がそう言う——間を置いて次を送るのは画面である。
        // ★再生中は打ち手を呼ばない（CR-10 の 10-3）。手は記録に在る
        //   ★この枝はどの出来事のあとでも走る——止めないと、並びを使い切ったあとも打ち続ける（BUG-47）
        val replaying = moved.replay.isNotEmpty() || event.kind == "replay" || event.kind == "next"
        val stepped = if (!replaying && OthelloSetup.isMachineTurn(setup, moved.turn))
            OthelloTurn.machineStep(moved, setup) else null
        val next = if (stepped != null && stepped.ok && stepped.state != null)
            stepped.state else moved
        // ★後始末は外へ出した（DD-L4-othello-bridge §2）。★ここは「通る道」だけを持つ
        // ★形勢の並びを、伸ばすか切り詰めるか（CR-8・DD-L3-othello-graph §5.2）
        val drawn = OthelloBridgeAfter.drawn(next, setup, event, got.ok)
        // ★再生は対局ではない。記録も DB も触らない（CR-10 の 10-5）
        val log = if (drawn.replay.isNotEmpty() || event.kind == "replay") null else drawn.log
        // ★受理されたなら 1 件書き足し、終局していれば閉じる（DD-L2-othello §7z.2b3）
        //   ★関数が在ることと、呼ばれることは別である——BUG-25 はここが空だった
        val wrote = if (log == null || !log.ok || !got.ok) drawn
            else recordMove(drawn, log, setup, if (event.kind == "start") 0 else before)
        OthelloBridgeAfter.closed(wrote, log, root, KEEP)
        val shown = OthelloBridgeAfter.told(OthelloView.buildView(wrote, setup), event, root, SHOWN)
        return Handled(got.ok, wrote, got.reason, shown)
    }

    /** 対局を始めるなら記録を開く。置き場が空なら開かない。 */
    fun opened(setup: Setup, root: String): State {
        val fresh = OthelloState.newState()
        if (root == "") return fresh
        val log = OthelloLogWrite.openLog(setup, root)
        // ★対局の番号を、対局の頭で受け取る（DD-L3-othello-db §4.1）
        // ★名前は対局の設定が持っている（CR-9 の 9-2）。空なら DB の側で日時が入る
        val id = OthelloDb.startGame(OthelloDb.openDb(root), setup, log.path, setup.name)
        return fresh.copy(log = log, gameId = id)
    }

    /** 記録の在り処から、その置き場の DB を得る。 */
    private fun dbOf(log: LogHandle): DbHandle =
        OthelloDb.openDb(java.io.File(log.path).parent ?: "")

    /** 増えた手を全部書き足し、終局していれば勝敗を書いて閉じる。閉じたら手を離す。 */
    fun recordMove(state: State, log: LogHandle, setup: Setup, from: Int): State {
        // ★1 回の出来事で 2 手進むことがある。末尾だけ書くと人の手が残らない（BUG-30）
        for ((i, entry) in state.history.drop(from).withIndex()) {
            val mover = entry.before.turn
            val by = if (OthelloSetup.isMachineTurn(setup, mover)) "machine" else "human"
            val body = mapOf("turn" to mover, "by" to by,
                "square" to entry.move, "flips" to entry.flips.size.toString())
            OthelloLogWrite.appendEvent(log, "move", body)
            // ★1 手ごとに DB へも足す（DD-L3-othello-db §4.1 の 3）
            // ★seq は「何手目か」（DD-L3-othello-db §3）。★繰り返しの中で 1 ずつ増える
            //   ★`from + 1` は繰り返しの中で変わらない——2 手進むと同じ番号で入る（2026-08-18）
            if (state.gameId > 0) OthelloDb.addMove(dbOf(log), state.gameId, from + i + 1, body)
        }
        if (!OthelloRules.isOver(state.board)) return state
        val stones = OthelloState.countStones(state.board)
        val winner = if (stones.b > stones.w) "B" else if (stones.w > stones.b) "W" else "-"
        OthelloLogWrite.closeLog(log, Result(winner, stones.b, stones.w))
        return state.copy(log = null)
    }
}
