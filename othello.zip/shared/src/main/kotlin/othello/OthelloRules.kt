package othello

/**
 * 盤の規則。盤と手番を受け取り、答えを返す。状態を持たない。
 *
 * 設計: DD-L4-othello-rules §6
 */
object OthelloRules {

    /** 置ける升と、数えたことの印を持つ器を返す。 */
    fun legalMoves(board: List<String>, turn: String): Moves =
        Moves(OthelloSquare.allSquares().filter { OthelloScan.flips(board, it, turn).isNotEmpty() }, true)

    /** 置いた後の新しい盤。裏返る升が無ければ、盤を変えずに返す。 */
    fun applyMove(board: List<String>, move: String, turn: String): List<String> {
        val got = OthelloScan.flips(board, move, turn)
        if (got.isEmpty()) return board
        val newBoard = OthelloBoard.copyBoard(board).toMutableList()
        for (square in listOf(move) + got) {
            val rc = OthelloSquare.squareToRc(square)
            val line = newBoard[rc.first]
            newBoard[rc.first] = line.substring(0, rc.second) + turn + line.substring(rc.second + 1)
        }
        return newBoard
    }

    /** 両者とも置ける升が無ければ真。 */
    fun isOver(board: List<String>): Boolean =
        legalMoves(board, "B").moves.isEmpty() && legalMoves(board, "W").moves.isEmpty()
}
