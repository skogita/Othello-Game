package othello

/**
 * 対局の設定。黒白それぞれの打ち手と強さの段を持つ。盤も進行も知らない。
 *
 * 設計: DD-L4-othello-play §7
 * ★段からパラメータを引くのは、ここ 1 回だけである（DD-L2-othello-ai §1.2）。
 */
object OthelloSetup {

    private val PLAYERS = listOf("human", "machine")

    /** 対局の設定。パラメータの組を含む。受け付けられないときは空の器。 */
    fun newSetup(black: String, white: String, blackLevel: Int, whiteLevel: Int,
                 root: String, name: String): Setup {
        val none = Setup("", "", null, null, null, null)
        if (!PLAYERS.contains(black) || !PLAYERS.contains(white)) return none
        // ★段は側ごとに受け取り、組も側ごとに引く（CR-12）。人の側は持たない
        if (black == "machine" && (blackLevel < 1 || blackLevel > 6)) return none
        if (white == "machine" && (whiteLevel < 1 || whiteLevel > 6)) return none
        return Setup(black, white,
            if (black == "machine") blackLevel else null,
            if (black == "machine") OthelloParam.levelParams(blackLevel, root) else null,
            if (white == "machine") whiteLevel else null,
            if (white == "machine") OthelloParam.levelParams(whiteLevel, root) else null,
            // ★名前は判定に使わない。そのまま載せるだけ（CR-9 の 9-2）
            name)
    }

    /** いまの手番が計算機かどうか。 */
    fun isMachineTurn(setup: Setup, turn: String): Boolean =
        if (turn == "B") setup.black == "machine" else setup.white == "machine"
}
