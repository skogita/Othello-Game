package othello

/**
 * 後始末。どの出来事のあとでも走る部分だけを持つ。
 *
 * 設計: DD-L4-othello-bridge §2 ／ 決めは DD-L3-othello §2
 *
 * ★2026-08-15 に `OthelloBridge.handle` から切り出した（2 度目）。
 *   ★1 度目は「出来事ごとの枝」を出して 37 → 31 まで下げたが、規約（20）に届かなかった。
 *   ★残っていたのは「枝」ではなく「後始末」——出来事の種類では分かれない部分である。
 * ★「割った」ことと「収まった」ことは別。★割ったら必ず撃って、数で確かめる。
 */
object OthelloBridgeAfter {

    /** 形勢の並びを伸ばす／切り詰める（CR-8）。★待ったなら手数に合わせて切る。 */
    fun drawn(state: State, setup: Setup, event: Command, ok: Boolean): State {
        if (event.kind == "undo")
            return state.copy(trend = OthelloGraph.trimmed(state.trend, state.moves))
        if (!ok) return state
        val machine = setup.blackParams != null || setup.whiteParams != null
        return state.copy(trend = OthelloGraph.appended(state.trend, state.board, machine))
    }

    /**
     * 記録を閉じたなら、DB を終わらせて永続化し、控えを取る（CR-9・DD-L3-othello-db §4.1）。
     *
     * ★閉じていなければ何もしない。★ここで永続化される。
     */
    fun closed(state: State, log: LogHandle?, root: String, keep: Int) {
        if (log == null || state.log != null || root == "" || state.gameId <= 0) return
        val db = OthelloDb.openDb(root)
        val stones = OthelloState.countStones(state.board)
        val winner = if (stones.b > stones.w) "B" else if (stones.w > stones.b) "W" else "-"
        OthelloDb.finishGame(db, state.gameId, Result(winner, stones.b, stones.w))
        OthelloDbKeep.backupDb(db, root, keep)
    }

    /**
     * 一覧・取り込み・書き出しの結果を、一式の文言に載せる。
     *
     * ★文言は一式の欄に入れる——★拒否の理由は画面に出ていないので、そこへ入れると押しても何も出ない（BUG-48）。
     * ★当てはまらない出来事なら、受け取った一式をそのまま返す。
     */
    fun told(view: View, event: Command, root: String, shown: Int): View = when (event.kind) {
        "games" -> {
            val list = OthelloDbView.listGames(OthelloDb.openDb(root), shown)
            view.copy(games = list,
                message = if (list.isEmpty()) "まだ記録がありません" else "")
        }
        "import" ->
            view.copy(message = "" + OthelloDbKeep.importFolder(OthelloDb.openDb(root), root) +
                " 本を取り込みました")
        "dump" -> {
            val db = OthelloDb.openDb(root)
            val at = OthelloDbView.writeDump(db, root)
            view.copy(message = if (at == "") "書き出す先がありません"
                else "" + OthelloDbView.dumpAll(db).size + " 行を書き出しました: " + at)
        }
        else -> view
    }
}
