package othello

/**
 * 形勢の線グラフ（CR-8）。
 *
 * 設計: DD-L4-othello-graph ／ 決めは DD-L3-othello-graph
 * ★枚数ではなく、升の重みの積算値。★両方の側を、同じ 1 つの表で測る。
 * ★メモリの中だけ・その対局のあいだだけ。記録には残さない。
 */
object OthelloGraph {

    /** その側の石が乗っている升の、重みの積算値。 */
    fun weightSum(board: List<String>, side: String): Int {
        var total = 0
        for (row in 0..7) {
            for (col in 0..7) {
                if (board[row][col].toString() != side) continue
                // ★段で表を切り替えない。いつも同じ物差し（CR-12）
                total += OthelloWeight.weightOf(row, col)
            }
        }
        return total
    }

    /** 2 本の並びの末尾へ、1 つずつ足す。★段の組が無ければ、そのまま返す。 */
    fun appended(now: Trend, board: List<String>, machine: Boolean): Trend {
        if (!machine) return now
        return Trend(now.black + weightSum(board, "B"), now.white + weightSum(board, "W"))
    }

    /** 手数に合わせて切り詰める。★0 手目を含むので、残すのは 手数 + 1。 */
    fun trimmed(now: Trend, moves: Int): Trend {
        val keep = moves + 1
        if (now.black.size <= keep) return now
        return Trend(now.black.take(keep), now.white.take(keep))
    }
}
