package othello

/**
 * 計算機の番。打ち手に聞いて 1 手進める。どう選ぶかは持たない。
 *
 * 設計: DD-L4-othello-play §8
 * ★この関数は盤を読まない。置ける升の判定も、裏返しも、全部よそが持っている。
 */
object OthelloTurn {

    /** 進めたかと、新しい状態か理由。 */
    fun machineStep(state: State, setup: Setup): Stepped {
        if (!OthelloSetup.isMachineTurn(setup, state.turn)) {
            return Stepped(false, false, null, "人の番なので進めない")
        }
        val chosen = // ★打つ側の組を使う（CR-12）。間違えると相手の強さで打つ
        OthelloAi.chooseMove(state.board, state.turn,
            if (state.turn == "B") setup.blackParams else setup.whiteParams)
        if (chosen.move == "") {
            val passed = OthelloGame.passTurn(state)
            return Stepped(passed.ok, true, passed.state, chosen.reason)
        }
        val played = OthelloGame.play(state, chosen.move)
        return Stepped(played.ok, false, played.state, "")
    }
}
