package othello

/**
 * 共通が使う型。
 *
 * 設計: DD-L3-othello §3（データ構造）／DD-L4-othello-rules §2a
 * ★型の名に読点を入れない——記法が引数を読点で区切るため。
 */

/** 向きの組。行の増分と列の増分。 */
typealias Step = Pair<Int, Int>

/**
 * 置ける升の答え。
 *
 * ★[moves] が空であることと、まだ数えていないことを、受け取った側が言い分けられるようにする器。
 * [counted] が真なら「数えた結果 0 か所」、偽なら「数えていない」（DD-L3-othello §3.4）。
 */
data class Moves(val moves: List<String>, val counted: Boolean)

/** 段ごとのパラメータの組。★係数が 0 なら、その見方は効かない。 */
@kotlinx.serialization.Serializable
data class Params(
    val weight: Int,
    val mobility: Int,
    val stones: Int,
    val depth: Int,
    val endgame: Int,
    val fallback: Boolean,
    val chosen: Boolean,
    val games: Int,
    /** ★段 6（著者方式）か。真なら升ごとの点の表だけで打つ（DD-L3-othello-ai §3.1b）。 */
    val author: Boolean = false
)

/** 対局の設定。★段とパラメータは、計算機が居るときだけ持つ。 */
data class Setup(
    val black: String,
    val white: String,
    /** ★黒の段と組。黒が人なら無し（CR-12）。 */
    val blackLevel: Int?,
    val blackParams: Params?,
    /** ★白の段と組。白が人なら無し。 */
    val whiteLevel: Int?,
    val whiteParams: Params?,
    /** ★対局の名前（任意。CR-9 の 9-2）。★空なら、DB の側で日時が入る。 */
    val name: String = ""
)

/** 記録の中身。★言語をまたぐので、値は文字にして持つ。 */
typealias Body = Map<String, String>

/** ★組どうしの対（DD-L3-othello-ai §3.4b）。★相手の違うものを同じ列に足さないための鍵。 */
data class Duel(val one: Params, val other: Params?)   // ★`other` が無しなら相手は人（BUG-32）

/** ★対ごとの数え（`one` の勝ち数と、その対の局数）。読点を含む型なので別名を付ける（DD-L4-othello-ai §2）。 */
typealias Tally = MutableMap<Duel, Pair<Int, Int>>

/** 記録の 1 件。★1 行 1 件。行をまたがない（DD-L3-othello-log §3.1）。 */
@kotlinx.serialization.Serializable
data class Event(val at: String, val kind: String, val body: Map<String, String>)

/** ★DB の在り処と、開けたかどうか（CR-9）。 */
data class DbHandle(val path: String, val ok: Boolean, val reason: String)

/** 記録の在り処と、書けたかどうか。 */
data class LogHandle(val path: String, val ok: Boolean, val reason: String)

/** 書けたかどうか。★例外を投げない（DD-L2-othello-log §3.3）。 */
data class Written(val ok: Boolean, val reason: String)

/** 勝敗と、黒白の最終の枚数。 */
data class Result(val winner: String, val black: Int, val white: Int)

/** 読み出した 1 対局。★途中で終わったか、壊れているかが分かる形（DD-L3-othello-log §3.4）。 */
data class GameRecord(
    val path: String,
    val broken: Boolean,
    val finished: Boolean,
    val level: Int?,
    val params: Params?,
    val result: Result?,
    /** ★黒白の打ち手。段 5 が「計算機の側が勝ったか」を数えるのに要る。 */
    val black: String? = null,
    val white: String? = null,
    /** ★白の段と組。段どうしを戦わせた記録だけが持つ（DD-L4-othello-log §7）。 */
    val whiteLevel: Int? = null,
    val whiteParams: Params? = null
)

/** ★一覧の 1 行（再生で選ぶため。CR-10）。 */
data class GameHead(val id: Int, val startedAt: String, val name: String,
                    val black: String, val white: String,
                    val blackLevel: Int?, val whiteLevel: Int?, val winner: String)

/** 集めた記録と、使えた数・外した数・壊れた数。★分母をこちらの都合で決めない。 */
data class Collected(val games: List<GameRecord>, val used: Int, val broken: Int, val dropped: Int)

/** 並びの順が正しいかと、崩れている場所。 */
data class Order(val ok: Boolean, val at: Int, val reason: String)

/** 読んだ結果。★点と升を一緒に返す（DD-L3-othello-ai §3.3）。 */
data class Searched(val score: Int, val move: String)

/** 打ち手の答え。次に置く升と、決められたかどうか。 */
data class Chosen(val ok: Boolean, val move: String, val reason: String)

/** 置く前の状態。★履歴そのものは入れない（入れ子が深くなる）。 */
data class Before(val board: List<String>, val turn: String, val moves: Int, val passes: Int)

/** 履歴の 1 件。置いた升・裏返った升・置く前の状態。 */
data class Entry(val move: String, val flips: List<String>, val before: Before)

/** 形勢の 2 本の並び（CR-8）。★メモリの中だけ・その対局のあいだだけ。 */
data class Trend(val black: List<Int>, val white: List<Int>)

/** 対局の状態。★器 1 つの値。書き換えない。 */
data class State(
    val board: List<String>,
    val turn: String,
    val moves: Int,
    val history: List<Entry>,
    val passes: Int,
    /** 開いた記録の在り処。★対局と 1 対 1（DD-L3-othello §3.5）。開いていなければ無し。 */
    val log: LogHandle? = null,
    /** ★形勢の 2 本の並び（CR-8）。メモリの中だけ・その対局のあいだだけ。 */
    val trend: Trend = Trend(listOf(), listOf()),
    /** ★DB が付けた対局の番号（CR-9）。対局の頭で受け取り、終わるまで持つ。 */
    val gameId: Int = 0,
    /** ★再生の残りの手（CR-10）。空なら再生ではない。 */
    val replay: List<String> = listOf(),
    /** ★ヘルプが開いているか（F-12・RF-64）。★印だけ——盤にも進行にも触らない。 */
    val help: Boolean = false
)

/** 黒と白の枚数。 */
data class Stones(val b: Int, val w: Int)

/** 直前の手。★履歴が空なら無し（0 を入れない）。 */
data class LastMove(val square: String, val flipped: Int)

/** 受理したかと、新しい状態か理由。★置けないことを例外で伝えない。 */
data class Played(val ok: Boolean, val state: State?, val reason: String, val over: Boolean)

/** 升・パス・待った、それぞれ押せるか。 */
data class Pressable(val squares: List<String>, val canPass: Boolean, val canUndo: Boolean)

/** 画面が描くのに要るもの一式。★1 回で全部渡す（DD-L2-othello §3.4）。 */
data class View(
    val board: List<String>,
    val turn: String,
    val moves: Int,
    val stones: Stones,
    val last: LastMove?,
    val hints: List<String>,
    val hintCount: Int,
    val counted: Boolean,
    val blackLevel: Int?,
    val whiteLevel: Int?,
    val message: String,
    /** ★今回裏返った升の並び。1 枚ずつ見せるための順（CR-6）。空ならめくるものが無い。 */
    val flipped: List<String>,
    /** ★次も計算機の番か。真なら、画面は間を置いてから次の出来事を送る（CR-6）。 */
    val machineToMove: Boolean,
    /** ★段 5 が記録から選べたか。偽なら決め打ちの値で動いている（DD-L1-othello §5.2）。 */
    val picked: Boolean,
    /** ★何局の記録から選んだか。選べなければ 0（DD-L3-othello §3.3b）。 */
    val pickedGames: Int,
    /** ★形勢の 2 本の並び（CR-8）。空なら描かない。 */
    val trend: Trend,
    val pressable: Pressable,
    /** ★再生の続きが在るか。真なら、画面は間を置いて次を送る（CR-10）。 */
    val replaying: Boolean = false,
    /** ★再生で選ぶための一覧（CR-10）。★窓口が載せる——組み立ては DB を知らない。 */
    val games: List<GameHead> = listOf(),
    /** ★ヘルプが開いているか（F-12・RF-64）。真なら画面はヘルプを出し、升を渡さない。 */
    val help: Boolean = false
)

/** 計算機の番を進めた結果。 */
data class Stepped(val ok: Boolean, val passed: Boolean, val state: State?, val reason: String)

/** 画面から来る出来事。★決めた 9 つだけ（DD-L4-othello-bridge §3.1）。 */
data class Command(val kind: String, val square: String)

/** 境の窓口の答え。新しい状態と、一式。★断ったときも一式を返す。 */
data class Handled(val ok: Boolean, val state: State, val reason: String, val view: View)
