package othello

import java.io.File
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement
import kotlinx.serialization.json.Json
/**
 * 残すことと、外から入れること（控え・1 局を丸ごと・取り込み）。
 *
 * 設計: DD-L4-othello-db §1 ／ 決めは DD-L3-othello-db §2
 * ★2026-08-15 に OthelloDb.kt から切り出した——266 行が規約(200)を超えたため。
 * ★切れ目は、まずコード単位。超えていたのは行数であって、どれか 1 つの関数ではない。
 * ★割れ目は「変わる理由」で決めた: ここは「残しかた」が変わったときに変わる。
 */
object OthelloDbKeep {
    /** 控えを取る。★古いほうから番号をずらし、残す代を超えたものは消す。 */
    fun backupDb(db: DbHandle, root: String, keep: Int): Int {
        if (!db.ok || root == "" || keep <= 0) return 0
        // ★ずらしてから書く。先に書くと、いちばん新しい控えが 2 つになる（DD-L4-othello-db §3.3e）
        for (age in keep downTo 1) {
            val older = File(root, "othello.db.$age")
            if (age == keep && older.exists()) older.delete()
            val newer = File(root, "othello.db." + (age - 1))
            if (age > 1 && newer.exists()) newer.renameTo(older)
        }
        val at = File(root, "othello.db.1")
        if (at.exists()) at.delete()
        OthelloDb.kept.getValue(db.path).createStatement().use {
            it.execute("VACUUM INTO '" + at.path.replace("\\", "/") + "'")
        }
        return (1..keep).count { File(root, "othello.db.$it").exists() }
    }

    /** 終わった記録 1 本を、手ごと丸ごと入れる（取り込み用）。★同じ在り処は入れ直さない。 */
    fun saveGame(db: DbHandle, path: String, name: String): Written {
        if (!db.ok) return Written(false, "DB が開いていない")
        val got = OthelloLogRead.readOne(path)
        if (got.broken || !got.finished) return Written(false, "終わっていない記録は入れない")
        val setup = Setup(got.black ?: "", got.white ?: "", got.level, got.params,
            got.whiteLevel, got.whiteParams)
        // ★撃つ前に見る。撃って弾かれると、★入らないのに番号だけ消費される（BUG-50）
        if (known(db, path)) return Written(false, "既に入っている")
        val id = OthelloDb.startGame(db, setup, path, name)
        if (id == 0) return Written(false, "既に入っている")
        OthelloLogRead.readMoveBodies(path).forEachIndexed { i, body -> OthelloDb.addMove(db, id, i + 1, body) }
        return OthelloDb.finishGame(db, id, got.result!!)
    }

    /** その在り処が既に入っているか（DD-L4-othello-db §3.3 の 4）。 */
    private fun known(db: DbHandle, path: String): Boolean {
        OthelloDb.kept.getValue(db.path).prepareStatement("SELECT 1 FROM games WHERE path=?").use {
            it.setString(1, path)
            return it.executeQuery().next()
        }
    }

    /** ★問い合わせで集める。全部読んで数え直さない（CR-11）。 */

    /** 置き場の記録をまとめて入れる。★同じ在り処は 2 度入らない。 */
    fun importFolder(db: DbHandle, root: String): Int {
        if (!db.ok || root == "") return 0
        val dir = File(root)
        if (!dir.isDirectory) return 0
        var n = 0
        for (name in dir.list()!!.sorted()) {
            if (!name.endsWith(".jsonl")) continue
            if (OthelloDbKeep.saveGame(db, File(root, name).path, "").ok) n += 1
        }
        return n
    }
}