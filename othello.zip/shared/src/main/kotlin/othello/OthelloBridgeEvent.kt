package othello

/**
 * 出来事ごとの枝。どう状態が変わるかだけを持つ。
 *
 * 設計: DD-L4-othello-bridge §2 ／ 決めは DD-L3-othello §2
 *
 * ★2026-08-15 に `OthelloBridge.handle` から切り出した——複雑度が 37（規約は 20）になったため。
 * ★切れ目は、まずコード単位。それで足りなければ関数単位（owner 指示 2026-08-15）。
 *   ★ここは 1 つの関数が超えていたので、ファイルを割っても複雑度は 1 も下がらない。∴ 関数単位で割る。
 * ★判定は増えない——判断の置き場は 1 つのまま（DD-L2-othello §3.5）。
 */
object OthelloBridgeEvent {

    /** 出来事 1 つを、進行への呼び分けに直す。★決めた語でないものは、ここへ来ない。 */
    fun apply(state: State, setup: Setup, event: Command, root: String): Played = when (event.kind) {
        "square" -> OthelloGame.play(state, event.square)
        "pass" -> OthelloGame.passTurn(state)
        "undo" -> OthelloUndo.undo(state, setup)
        "machine" -> Played(true, state, "", false)
        "replay" -> replayOf(event, root)
        "next" -> nextOf(state)
        "help", "closeHelp" -> helpOf(state, event)
        // ★一覧・取り込み・書き出しは盤を変えない（DD-L4-othello-bridge §3.2 の 5f〜5h）
        "games", "import", "dump" -> Played(true, state, "", false)
        // ★開くのは、この枝の中だけ。外に置くと出来事のたびに 1 本できる（BUG-29）
        else -> Played(true, OthelloBridge.opened(setup, root), "", false)
    }

    /** 再生を始める。手の並びを取り、対局の頭の状態に持たせる（CR-10）。 */
    fun replayOf(event: Command, root: String): Played =
        Played(true, OthelloState.newState().copy(
            replay = OthelloDb.readMoves(OthelloDb.openDb(root), event.square.toIntOrNull() ?: 0)),
            "", false)

    /** 再生の次の 1 手。並びの先頭を置き、並びから外す。★打ち手を呼ばない（手は記録に在る）。 */
    fun nextOf(state: State): Played {
        if (state.replay.isEmpty()) return Played(false, null, "再生は終わっている", false)
        val one = OthelloGame.play(state, state.replay.first())
        if (one.ok && one.state != null)
            return Played(true, one.state.copy(replay = state.replay.drop(1)), "", false)
        return Played(true, OthelloGame.passTurn(state).state
            ?.copy(replay = state.replay.drop(1)) ?: state, "", false)
    }

    /**
     * ヘルプの印を立てる／下ろす（F-12・RF-64）。
     *
     * ★盤にも進行にも触らない。★閉じるときに「戻す」処理を持たない——触っていないので、戻すものが無い。
     */
    fun helpOf(state: State, event: Command): Played =
        Played(true, state.copy(help = event.kind == "help"), "", false)
}
