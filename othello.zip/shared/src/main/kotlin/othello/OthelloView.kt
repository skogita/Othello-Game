package othello

/**
 * 表示の組み立て。画面が描くのに要るものを 1 かたまりにして渡す。描画はしない。
 *
 * 設計: DD-L4-othello-play §6
 */
object OthelloView {

    /** 升・パス・待った、それぞれ押せるか。 */
    fun pressable(state: State, moves: Moves): Pressable =
        Pressable(moves.moves, moves.moves.isEmpty(), state.history.isNotEmpty())

    /** 画面が描くのに要るもの一式。★毎回、新しい器にまとめて返す。 */
    fun buildView(state: State, setup: Setup): View {
        val moves = OthelloRules.legalMoves(state.board, state.turn)
        return View(
            state.board, state.turn, state.moves,
            OthelloState.countStones(state.board),
            OthelloState.lastMoveInfo(state.history),
            moves.moves, moves.moves.size, moves.counted,
            setup.blackLevel,
            setup.whiteLevel,
            if (OthelloRules.isOver(state.board)) "終局しました" else "",
            if (state.history.isEmpty()) listOf() else state.history.last().flips,
            // ★再生中は偽。真だと、画面が「計算機の 1 手」を送り始める（BUG-47）
            OthelloSetup.isMachineTurn(setup, state.turn) &&
                !OthelloRules.isOver(state.board) && state.replay.isEmpty(),
            // ★決め打ちで動いていることを隠さない（DD-L1-othello §4b・§5.2）
            // ★段 5 が選べたか（どちらかの側が段 5 なら、その側で見る）
            (setup.blackParams?.fallback != true) && (setup.whiteParams?.fallback != true),
            maxOf(setup.blackParams?.games ?: 0, setup.whiteParams?.games ?: 0),
            // ★形勢の並みをそのまま載せる（CR-8）。画面は描くだけ
            state.trend,
            // ★再生中は打てない・戻せない。押せるものを空にする（CR-10 の 10-2・10-3）
            //   ★ヘルプが開いているあいだも同じ——升を渡さない（DD-L1-othello §6.8）
            //   ★画面に無視させない——押せないことは、渡すものの側で決める
            if (state.replay.isEmpty() && !state.help) pressable(state, moves)
            else Pressable(listOf(), false, false),
            // ★再生の続きが在るか（CR-10）。画面が間を置いて次を送る
            state.replay.isNotEmpty(),
            // ★一覧は窓口が載せる（ここでは空のまま）
            listOf(),
            // ★ヘルプが開いているか（F-12・RF-64）。画面はこれを見て出す
            state.help
        )
    }
}
