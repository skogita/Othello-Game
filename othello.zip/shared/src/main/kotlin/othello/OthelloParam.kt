package othello

/**
 * 段ごとのパラメータの表。記録に触るのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-ai §6 ／ 表は DD-L3-othello-ai §3.2
 * ★深さの下限は 1。深さ 0 は「読まない」であり、読まなければ升も選べない。
 */
object OthelloParam {

    private val TABLE = mapOf(
        // ★測って入れ替えた（DD-L1-othello-ai §4.3）。枚数だけを見る組がいちばん弱い
        1 to Params(0, 0, 1, 1, 0, false, false, 0),
        2 to Params(0, 0, 0, 1, 0, false, false, 0),
        3 to Params(1, 0, 0, 1, 0, false, false, 0),
        4 to Params(1, 10, 0, 4, 0, false, false, 0),
        // ★段 6（著者方式）。表だけを見て、10 手先まで読む（CR-7）
        6 to Params(0, 0, 0, 10, 0, false, false, 0, true)
    )

    /** その対に 1 局、勝った側に 1 勝を積む（DD-L3-othello-ai §3.4b）。 */
    fun add(tally: Tally, key: Duel, won: Int) {
        val now = if (tally.containsKey(key)) tally.getValue(key) else Pair(0, 0)
        tally[key] = Pair(now.first + won, now.second + 1)
    }

    /** ★その組が勝ち越している相手の数（DD-L3-othello-ai §3.4b）。 */
    fun wins(tally: Tally, one: Params): Int =
        tally.count { e ->
            (e.key.one == one && e.value.first * 2 > e.value.second) ||
                (e.key.other == one && (e.value.second - e.value.first) * 2 > e.value.second)
        }

    /** ★中の全員が、外の全員に勝ち越しているか（★中どうしの勝敗は問わない）。 */
    fun beatsOutside(tally: Tally, inner: List<Params>, all: List<Params>): Boolean =
        all.filterNot { inner.contains(it) }.all { out ->
            inner.all { one ->
                tally.any { e ->
                    (e.key.one == one && e.key.other == out && e.value.first * 2 > e.value.second) ||
                        (e.key.one == out && e.key.other == one &&
                            (e.value.second - e.value.first) * 2 > e.value.second)
                }
            }
        }

    /** ★最強の集合から取る。★中の全員が外の全員に勝ち越している（DD-L3-othello-ai §3.4b）。 */
    fun bestParams(root: String): Params? {
        // ★材料は DB へ問い合わせて集める（CR-11）。DB が空ならファイルを読む
        val db = OthelloDb.openDb(root)
        val asked = if (db.ok) OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)) else null
        val got = if (asked != null && asked.used > 0) asked
            else OthelloLogRead.collect(listOf(1, 2, 3, 4), root)
        if (got.used == 0) return null
        // ★★組の対ごとに数える。★相手の違うものを同じ列に足さない——足すと 1 勝 1 局が最強になる
        // ★人と計算機の対局は、相手を「人」1 つとして対にする（同§・裁定 A）
        val tally: Tally = mutableMapOf()
        var used = 0
        for (game in got.games) {
            val bare = game.params?.copy(fallback = false, chosen = false, games = 0)
            val other = game.whiteParams?.copy(fallback = false, chosen = false, games = 0)
            if (bare != null && other != null) {
                if (bare == other) continue
                add(tally, Duel(bare, other), if (game.result!!.winner == "B") 1 else 0)
                used += 1
                continue
            }
            // ★勝ちは計算機が受け持った側で数える（BUG-32）
            val one = bare ?: other ?: continue
            val side = if (bare != null) "B" else "W"
            add(tally, Duel(one, null), if (game.result!!.winner == side) 1 else 0)
            used += 1
        }
        if (used == 0) return null
        // ★★最強は集合である。1 つとは限らない——三つどもえなら 3 つとも最強（同§）
        val sets = tally.keys.flatMap { listOfNotNull(it.one, it.other) }.distinct()
        // ★★三つどもえでは、全員に 1 敗が在る——「誰にも負け越していない」では空になる。
        //   ★外に勝てているかで決める（DD-L3-othello-ai §3.4b）。中どうしの勝敗は問わない。
        val order = sets.sortedWith(compareByDescending<Params> { one -> wins(tally, one) }
            .thenBy { it.toString() })
        val best = (1..order.size).map { order.take(it) }
            .firstOrNull { inner -> beatsOutside(tally, inner, order) }
        if (best == null) return null
        // ★どれでも同じ強さ。★決まった順で先のものを取る（同じ盤面には同じ手を返す・DD-L1-othello §4）
        return best.sortedBy { it.toString() }.first().copy(chosen = true, games = used)
    }

    /** 段のパラメータの組。段が範囲の外なら無し。段 5 は記録から選ぶ。 */
    fun levelParams(level: Int, root: String): Params? {
        if (level < 1 || level > 6) return null
        if (level != 5) return TABLE.getValue(level)
        val chosen = bestParams(root)
        if (chosen != null) return chosen
        return TABLE.getValue(4).copy(fallback = true, chosen = false)
    }
}
