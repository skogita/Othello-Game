package othello

/**
 * 先読み。手を選ぶことと点を出すことを、同じ 1 回の読みで行う。
 *
 * 設計: DD-L4-othello-ai §5 ／ 方式は DD-L3-othello-ai §3.3
 * ★深さは 1 手が 1。深さ 0 は「読まずに、その盤をそのまま点にする」。
 * ★点は、その盤で手番の側から見た数。深さの偶奇で意味が変わらない。
 */
object OthelloSearch {

    const val LOW = -100000
    const val HIGH = 100000

    /** 点と升を一緒に返す。同点なら升の順で先のもの。 */
    fun search(board: List<String>, turn: String, depth: Int, params: Params,
               alpha: Int, beta: Int, until: Long): Searched {
        // ★打ち切りの時刻を過ぎたら、読まずに点にする（DD-L1-othello-ai §4.4）
        if (until > 0L && System.currentTimeMillis() >= until)
            return Searched(OthelloEval.evaluate(board, turn, params), "")
        if (depth <= 0) return Searched(OthelloEval.evaluate(board, turn, params), "")
        val moves = OthelloRules.legalMoves(board, turn).moves
        if (moves.isEmpty()) return Searched(OthelloEval.evaluate(board, turn, params), "")
        val other = if (turn == "B") "W" else "B"
        var best = ""
        var score = LOW
        var low = alpha
        for (move in moves.sorted()) {
            val next = OthelloRules.applyMove(board, move, turn)
            val got = -search(next, other, depth - 1, params, -beta, -low, until).score
            if (best == "" || got > score) {
                best = move
                score = got
            }
            if (score > low) low = score
            if (low >= beta) return Searched(score, best)
        }
        return Searched(score, best)
    }

    /** 最も良い升。置ける升が無ければ空。★読みは持たない。 */
    fun bestMove(board: List<String>, turn: String, depth: Int, params: Params,
                 alpha: Int, beta: Int, until: Long): String =
        search(board, turn, depth, params, alpha, beta, until).move
}
