package othello

import java.io.File

/**
 * 記録の置き場を決める。★探さない。書けるかを尋ねない。
 *
 * 設計: DD-L4-othello-play §8a ／ 決めは DD-L2-othello §7z.2c
 * ★環境の値をここで読まない。環境が用意した置き場は、引数で受け取る。
 * ★決めるだけで、作らない。作るのは書く側である。
 */
object OthelloPlace {

    /** 記録の置き場。外からの指定か、環境が用意した置き場の下。どちらも無ければ空。 */
    fun logRoot(app: String, given: String, provided: String): String {
        if (given != "") return given
        if (provided == "") return ""
        return File(provided, app).path
    }
}
