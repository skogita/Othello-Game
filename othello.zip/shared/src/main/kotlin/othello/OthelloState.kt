package othello

/**
 * 対局の状態。器 1 つの値。書き換えない。
 *
 * 設計: DD-L4-othello-play §3
 */
object OthelloState {

    /** 初期配置・黒番・手数 0 の状態。 */
    fun newState(): State = State(OthelloBoard.initialBoard(), "B", 0, listOf(), 0)

    /** 黒と白の枚数。 */
    fun countStones(board: List<String>): Stones {
        val joined = board.joinToString("")
        return Stones(joined.count { it == 'B' }, joined.count { it == 'W' })
    }

    /** 直前の升と裏返った枚数。★履歴が空なら無し（0 を入れない）。 */
    fun lastMoveInfo(history: List<Entry>): LastMove? {
        if (history.isEmpty()) return null
        val last = history.last()
        return LastMove(last.move, last.flips.size)
    }
}
