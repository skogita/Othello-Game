package othello

/**
 * 対局の進行。状態を受け取り、新しい状態を返す。書き換えない。
 *
 * 設計: DD-L4-othello-play §4
 */
object OthelloGame {

    /** 履歴に積む「置く前の状態」。★履歴そのものは入れない。 */
    fun beforeState(state: State): Before =
        Before(state.board, state.turn, state.moves, state.passes)

    /** 受理したかと、新しい状態か理由。 */
    fun play(state: State, move: String): Played {
        val got = OthelloScan.flips(state.board, move, state.turn)
        if (got.isEmpty()) return Played(false, null, "裏返る升が無いので置けない", false)
        val entry = Entry(move, got, beforeState(state))
        return Played(
            true,
            state.copy(
                OthelloRules.applyMove(state.board, move, state.turn),
                if (state.turn == "B") "W" else "B",
                state.moves + 1,
                state.history + entry,
                0
            ),
            "", false
        )
    }

    /** 受理したかと、新しい状態か理由。置ける升があるあいだは受理しない。 */
    fun passTurn(state: State): Played {
        if (OthelloRules.legalMoves(state.board, state.turn).moves.isNotEmpty()) {
            return Played(false, null, "置ける升があるのでパスできない", false)
        }
        val entry = Entry("", listOf(), beforeState(state))
        val next = state.copy(
            state.board,
            if (state.turn == "B") "W" else "B",
            state.moves + 1,
            state.history + entry,
            state.passes + 1
        )
        return Played(true, next, "", next.passes == 2)
    }
}
