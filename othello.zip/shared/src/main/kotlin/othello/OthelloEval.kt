package othello

/**
 * 盤の点数。何を見るかは、渡された係数で決める。
 *
 * 設計: DD-L4-othello-ai §4
 * ★石の数は、ここで数える。進行の側を呼ばない——依存の向きが逆になる（DD-L2-othello-ai §1.1）。
 */
object OthelloEval {

    /** 自分が置ける升の数から、相手が置ける升の数を引いた数。 */
    fun mobility(board: List<String>, turn: String): Int {
        val other = if (turn == "B") "W" else "B"
        return OthelloRules.legalMoves(board, turn).moves.size -
            OthelloRules.legalMoves(board, other).moves.size
    }

    /** 盤の良さ。手番の側から見た点。係数が 0 なら、その見方は効かない。 */
    fun evaluate(board: List<String>, turn: String, params: Params): Int {
        // ★段 6 は、升ごとの点の表だけで決める（CR-7・DD-L3-othello-ai §3.1b）
        if (params.author) return OthelloWeight.authorScore(board, turn)
        val other = if (turn == "B") "W" else "B"
        val joined = board.joinToString("")
        val stones = joined.count { it.toString() == turn } - joined.count { it.toString() == other }
        return params.weight * OthelloWeight.positionScore(board, turn) +
            params.mobility * mobility(board, turn) +
            params.stones * stones
    }
}
