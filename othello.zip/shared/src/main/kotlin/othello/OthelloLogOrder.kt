package othello

/**
 * 記録の並びの順を確かめる。順の決めを持つのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-log §5
 */
object OthelloLogOrder {

    private val NEXT_OK = mapOf(
        "open" to listOf("move", "pass", "close"),
        "move" to listOf("move", "pass", "undo", "close"),
        "pass" to listOf("move", "pass", "undo", "close"),
        "undo" to listOf("move", "pass", "undo", "close"),
        "close" to listOf<String>()
    )

    /** 順が正しいかと、崩れている場所を返す。 */
    fun checkOrder(events: List<Event>): Order {
        if (events.isEmpty() || events[0].kind != "open") {
            return Order(false, 0, "最初が対局の始まりでない")
        }
        for (i in 1 until events.size) {
            val prev = events[i - 1].kind
            val ok = if (NEXT_OK.containsKey(prev)) NEXT_OK.getValue(prev) else listOf()
            if (!ok.contains(events[i].kind)) return Order(false, i, "来てはいけない種類が来ている")
        }
        return Order(true, -1, "")
    }
}
