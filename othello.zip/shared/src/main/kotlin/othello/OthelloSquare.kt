package othello

/**
 * 升の名前と、行・列の行き来。盤も規則も知らない。
 *
 * 設計: DD-L4-othello-rules §3
 */
object OthelloSquare {

    private const val COLS = "abcdefgh"
    private const val ROWS = "12345678"

    /** 升の名前を行と列の組に直す。盤の外なら負の値の組。 */
    fun squareToRc(square: String): Step {
        if (square.length != 2) return Step(-1, -1)
        val col = COLS.indexOf(square[0])
        val row = ROWS.indexOf(square[1])
        if (col < 0 || row < 0) return Step(-1, -1)
        return Step(row, col)
    }

    /** 行と列を升の名前に直す。盤の外なら空。 */
    fun rcToSquare(row: Int, col: Int): String {
        if (row < 0 || row > 7 || col < 0 || col > 7) return ""
        return "" + COLS[col] + ROWS[row]
    }

    /** 盤の 64 升の名前を並べて返す。 */
    fun allSquares(): List<String> =
        (0..7).flatMap { row -> (0..7).map { col -> rcToSquare(row, col) } }
}
