package othello

/**
 * 走査。8 方向の定めを持つのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-rules §5
 */
object OthelloScan {

    private val STEPS = listOf(
        Step(-1, -1), Step(-1, 0), Step(-1, 1), Step(0, -1),
        Step(0, 1), Step(1, -1), Step(1, 0), Step(1, 1)
    )

    /** その向きで挟める升の一覧。挟めなければ空。1 方向しか見ない。 */
    fun scanLine(board: List<String>, row: Int, col: Int, step: Step, turn: String): List<String> {
        val other = if (turn == "B") "W" else "B"
        val got = mutableListOf<String>()
        var r = row + step.first
        var c = col + step.second
        while (r in 0..7 && c in 0..7 && board[r][c].toString() == other) {
            got.add(OthelloSquare.rcToSquare(r, c))
            r += step.first
            c += step.second
        }
        if (got.isNotEmpty() && r in 0..7 && c in 0..7 && board[r][c].toString() == turn) return got
        return emptyList()
    }

    /** 裏返る升の一覧。置けないときは空。 */
    fun flips(board: List<String>, move: String, turn: String): List<String> {
        val rc = OthelloSquare.squareToRc(move)
        if (rc.first < 0) return emptyList()
        if (board[rc.first][rc.second] != '.') return emptyList()
        return STEPS.flatMap { scanLine(board, rc.first, rc.second, it, turn) }
    }
}
