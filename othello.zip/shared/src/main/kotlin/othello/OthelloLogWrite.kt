package othello

import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.serialization.json.Json

/**
 * 記録を書く。追記だけ。日時を取るのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-log §3
 * ★どれも「書けたかどうか」を返す。例外を投げない——記録が書けないことを理由に、対局が止まってはいけない。
 */
object OthelloLogWrite {

    private val KINDS = listOf("move", "pass", "undo", "close")
    private val STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss-SSS")

    /** 対局の始まりの 1 行を書き、記録の在り処を返す。 */
    fun openLog(setup: Setup, root: String): LogHandle {
        val stamp = LocalDateTime.now().format(STAMP)
        val path = File(root, "g$stamp.jsonl").path
        if (root == "") return LogHandle(path, false, "置き場が無いので書けない")
        val dir = File(root)
        if (!dir.isDirectory) dir.mkdirs()
        // ★「作った」を信じない。作る仕組みは、できなかったことを黙って返すことがある。
        if (!dir.isDirectory) return LogHandle(path, false, "置き場を作れないので書けない")
        // ★人どうしなら強さのパラメータが無い。無い欄は書かない（段と同じ扱い）
        // ★黒の段と白の段を、両方残す（CR-12）
        val body = mutableMapOf("black" to setup.black, "white" to setup.white)
        if (setup.blackParams != null)
            body["params"] = Json.encodeToString(Params.serializer(), setup.blackParams)
        if (setup.blackLevel != null) body["level"] = setup.blackLevel.toString()
        if (setup.whiteParams != null)
            body["white_params"] = Json.encodeToString(Params.serializer(), setup.whiteParams)
        if (setup.whiteLevel != null) body["white_level"] = setup.whiteLevel.toString()
        File(path).appendText(Json.encodeToString(Event.serializer(), Event(stamp, "open", body)) + "\n")
        return LogHandle(path, true, "")
    }

    /** 1 行を書き足す。種類が決めた語でなければ書かない。 */
    fun appendEvent(log: LogHandle, kind: String, body: Body): Written {
        val stamp = LocalDateTime.now().format(STAMP)
        if (!KINDS.contains(kind)) return Written(false, "決めていない種類なので書かない")
        if (!log.ok) return Written(false, "記録が開いていないので書けない")
        File(log.path).appendText(
            Json.encodeToString(Event.serializer(), Event(stamp, kind, body)) + "\n")
        return Written(true, "")
    }

    /** 対局の終わりの 1 行を書き足す。 */
    fun closeLog(log: LogHandle, result: Result): Written {
        val stamp = LocalDateTime.now().format(STAMP)
        if (!log.ok) return Written(false, "記録が開いていないので書けない")
        val body = mapOf("winner" to result.winner, "black" to result.black.toString(),
            "white" to result.white.toString())
        File(log.path).appendText(
            Json.encodeToString(Event.serializer(), Event(stamp, "close", body)) + "\n")
        return Written(true, "")
    }
}
