package othello

/**
 * 待った。戻す先は「1 手前」ではなく、「人が打つ番」。
 *
 * 設計: DD-L4-othello-play §5
 */
object OthelloUndo {

    /** 受理したかと、人が打つ番まで戻した状態か理由。 */
    fun undo(state: State, setup: Setup): Played {
        if (state.history.isEmpty()) return Played(false, null, "履歴が空なので戻せない", false)
        var before = state.history.last().before
        var rest = state.history.dropLast(1)
        while (rest.isNotEmpty() && OthelloSetup.isMachineTurn(setup, before.turn)) {
            before = rest.last().before
            rest = rest.dropLast(1)
        }
        return Played(true, state.copy(board = before.board, turn = before.turn, moves = before.moves,
            history = rest, passes = before.passes),
            "", false)
    }
}
