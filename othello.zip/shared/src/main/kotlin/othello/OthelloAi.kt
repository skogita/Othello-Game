package othello

/**
 * 打ち手の入口。段は知らない。パラメータの組を受け取る。
 *
 * 設計: DD-L4-othello-ai §7
 * ★同じパラメータなら、同じ升を返す。乱数も記録も見ない。
 * ★ただし 5 秒で打ち切るので、打ち切りに掛かると同じ手を返す保証は無い（DD-L1-othello-ai §4.4）。
 */
object OthelloAi {

    /** ★1 手にかける時間の上限（DD-L1-othello-ai §4.4）。 */
    const val LIMIT = 5000L

    /** 次に置く升と、決められたかどうか。 */
    fun chooseMove(board: List<String>, turn: String, params: Params?): Chosen {
        if (params == null) return Chosen(false, "", "パラメータが空なので決められない")
        val moves = OthelloRules.legalMoves(board, turn).moves
        if (moves.isEmpty()) return Chosen(true, "", "置ける升が無い")
        val empty = board.joinToString("").count { it == '.' }
        val depth = if (params.endgame > 0 && empty <= params.endgame) empty else params.depth
        // ★打ち切りの時刻は、ここで 1 度だけ作る（DD-L1-othello-ai §4.4）
        val until = System.currentTimeMillis() + LIMIT
        return Chosen(true, OthelloSearch.bestMove(board, turn, depth, params,
            OthelloSearch.LOW, OthelloSearch.HIGH, until), "")
    }
}
