package othello

import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.serialization.json.Json

/**
 * 素振り。段どうしを戦わせ、その記録を残す。
 *
 * 設計: DD-L4-othello-log §7 ／ 決めは DD-L3-othello-ai §3.4b
 * ★段 5 の材料は、人との対局では貯まらない——相手の強さがばらばらだから。
 * ★同じ開幕から、色を入れ替えて戦わせる。1 局では足りない（打ち手は決定的）。
 */
object OthelloDrill {

    /** 素振りを走らせる口。引数は 置き場・開幕の数・段の組み合わせ（`1-4` の形）。 */
    @JvmStatic
    fun main(args: Array<String>) {
        val root = args[0]
        val boards = args[1].toInt()
        val pairs = args.drop(2).map { Step(it.split("-")[0].toInt(), it.split("-")[1].toInt()) }
        println("素振り: 置き場=" + root + " 開幕=" + boards + " 組=" + pairs)
        println("書いた記録: " + runSeries(pairs, boards, root) + " 本")
    }

    private val STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH-mm-ss-SSS")
    private val json = Json { encodeDefaults = true }

    /** 段どうしの 1 局を開く。★両側の段と組を頭に書く。 */
    fun openDrill(black: Params, blackLevel: Int, white: Params,
                  whiteLevel: Int, root: String): LogHandle {
        val stamp = LocalDateTime.now().format(STAMP)
        val path = File(root, "d$stamp.jsonl").path
        if (root == "") return LogHandle(path, false, "置き場が無いので書けない")
        val dir = File(root)
        if (!dir.isDirectory) dir.mkdirs()
        if (!dir.isDirectory) return LogHandle(path, false, "置き場を作れないので書けない")
        val body = mapOf("black" to "machine", "white" to "machine",
            "level" to blackLevel.toString(),
            "params" to json.encodeToString(Params.serializer(), black),
            "white_level" to whiteLevel.toString(),
            "white_params" to json.encodeToString(Params.serializer(), white))
        File(path).appendText(json.encodeToString(Event.serializer(), Event(stamp, "open", body)) + "\n")
        return LogHandle(path, true, "")
    }

    /** 段の組み合わせを、開幕を変えた盤から色を入れ替えて戦わせ、記録を書く。書いた本数を返す。 */
    fun runSeries(pairs: List<Step>, boards: Int, root: String): Int {
        if (root == "") return 0
        var wrote = 0
        for (pair in pairs) {
            // ★段 5 は記録から選ぶので、置き場を渡す。空を渡すと「記録を見ない段 5」になる
            val one = OthelloParam.levelParams(pair.first, root)!!
            val two = OthelloParam.levelParams(pair.second, root)!!
            for (from in openings(boards)) {
                // ★色を入れ替えて 2 局。片方の色だけだと、先手の有利が勝率に混ざる
                wrote += playAndWrite(from, one, pair.first, two, pair.second, root)
                wrote += playAndWrite(from, two, pair.second, one, pair.first, root)
            }
        }
        return wrote
    }

    /** 開幕を変えた盤を、指定された数だけ作る。 */
    fun openings(count: Int): List<State> {
        val out = mutableListOf(OthelloState.newState())
        for (first in OthelloRules.legalMoves(OthelloBoard.initialBoard(), "B").moves) {
            val one = OthelloGame.play(OthelloState.newState(), first).state!!
            for (second in OthelloRules.legalMoves(one.board, one.turn).moves) {
                if (out.size >= count) return out.take(count)
                out.add(OthelloGame.play(one, second).state!!)
            }
        }
        return out.take(count)
    }

    /** 1 局を最後まで打ち、1 手ずつ記録に残して閉じる。書けたら 1 を返す。 */
    fun playAndWrite(from: State, black: Params, blackLevel: Int,
                             white: Params, whiteLevel: Int, root: String): Int {
        val log = openDrill(black, blackLevel, white, whiteLevel, root)
        if (!log.ok) return 0
        var state = from
        while (!OthelloRules.isOver(state.board)) {
            val mover = state.turn
            if (OthelloRules.legalMoves(state.board, mover).moves.isEmpty()) {
                state = OthelloGame.passTurn(state).state!!
                continue
            }
            val params = if (mover == "B") black else white
            val got = OthelloAi.chooseMove(state.board, mover, params)
            state = OthelloGame.play(state, got.move).state!!
            val last = state.history.last()
            OthelloLogWrite.appendEvent(log, "move", mapOf("turn" to mover, "by" to "machine",
                "square" to last.move, "flips" to last.flips.size.toString()))
        }
        val stones = OthelloState.countStones(state.board)
        val winner = if (stones.b > stones.w) "B" else if (stones.w > stones.b) "W" else "-"
        OthelloLogWrite.closeLog(log, Result(winner, stones.b, stones.w))
        return 1
    }
}
