package othello

import java.io.File
import kotlinx.serialization.json.Json

/**
 * 記録を読む。書かない。順を確かめるのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-log §4
 * ★壊れた記録を黙って捨てない。捨てると母数から静かに減る。
 */
object OthelloLogRead {

    private val json = Json { ignoreUnknownKeys = true }

    /** 記録 1 本を読む。壊れていれば壊れていると分かる形で返す。 */
    fun readOne(path: String): GameRecord {
        val events = File(path).readLines().filter { it.isNotBlank() }
            .map { json.decodeFromString(Event.serializer(), it) }
        val order = OthelloLogOrder.checkOrder(events)
        if (!order.ok) return GameRecord(path, true, false, null, null, null)
        val finished = events.last().kind == "close"
        val head = events[0].body
        val level = if (head.containsKey("level")) head.getValue("level").toInt() else null
        val params = if (head.containsKey("params"))
            json.decodeFromString(Params.serializer(), head.getValue("params")) else null
        val tail = events.last().body
        val result = if (finished) Result(tail.getValue("winner"),
            tail.getValue("black").toInt(), tail.getValue("white").toInt()) else null
        // ★頭に在る打ち手を落とさない（DD-L4-othello-log §4.2）
        // ★段どうしの記録は、白の段と組も持つ。無ければ両側とも同じ組
        return GameRecord(path, false, finished, level, params, result,
            head["black"], head["white"],
            head["white_level"]?.toInt(),
            if (head.containsKey("white_params"))
                json.decodeFromString(Params.serializer(), head.getValue("white_params")) else null)
    }

    /** 段が合う対局だけを、使えた数・外した数・壊れた数と一緒に返す。 */
    fun collect(levels: List<Int>, root: String): Collected {
        val dir = File(root)
        val names = if (dir.isDirectory) dir.list()!!.sorted() else listOf()
        val games = names.filter { it.endsWith(".jsonl") }.map { readOne(File(root, it).path) }
        val broken = games.filter { it.broken }
        // ★どちらかの側の段が対象なら使う。黒の段だけ見ると、黒が人の対局が全部落ちる（BUG-44）
        val kept = games.filter {
            !it.broken && it.finished &&
                (levels.contains(it.level) || levels.contains(it.whiteLevel))
        }
        return Collected(kept, kept.size, broken.size, games.size - broken.size - kept.size)
    }

    /** 記録の中の「1 手」の行の中身を、古い順に返す（DB へ移すために使う）。 */
    fun readMoveBodies(path: String): List<Body> =
        File(path).readLines().filter { it.isNotBlank() }
            .map { json.decodeFromString(Event.serializer(), it) }
            .filter { it.kind == "move" }
            .map { it.body }
}
