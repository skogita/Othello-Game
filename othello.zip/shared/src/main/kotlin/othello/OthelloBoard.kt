package othello

/**
 * 盤という値。作る、写す。判定は持たない。
 *
 * 設計: DD-L4-othello-rules §4
 */
object OthelloBoard {

    private const val EMPTY_ROW = "........"

    /** 初期配置の盤。8 行、各行 8 文字。 */
    fun initialBoard(): List<String> =
        listOf(EMPTY_ROW, EMPTY_ROW, EMPTY_ROW, "...WB...", "...BW...", EMPTY_ROW, EMPTY_ROW, EMPTY_ROW)

    /** 中身の同じ新しい盤を返す。受け取った盤には触らない。 */
    fun copyBoard(board: List<String>): List<String> = board.map { it }
}
