package othello

import java.io.File
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement
import kotlinx.serialization.json.Json

/**
 * 対戦記録を SQL で読める形に残し、問い合わせる（CR-9・CR-10・CR-11）。
 *
 * 設計: DD-L4-othello-db ／ 決めは DD-L2-othello-db・DD-L3-othello-db
 * ★残す役目は記録ファイルが持つ。DB は探すための索引。
 * ★1 手ごとに書き、1 ゲームの終わりに永続化する。
 * ★Windows はメモリの上、Android はファイルの上。
 */
object OthelloDb {

    // ★同じ束の OthelloDbKeep／OthelloDbView も使う。★入れ物は 1 か所だけが持つ
    internal val json = Json { encodeDefaults = true; ignoreUnknownKeys = true }
    internal val kept = mutableMapOf<String, Connection>()

    /** DB を開く。置き場が空ならメモリの上。表が無ければ作る。 */
    fun openDb(root: String): DbHandle {
        // ★置き場が無ければ作る。DB は「無ければ作る」が、置き場までは作らない（BUG-49）
        if (root != "") { val dir = File(root); if (!dir.isDirectory) dir.mkdirs() }
        val path = if (root == "") ":memory:" else File(root, "othello.db").path
        val at = kept.getOrPut(path) { DriverManager.getConnection("jdbc:sqlite:$path") }
        at.createStatement().use {
            // ★書き込みの記録は、開くときに指定する。開いた後では無視される（DD-L2-othello-db §2）
            if (path != ":memory:") it.execute("PRAGMA journal_mode=WAL")
            it.executeUpdate(
                "CREATE TABLE IF NOT EXISTS games (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE, started_at TEXT, " +
                    "name TEXT, black TEXT, white TEXT, black_level INTEGER, white_level INTEGER, " +
                    "black_params TEXT, white_params TEXT, winner TEXT, " +
                    "black_stones INTEGER, white_stones INTEGER)"
            )
            it.executeUpdate(
                "CREATE TABLE IF NOT EXISTS moves (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, game_id INTEGER, seq INTEGER, " +
                    "turn TEXT, played_by TEXT, square TEXT, flips INTEGER)"
            )
        }
        return DbHandle(path, true, "")
    }

    /** 対局の 1 行を作り、DB が付けた番号を返す。★勝敗はまだ空。 */
    fun startGame(db: DbHandle, setup: Setup, path: String, name: String): Int {
        if (!db.ok) return 0
        val at = File(path).name.removePrefix("g").removePrefix("d").removeSuffix(".jsonl")
        val call = kept.getValue(db.path).prepareStatement(
            "INSERT OR IGNORE INTO games (path, started_at, name, black, white, " +
                "black_level, white_level, black_params, white_params) VALUES (?,?,?,?,?,?,?,?,?)",
            Statement.RETURN_GENERATED_KEYS
        )
        call.use {
            it.setString(1, path)
            it.setString(2, at)
            // ★名前が空なら、時刻から自動で付ける（CR-9 の 9-2）
            it.setString(3, if (name == "") at else name)
            it.setString(4, setup.black)
            it.setString(5, setup.white)
            it.setObject(6, setup.blackLevel)
            it.setObject(7, setup.whiteLevel)
            it.setString(8, setup.blackParams?.let { one -> json.encodeToString(Params.serializer(), one) })
            it.setString(9, setup.whiteParams?.let { one -> json.encodeToString(Params.serializer(), one) })
            // ★入らなかった（既に在る）なら 0 を返す。番号を返すと、2 度目も入ったことになる
            if (it.executeUpdate() == 0) return 0
            val keys = it.generatedKeys
            return if (keys.next()) keys.getInt(1) else 0
        }
    }

    /** 手を 1 行足す。★1 手ごとに呼ぶ。ここでは永続化しない。 */
    fun addMove(db: DbHandle, gameId: Int, seq: Int, body: Body): Written {
        if (!db.ok || gameId <= 0) return Written(false, "対局の番号が無い")
        val call = kept.getValue(db.path).prepareStatement(
            "INSERT INTO moves (game_id, seq, turn, played_by, square, flips) VALUES (?,?,?,?,?,?)"
        )
        call.use {
            it.setInt(1, gameId)
            it.setInt(2, seq)
            it.setString(3, body["turn"] ?: "")
            it.setString(4, body["by"] ?: "")
            it.setString(5, body["square"] ?: "")
            it.setInt(6, (body["flips"] ?: "0").toInt())
            it.executeUpdate()
        }
        return Written(true, "")
    }

    /** 勝敗を入れて終わらせる。★ここで永続化する（1 ゲームの終わりに 1 回）。 */
    fun finishGame(db: DbHandle, gameId: Int, result: Result): Written {
        if (!db.ok || gameId <= 0) return Written(false, "対局の番号が無い")
        val call = kept.getValue(db.path).prepareStatement(
            "UPDATE games SET winner=?, black_stones=?, white_stones=? WHERE id=?"
        )
        call.use {
            it.setString(1, result.winner)
            it.setInt(2, result.black)
            it.setInt(3, result.white)
            it.setInt(4, gameId)
            it.executeUpdate()
        }
        // ★永続化。書き込みの記録を本体へ移す（DD-L3-othello-db §4.1 の 6）
        if (db.path != ":memory:") {
            kept.getValue(db.path).createStatement().use { it.execute("PRAGMA wal_checkpoint(FULL)") }
        }
        return Written(true, "")
    }

    fun readMoves(db: DbHandle, gameId: Int): List<String> {
        if (!db.ok) return listOf()
        val out = mutableListOf<String>()
        kept.getValue(db.path).prepareStatement(
            "SELECT square FROM moves WHERE game_id=? ORDER BY seq"
        ).use {
            it.setInt(1, gameId)
            val rows = it.executeQuery()
            while (rows.next()) out.add(rows.getString(1))
        }
        return out
    }
}
