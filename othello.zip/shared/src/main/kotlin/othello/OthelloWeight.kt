package othello

/**
 * 升の重み。表を持つのは、このファイルだけ。
 *
 * 設計: DD-L4-othello-ai §3 ／ 表は DD-L3-othello-ai §3.1
 */
object OthelloWeight {

    private val WEIGHTS = listOf(
        listOf(120, -20, 20, 5, 5, 20, -20, 120),
        listOf(-20, -40, -5, -5, -5, -5, -40, -20),
        listOf(20, -5, 15, 3, 3, 15, -5, 20),
        listOf(5, -5, 3, 3, 3, 3, -5, 5),
        listOf(5, -5, 3, 3, 3, 3, -5, 5),
        listOf(20, -5, 15, 3, 3, 15, -5, 20),
        listOf(-20, -40, -5, -5, -5, -5, -40, -20),
        listOf(120, -20, 20, 5, 5, 20, -20, 120)
    )

    /** その升の重み。盤の外なら 0。 */
    fun weightOf(row: Int, col: Int): Int {
        if (row < 0 || row > 7 || col < 0 || col > 7) return 0
        return WEIGHTS[row][col]
    }

    /** 自分の石の重みの合計から、相手の石の重みの合計を引いた数。 */
    fun positionScore(board: List<String>, turn: String): Int {
        val other = if (turn == "B") "W" else "B"
        val mine = (0..7).sumOf { r ->
            (0..7).sumOf { c -> if (board[r][c].toString() == turn) weightOf(r, c) else 0 }
        }
        val theirs = (0..7).sumOf { r ->
            (0..7).sumOf { c -> if (board[r][c].toString() == other) weightOf(r, c) else 0 }
        }
        return mine - theirs
    }

    // ★段 6（著者方式）の点の表（DD-L3-othello-ai §3.1b）。★式で作らない——与えられた表である
    private val AUTHOR = listOf(
        listOf(25, -16, 9, -1, -1, 9, -16, 25),
        listOf(-16, -16, 9, 9, 9, 9, -16, -16),
        listOf(9, 9, 9, 9, 9, 9, 9, 9),
        listOf(-1, -1, 9, 9, 9, 9, -1, -1),
        listOf(-1, -1, 9, 9, 9, 9, -1, -1),
        listOf(9, 9, 9, 9, 9, 9, 9, 9),
        listOf(-16, -16, 9, 9, 9, 9, -16, -16),
        listOf(25, -16, 9, -1, -1, 9, -16, 25)
    )

    /** 段 6 の、その升の点。表を引くだけ。 */
    fun authorOf(row: Int, col: Int): Int = AUTHOR[row][col]

    /** 段 6 の、盤全体の点。自分の石の点から、相手の石の点を引く。 */
    fun authorScore(board: List<String>, turn: String): Int {
        var total = 0
        for (row in 0..7) {
            for (col in 0..7) {
                val one = board[row][col].toString()
                if (one == turn) total += authorOf(row, col)
                if (one != turn && one != ".") total -= authorOf(row, col)
            }
        }
        return total
    }
}
