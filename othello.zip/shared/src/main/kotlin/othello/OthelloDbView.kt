package othello

import java.io.File
import java.sql.Connection
import java.sql.DriverManager
import java.sql.Statement
import kotlinx.serialization.json.Json
/**
 * 見ることと、外へ出すこと（一覧・段ごとの数え・中身の並び・書き出し）。
 *
 * 設計: DD-L4-othello-db §1 ／ 決めは DD-L3-othello-db §2
 * ★2026-08-15 に OthelloDb.kt から切り出した。
 * ★割れ目は「変わる理由」で決めた: ここは「見せかた」が変わったときに変わる。
 */
object OthelloDbView {
    fun collectGames(db: DbHandle, levels: List<Int>): Collected {
        if (!db.ok) return Collected(listOf(), 0, 0, 0)
        val marks = levels.joinToString(",") { "?" }
        val call = OthelloDb.kept.getValue(db.path).prepareStatement(
            "SELECT path, black, white, black_level, white_level, black_params, white_params, " +
                "winner, black_stones, white_stones FROM games " +
                "WHERE winner IS NOT NULL AND (black_level IN ($marks) OR white_level IN ($marks))"
        )
        val out = mutableListOf<GameRecord>()
        call.use {
            for (i in levels.indices) {
                it.setInt(i + 1, levels[i])
                it.setInt(levels.size + i + 1, levels[i])
            }
            val rows = it.executeQuery()
            while (rows.next()) {
                out.add(GameRecord(rows.getString(1), false, true,
                    rows.getObject(4)?.let { one -> (one as Number).toInt() },
                    rows.getString(6)?.let { one -> OthelloDb.json.decodeFromString(Params.serializer(), one) },
                    Result(rows.getString(8), rows.getInt(9), rows.getInt(10)),
                    rows.getString(2), rows.getString(3),
                    rows.getObject(5)?.let { one -> (one as Number).toInt() },
                    rows.getString(7)?.let { one -> OthelloDb.json.decodeFromString(Params.serializer(), one) }))
            }
        }
        return Collected(out, out.size, 0, 0)
    }

    /** ★新しい順の一覧。再生する対局を選ぶために使う。 */
    fun listGames(db: DbHandle, limit: Int): List<GameHead> {
        if (!db.ok) return listOf()
        val out = mutableListOf<GameHead>()
        OthelloDb.kept.getValue(db.path).prepareStatement(
            "SELECT id, started_at, name, black, white, black_level, white_level, winner " +
                "FROM games WHERE winner IS NOT NULL ORDER BY id DESC LIMIT ?"
        ).use {
            it.setInt(1, limit)
            val rows = it.executeQuery()
            while (rows.next()) {
                out.add(GameHead(rows.getInt(1), rows.getString(2), rows.getString(3),
                    rows.getString(4), rows.getString(5),
                    rows.getObject(6)?.let { one -> (one as Number).toInt() },
                    rows.getObject(7)?.let { one -> (one as Number).toInt() },
                    rows.getString(8) ?: ""))
            }
        }
        return out
    }


    /** ★中身を人が読める形で、1 行ずつ返す（道具）。★書き出し先は、呼ぶ側が決める。 */
    fun dumpAll(db: DbHandle): List<String> {
        if (!db.ok) return listOf()
        val out = mutableListOf<String>()
        OthelloDb.kept.getValue(db.path).createStatement().use {
            val rows = it.executeQuery(
                "SELECT id, started_at, name, black, white, black_level, white_level, " +
                    "winner, black_stones, white_stones FROM games ORDER BY id"
            )
            while (rows.next()) {
                out.add("games | id=" + rows.getInt(1) + " | at=" + rows.getString(2) +
                    " | name=" + rows.getString(3) +
                    " | " + rows.getString(4) + "(" + (rows.getString(6) ?: "-") + ")" +
                    " 対 " + rows.getString(5) + "(" + (rows.getString(7) ?: "-") + ")" +
                    // ★未完は「まだ」。引き分けの `-` と同じ顔にしない（BUG-51）
                    " | winner=" + (rows.getString(8) ?: "まだ") +
                    " | " + rows.getInt(9) + " 対 " + rows.getInt(10))
            }
        }
        // ★対局ごとに、手を 1 行で添える（古い順。DD-L4-othello-db §3.3f）
        val ids = out.map { it.substringAfter("id=").substringBefore(" ").trim().toInt() }
        for (id in ids) {
            out.add("moves | game_id=" + id + " | " + OthelloDb.readMoves(db, id).joinToString(" "))
        }
        return out
    }

    /** ★中身を置き場のファイルへ書き、在り処を返す（CR-13 の 13-5）。★上書きする。 */
    fun writeDump(db: DbHandle, root: String): String {
        if (root == "") return ""
        val at = File(root, "othello-dump.txt")
        // ★代を持たない。中身は DB が持っているので、いつでも作り直せる
        at.writeText(dumpAll(db).joinToString(System.lineSeparator()) + System.lineSeparator())
        return at.path
    }

    /** ★その対局の手を、seq の順に返す（再生に使う）。 */
}