package othello

/**
 * DB の中身を見る道具の口（DD-L4-othello-db §3.3f）。
 * ★出す形は `dumpAll` が決め、★どこへ出すかはここが決める。
 */
fun main(args: Array<String>) {
    val root = if (args.isEmpty()) "" else args[0]
    val db = OthelloDb.openDb(root)
    println("DB: " + db.path)
    val lines = OthelloDbView.dumpAll(db)
    if (lines.isEmpty()) println("★1 本も入っていない")
    lines.forEach { println(it) }
    // ★ボタンと同じ先へも書く。★見る道が 2 通りでも、書き出す先は 1 つ
    if (root != "") println("書き出し: " + OthelloDbView.writeDump(db, root))
}
