package othello

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 盤の規則の群の単体試験。
 *
 * ★材料は DD-L4-othello-rules の「試験材料」から、値も期待値もそのまま起こしている。
 * コードを読んで作ったものではない。
 */
class OthelloRulesGroupTest {

    private val init = listOf(
        "........", "........", "........", "...WB...",
        "...BW...", "........", "........", "........"
    )
    private val fullB = List(8) { "BBBBBBBB" }

    // ---- OthelloSquare.kt:OthelloSquare:squareToRc
    @Test fun `squareToRc 行と列`() = assertEquals(Step(4, 5), OthelloSquare.squareToRc("f5"))
    @Test fun `squareToRc 範囲の外`() = assertEquals(Step(-1, -1), OthelloSquare.squareToRc("z9"))

    // ---- OthelloSquare.kt:OthelloSquare:rcToSquare
    @Test fun `rcToSquare 升の名前`() = assertEquals("f5", OthelloSquare.rcToSquare(4, 5))
    @Test fun `rcToSquare 空`() = assertEquals("", OthelloSquare.rcToSquare(9, 0))

    // ---- OthelloSquare.kt:OthelloSquare:allSquares（免除: no_args）
    @Test fun `allSquares 升の一覧`() = assertEquals("a1", OthelloSquare.allSquares()[0])

    // ---- OthelloBoard.kt:OthelloBoard:initialBoard（免除: no_args）
    @Test fun `initialBoard 初期配置の盤`() =
        assertTrue(OthelloBoard.initialBoard()[3].contains("WB"))

    // ---- OthelloBoard.kt:OthelloBoard:copyBoard
    @Test fun `copyBoard 写した盤`() = assertTrue(OthelloBoard.copyBoard(init)[3].contains("WB"))

    @Test fun `copyBoard 元の盤に触らない`() {
        val got = OthelloBoard.copyBoard(init).toMutableList()
        got[0] = "XXXXXXXX"
        assertEquals("........", init[0])
    }

    // ---- OthelloScan.kt:OthelloScan:scanLine
    @Test fun `scanLine 挟んだ升の一覧`() =
        assertEquals(listOf("d4"), OthelloScan.scanLine(init, 2, 3, Step(1, 0), "B"))

    @Test fun `scanLine 挟めない`() =
        assertEquals(emptyList<String>(), OthelloScan.scanLine(init, 0, 0, Step(1, 0), "B"))

    // ---- OthelloScan.kt:OthelloScan:flips
    @Test fun `flips 挟んだ升の一覧`() = assertEquals(listOf("d4"), OthelloScan.flips(init, "d3", "B"))
    @Test fun `flips 升に石が在る`() = assertEquals(emptyList<String>(), OthelloScan.flips(init, "d4", "B"))
    @Test fun `flips どの向きでも挟めない`() =
        assertEquals(emptyList<String>(), OthelloScan.flips(init, "a1", "B"))
    @Test fun `flips 升が盤の外`() = assertEquals(emptyList<String>(), OthelloScan.flips(init, "z9", "B"))

    // ---- OthelloRules.kt:OthelloRules:legalMoves
    @Test fun `legalMoves 置ける升あり`() =
        assertTrue(OthelloRules.legalMoves(init, "B").moves.contains("d3"))

    @Test fun `legalMoves 置ける升なし`() =
        assertEquals(emptyList<String>(), OthelloRules.legalMoves(fullB, "W").moves)

    @Test fun `legalMoves 数えた印は常に立つ`() =
        assertTrue(OthelloRules.legalMoves(fullB, "W").counted)

    // ---- OthelloRules.kt:OthelloRules:applyMove
    @Test fun `applyMove 置いた後の盤`() =
        assertTrue(OthelloRules.applyMove(init, "d3", "B")[3].contains("BB"))

    @Test fun `applyMove 盤は変わらない`() =
        assertTrue(OthelloRules.applyMove(init, "a1", "B")[3].contains("WB"))

    // ---- OthelloRules.kt:OthelloRules:isOver
    @Test fun `isOver 対局中`() = assertFalse(OthelloRules.isOver(init))
    @Test fun `isOver 終局`() = assertTrue(OthelloRules.isOver(fullB))
}
