package othello

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 素振り（DD-L4-othello-log §7）と、そこから段 5 が選ぶところまで。
 * ★材料から通しで確かめる——「選ばれた」ではなく「選べる材料が本当に作れる」ことを見る。
 */
class OthelloDrillTest {

    @get:Rule val tmp = TemporaryFolder()

    private val p1 = OthelloParam.levelParams(1, "")!!
    private val p4 = OthelloParam.levelParams(4, "")!!

    // ---- openDrill
    @Test fun `openDrill 置き場が空なら書けない`() =
        assertFalse(OthelloDrill.openDrill(p1, 1, p4, 4, "").ok)

    @Test fun `openDrill 開いたら両側の段と組が頭に在る`() {
        val log = OthelloDrill.openDrill(p1, 1, p4, 4, tmp.root.path)
        assertTrue(log.ok)
        val head = File(log.path).readLines().first()
        assertTrue(head.contains("\"level\":\"1\"") && head.contains("\"white_level\":\"4\""))
        assertTrue(head.contains("white_params"))
    }

    // ---- readOne が両側を読む
    @Test fun `readOne 段どうしの記録は白の組も返す`() {
        val log = OthelloDrill.openDrill(p1, 1, p4, 4, tmp.root.path)
        OthelloLogWrite.closeLog(log, Result("W", 20, 44))
        val got = OthelloLogRead.readOne(log.path)
        assertEquals(4, got.whiteLevel)
        assertNotNull(got.whiteParams)
    }

    // ---- runSeries
    @Test fun `runSeries 置き場が空なら 1 本も書かない`() =
        assertEquals(0, OthelloDrill.runSeries(listOf(Step(1, 4)), 1, ""))

    @Test fun `runSeries 開幕ごとに色を入れ替えて 2 局書く`() {
        val wrote = OthelloDrill.runSeries(listOf(Step(1, 4)), 2, tmp.root.path)
        assertEquals(4, wrote)
        assertEquals(4, tmp.root.listFiles()!!.size)
    }

    @Test fun `runSeries 書いた記録は全部 終局まで行っている`() {
        OthelloDrill.runSeries(listOf(Step(2, 4)), 1, tmp.root.path)
        val got = OthelloLogRead.collect(listOf(1, 2, 3, 4), tmp.root.path)
        assertEquals(2, got.used)
        assertTrue(got.games.all { it.finished && it.result != null })
    }

    // ---- ★通し: 素振りで作った材料から、段 5 が選べる
    @Test fun `段5 素振りの記録から選べる`() {
        OthelloDrill.runSeries(listOf(Step(1, 4), Step(2, 4), Step(3, 4)), 2, tmp.root.path)
        val got = OthelloParam.levelParams(5, tmp.root.path)!!
        // ★段 4 の組がいちばん勝っているはず（深さ 4・手の数 10）
        assertTrue(got.chosen && !got.fallback)
        assertEquals(4, got.depth)
        assertEquals(10, got.mobility)
        assertEquals(12, got.games)
    }

    @Test fun `段5 材料が無ければ選べず 段4 の値に落ちる`() {
        val got = OthelloParam.levelParams(5, tmp.root.path)!!
        assertTrue(got.fallback && !got.chosen)
        assertEquals(0, got.games)
    }
}
