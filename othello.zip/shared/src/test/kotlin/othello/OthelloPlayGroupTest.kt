package othello

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 対局の進行と境の群の単体試験。
 *
 * ★材料は DD-L4-othello-play の「試験材料」から起こしている。
 */
class OthelloPlayGroupTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val init = listOf("........", "........", "........", "...WB...",
        "...BW...", "........", "........", "........")
    private val afterD3 = listOf("........", "........", "...B....", "...BB...",
        "...BW...", "........", "........", "........")
    private val afterC3 = listOf("........", "........", "..WB....", "...WB...",
        "...BW...", "........", "........", "........")
    private val fullB = List(8) { "BBBBBBBB" }
    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)
    private val setupHm = Setup("human", "machine", null, null, 3, p3)
    private val setupHh = Setup("human", "human", null, null, null, null)
    private val new = State(init, "B", 0, listOf(), 0)
    private val noMoveB = State(fullB, "B", 0, listOf(), 0)
    private val noMoveW = State(fullB, "W", 0, listOf(), 0)
    private val e1 = Entry("d3", listOf("d4"), Before(init, "B", 0, 0))
    private val e2 = Entry("c3", listOf("d4"), Before(afterD3, "W", 1, 0))
    private val afterOne = State(afterD3, "W", 1, listOf(e1), 0)
    private val afterReply = State(afterC3, "B", 2, listOf(e1, e2), 0)

    // ---- OthelloState
    @Test fun `newState 初期の状態`() = assertEquals("B", OthelloState.newState().turn)
    @Test fun `countStones 枚数`() = assertEquals(2, OthelloState.countStones(init).b)
    @Test fun `lastMoveInfo まだ1手も無い`() = assertNull(OthelloState.lastMoveInfo(listOf()))
    @Test fun `lastMoveInfo 直前の手`() =
        assertEquals("d3", OthelloState.lastMoveInfo(listOf(e1))!!.square)

    // ---- OthelloGame
    @Test fun `beforeState 置く前の状態`() = assertEquals("B", OthelloGame.beforeState(new).turn)
    @Test fun `play 受理した`() = assertTrue(OthelloGame.play(new, "d3").ok)
    @Test fun `play 受理しない`() {
        val got = OthelloGame.play(new, "a1")
        assertTrue(!got.ok && got.reason.contains("裏返"))
    }
    @Test fun `play 連続パスを0に戻す`() =
        assertEquals(0, OthelloGame.play(new.copy(passes = 1), "d3").state!!.passes)

    @Test fun `passTurn 受理しない`() {
        val got = OthelloGame.passTurn(new)
        assertTrue(!got.ok && got.reason.contains("置ける"))
    }
    @Test fun `passTurn 受理した`() = assertTrue(OthelloGame.passTurn(noMoveB).ok)
    @Test fun `passTurn 2回続けば終局`() =
        assertTrue(OthelloGame.passTurn(OthelloGame.passTurn(noMoveB).state!!).over)

    // ---- OthelloUndo
    @Test fun `undo 受理しない`() {
        val got = OthelloUndo.undo(new, setupHm)
        assertTrue(!got.ok && got.reason.contains("戻せ"))
    }
    @Test fun `undo 受理した`() = assertTrue(OthelloUndo.undo(afterOne, setupHh).ok)
    @Test fun `undo 人が打つ番まで戻す`() {
        val got = OthelloUndo.undo(afterReply, setupHm).state!!
        assertTrue(got.turn == "B" && got.moves == 0)
    }

    // ---- OthelloView
    @Test fun `pressable 升が押せる`() = assertTrue(
        OthelloView.pressable(new, Moves(listOf("d3", "c4", "f5", "e6"), true)).squares.contains("d3"))
    @Test fun `pressable パスだけ押せる`() =
        assertTrue(OthelloView.pressable(new, Moves(listOf(), true)).canPass)
    @Test fun `pressable 履歴が無ければ待ったは押せない`() =
        assertFalse(OthelloView.pressable(new, Moves(listOf("d3"), true)).canUndo)

    @Test fun `buildView 一式`() = assertTrue(OthelloView.buildView(new, setupHm).hints.contains("d3"))
    @Test fun `buildView 開始直後に直前の手を出さない`() =
        assertNull(OthelloView.buildView(new, setupHm).last)
    @Test fun `buildView いま何段目かを入れる`() =
        // ★黒が人なので黒の段は無い。白の段が入る（CR-12）
        assertEquals(3, OthelloView.buildView(new, setupHm).whiteLevel)
    @Test fun `buildView 人対人なら段を持たない`() =
        assertNull(OthelloView.buildView(new, setupHh).blackLevel)
    @Test fun `buildView 対局中は文言が空`() =
        assertEquals("", OthelloView.buildView(new, setupHm).message)
    @Test fun `buildView 数えたことを一式にも残す`() {
        val got = OthelloView.buildView(new, setupHm)
        assertTrue(got.counted && got.hintCount == 4)
    }

    // ---- OthelloSetup（★段は白黒ごと・CR-12）
    @Test fun `newSetup 対局の設定`() =
        assertEquals("human", OthelloSetup.newSetup("human", "machine", 3, 3, tmp.root.path, "").black)
    @Test fun `newSetup 段が範囲の外`() =
        assertEquals("", OthelloSetup.newSetup("human", "machine", 3, 9, tmp.root.path, "").black)
    @Test fun `newSetup 打ち手の語が違う`() =
        assertEquals("", OthelloSetup.newSetup("dog", "human", 3, 3, tmp.root.path, "").black)
    @Test fun `newSetup 計算機の側だけ組を持つ`() {
        val got = OthelloSetup.newSetup("human", "machine", 3, 3, tmp.root.path, "")
        assertNull(got.blackParams)
        assertEquals(1, got.whiteParams!!.depth)
    }

    // ★黒と白で別々の段を持てる（CR-12）
    @Test fun `newSetup 黒と白で別々の段`() {
        val got = OthelloSetup.newSetup("machine", "machine", 3, 4, tmp.root.path, "")
        assertEquals(3, got.blackLevel)
        assertEquals(4, got.whiteLevel)
        assertTrue(got.blackParams!!.depth != got.whiteParams!!.depth)
    }

    // ★人の側の段は、範囲の外でも受け付ける（使わないから）
    @Test fun `newSetup 人の側の段は見ない`() =
        assertEquals("human", OthelloSetup.newSetup("human", "machine", 99, 3, tmp.root.path, "").black)
    @Test fun `newSetup 人対人は段を持たない`() {
        val got = OthelloSetup.newSetup("human", "human", 3, 3, tmp.root.path, "")
        assertTrue(got.blackLevel == null && got.whiteLevel == null)
        assertTrue(got.blackParams == null && got.whiteParams == null)
    }
    @Test fun `isMachineTurn 計算機の番`() = assertTrue(OthelloSetup.isMachineTurn(setupHm, "W"))
    @Test fun `isMachineTurn 人の番`() = assertFalse(OthelloSetup.isMachineTurn(setupHm, "B"))

    // ---- OthelloTurn
    @Test fun `machineStep 進めない`() = assertFalse(OthelloTurn.machineStep(new, setupHm).ok)
    @Test fun `machineStep 1手進めた`() = assertTrue(OthelloTurn.machineStep(afterOne, setupHm).ok)
    @Test fun `machineStep パスした`() = assertTrue(OthelloTurn.machineStep(noMoveW, setupHm).passed)

    // ---- OthelloPlace
    @Test fun `logRoot 指定された場所`() = assertEquals("runs", OthelloPlace.logRoot("othello", "runs", ""))
    @Test fun `logRoot 場所なし`() = assertEquals("", OthelloPlace.logRoot("othello", "", ""))
    @Test fun `logRoot 環境の下の場所`() =
        assertTrue(OthelloPlace.logRoot("othello", "", tmp.root.path).contains("othello"))
    @Test fun `logRoot 場所を作らない`() =
        assertFalse(java.io.File(OthelloPlace.logRoot("othello", "", tmp.root.path)).isDirectory)

    // ---- OthelloBridge
    @Test fun `handle 進んだ`() {
        // ★人と計算機の対局では、1 回の出来事で 2 手進む（人の 1 手と、計算機の応手）
        val got = OthelloBridge.handle(new, setupHm, Command("square", "d3"), "")
        assertTrue(got.ok && got.state.moves == 2)
    }
    @Test fun `handle 受け付けない`() {
        val got = OthelloBridge.handle(new, setupHm, Command("dance", ""), "")
        assertTrue(!got.ok && got.reason.contains("出来事"))
    }
    @Test fun `handle 断る`() {
        val got = OthelloBridge.handle(new, setupHm, Command("pass", ""), "")
        assertTrue(!got.ok && got.reason.contains("置ける"))
    }
    @Test fun `handle 断ったとき状態を変えない`() =
        assertEquals(new, OthelloBridge.handle(new, setupHm, Command("pass", ""), "").state)
    @Test fun `handle どの道でも一式を返す`() = assertTrue(
        listOf(Command("square", "d3"), Command("dance", ""), Command("pass", "")).all {
            OthelloBridge.handle(new, setupHm, it, "").view.hints != null
        })
    @Test fun `handle 対局を始める`() {
        val got = OthelloBridge.handle(afterOne, setupHm, Command("start", ""), "")
        assertTrue(got.ok && got.state.moves == 0 && got.state.history.isEmpty())
    }
    @Test fun `handle 待った`() =
        assertEquals("B", OthelloBridge.handle(afterReply, setupHm, Command("undo", ""), "").state.turn)

    // ---- ★実測で見つかった 2 件（2026-08-12）
    @Test fun `handle 人が打てば計算機も打つ`() {
        val got = OthelloBridge.handle(new, setupHm, Command("square", "d3"), "")
        // 黒（人）が 1 手、白（計算機）が 1 手で、手番は人に戻る
        assertTrue(got.state.moves == 2 && got.state.turn == "B")
    }

    @Test fun `handle 計算機どうしでも1手ずつしか進まない`() {
        // ★CR-6: 一気に終局まで回さない。次も計算機だと一式が言う
        val both = Setup("machine", "machine", 3, p3, 3, p3)
        val got = OthelloBridge.handle(OthelloState.newState(), both, Command("start", ""), "")
        assertTrue(got.state.moves == 1 && got.view.machineToMove)
    }

    @Test fun `handle 計算機の1手を送ると1手だけ進む`() {
        val both = Setup("machine", "machine", 3, p3, 3, p3)
        val first = OthelloBridge.handle(OthelloState.newState(), both, Command("start", ""), "")
        val second = OthelloBridge.handle(first.state, both, Command("machine", ""), "")
        assertTrue(second.state.moves == 2)
    }

    @Test fun `handle 一式は今回裏返った升を持つ`() {
        val got = OthelloBridge.handle(new, setupHh, Command("square", "d3"), "")
        assertEquals(listOf("d4"), got.view.flipped)
    }

    @Test fun `handle 人どうしなら勝手に進まない`() {
        val got = OthelloBridge.handle(new, setupHh, Command("square", "d3"), "")
        assertTrue(got.state.moves == 1 && got.state.turn == "W")
    }

    // ---- ★口が落ちた欠陥を、窓口の側で押さえる（DD-L2-othello §7z.2b2）
    @Test fun `handle 返る状態と一式は同じ読みから出る`() {
        val got = OthelloBridge.handle(new, setupHm, Command("square", "d3"), "")
        // 一式の盤・手番・手数は、返った状態と一致する（片方だけ新しい、が起きない）
        assertTrue(got.view.board == got.state.board &&
            got.view.turn == got.state.turn && got.view.moves == got.state.moves)
    }

    @Test fun `handle 始めた直後も同じ読みから出る`() {
        val machineFirst = Setup("machine", "human", 3, p3, null, null)
        val got = OthelloBridge.handle(OthelloState.newState(), machineFirst, Command("start", ""), "")
        // 黒（先手）が計算機なら、始めた時点で 1 手進んでいる
        assertTrue(got.state.moves == 1 && got.view.moves == 1 &&
            got.view.board == got.state.board)
    }

    // ---- ★CR-6 の材料から（一式が持つ 2 つ）
    @Test fun `buildView 対局の頭はめくるものが無い`() =
        assertEquals(emptyList<String>(), OthelloView.buildView(new, setupHm).flipped)

    @Test fun `buildView 人の番なら次は計算機でない`() =
        assertFalse(OthelloView.buildView(new, setupHm).machineToMove)

    @Test fun `buildView 計算機の番なら一式がそう言う`() =
        assertTrue(OthelloView.buildView(afterOne, setupHm).machineToMove)

    @Test fun `buildView 終局したら次は無い`() {
        val over = State(fullB, "W", 0, listOf(), 0)
        assertFalse(OthelloView.buildView(over, setupHm).machineToMove)
    }

    // ---- ★BUG-25 記録を呼ぶ者（DD-L2-othello §7z.2b3）
    @Test fun `handle 置き場が空なら記録を開かない`() =
        assertNull(OthelloBridge.handle(OthelloState.newState(), setupHm,
            Command("start", ""), "").state.log)

    @Test fun `handle 置き場が在れば記録を開く`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm, Command("start", ""), root)
        assertTrue(out.state.log != null && out.state.log!!.ok)
    }

    @Test fun `handle 1 手ごとに記録が伸びる`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        val begun = OthelloBridge.handle(OthelloState.newState(), setupHh, Command("start", ""), root)
        val one = OthelloBridge.handle(begun.state, setupHh, Command("square", "d3"), "")
        val lines = java.io.File(one.state.log!!.path).readLines().filter { it.isNotBlank() }
        assertEquals(2, lines.size)
        assertTrue(lines[1].contains("\"square\":\"d3\""))
    }

    @Test fun `handle 終局したら記録を閉じて手を離す`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        val log = OthelloLogWrite.openLog(setupHh, root)
        val near = State(listOf("BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBBB",
            "BBBBBBBB", "BBBBBBBB", "BBBBBBBW", "BBBBBB.W"), "B", 0,
            listOf(Entry("h7", listOf(), Before(listOf("BBBBBBBB", "BBBBBBBB", "BBBBBBBB",
                "BBBBBBBB", "BBBBBBBB", "BBBBBBBB", "BBBBBBB.", "BBBBBB.W"), "B", 0, 0))), 0, log)
        val out = OthelloBridge.handle(near, setupHh, Command("pass", ""), "")
        assertNull(out.state.log)
        assertTrue(java.io.File(log.path).readText().contains("close"))
    }

    // ---- ★実機で出た 3 件（BUG-29・30・31）
    @Test fun `handle 対局を始める以外では記録を開かない`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        OthelloBridge.handle(new, setupHh, Command("square", "d3"), root)
        // ★記録だけを数える。同じ置き場に DB も居る（DD-L3-othello-db §4.2）
        assertEquals(0, java.io.File(root).listFiles()!!.count { it.name.endsWith(".jsonl") })
    }

    @Test fun `handle 対局を始めるときだけ記録が 1 本できる`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        OthelloBridge.handle(new, setupHh, Command("start", ""), root)
        assertEquals(1, java.io.File(root).listFiles()!!.count { it.name.endsWith(".jsonl") })
    }

    @Test fun `handle 1 回の出来事で 2 手進んだら 2 件書く`() {
        val root = kotlin.io.path.createTempDirectory("othello-test").toString()
        val begun = OthelloBridge.handle(new, setupHm, Command("start", ""), root)
        val one = OthelloBridge.handle(begun.state, setupHm, Command("square", "d3"), "")
        val lines = java.io.File(one.state.log!!.path).readLines().filter { it.isNotBlank() }
        // 開始の 1 行 ＋ 人の 1 手 ＋ 計算機の 1 手
        assertEquals(3, lines.size)
        assertTrue(lines[1].contains("\"by\":\"human\"") && lines[2].contains("\"by\":\"machine\""))
    }

    // ---- ★段 5 が決め打ちで動いていることを、一式が言う（DD-L1-othello §5.2）
    @Test fun `buildView 段5が選べていれば選べたと言う`() =
        assertTrue(OthelloView.buildView(new, setupHm).picked)

    @Test fun `buildView 何局から選んだかを一式が持つ`() {
        val five = Setup("human", "machine", null, null, 5, Params(1, 10, 0, 4, 0, false, true, 30))
        val got = OthelloView.buildView(new, five)
        assertTrue(got.picked)
        assertEquals(30, got.pickedGames)
    }

    @Test fun `buildView 選べなければ局数は 0`() {
        val fell = Setup("human", "machine", null, null, 5, Params(1, 10, 0, 4, 0, true, false, 0))
        assertEquals(0, OthelloView.buildView(new, fell).pickedGames)
    }

    @Test fun `buildView 段5が選べなければ選べなかったと言う`() {
        val fell = Setup("human", "machine", null, null, 5,
            Params(1, 10, 0, 4, 0, true, false, 0))
        assertFalse(OthelloView.buildView(new, fell).picked)
    }
}
