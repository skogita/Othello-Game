package othello

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 対戦記録を SQL で読める形に残す（CR-9・CR-11 ／ DD-L4-othello-log §8）。
 * ★材料は設計書の試験材料から起こす。
 */
class OthelloDbTest {

    @get:Rule val tmp = TemporaryFolder()

    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)
    private val p4 = Params(1, 10, 0, 4, 0, false, false, 0)

    /** 終わった記録を 1 本作る。★人の側には段を付けない（CR-12）。 */
    private fun finished(name: String, level: Int, params: Params, winner: String): String {
        val setup = Setup("human", "machine", null, null, level, params)
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        OthelloLogWrite.appendEvent(log, "move",
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloLogWrite.closeLog(log, Result(winner, 34, 30))
        return log.path
    }

    // ---- openDb
    @Test fun `openDb 置き場が空ならメモリの上`() =
        assertTrue(OthelloDb.openDb("").path.contains("memory"))

    @Test fun `openDb 置き場が在ればファイルの上`() {
        val db = OthelloDb.openDb(tmp.root.path)
        assertTrue(db.ok && db.path.contains("othello.db"))
        assertTrue(File(db.path).exists())
    }

    // ---- saveGame
    @Test fun `saveGame 終わっていない記録は入れない`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val setup = Setup("human", "machine", null, null, 3, p3)
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        assertFalse(OthelloDbKeep.saveGame(db, log.path, "").ok)
    }

    @Test fun `saveGame 終わった記録は入る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        assertTrue(OthelloDbKeep.saveGame(db, finished("g", 3, p3, "B"), "ためし").ok)
        assertEquals(1, OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).used)
    }

    // ★同じ在り処を 2 度入れない（二重に数えないため。DD-L4-othello-log §8.3）
    @Test fun `saveGame 同じ記録は入れ直さない`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val path = finished("g", 3, p3, "B")
        OthelloDbKeep.saveGame(db, path, "")
        OthelloDbKeep.saveGame(db, path, "")
        assertEquals(1, OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).used)
    }

    // ---- collectGames
    @Test fun `collectGames 1 本も無ければ空`() =
        assertEquals(0, OthelloDbView.collectGames(OthelloDb.openDb(tmp.root.path), listOf(1, 2, 3, 4)).used)

    // ★どちらかの側の段が対象なら取る（黒が人の対局が落ちない。BUG-44）
    @Test fun `collectGames 白の段でも取れる`() {
        val db = OthelloDb.openDb(tmp.root.path)
        OthelloDbKeep.saveGame(db, finished("g", 3, p3, "B"), "")
        assertEquals(1, OthelloDbView.collectGames(db, listOf(3)).used)
        assertEquals(0, OthelloDbView.collectGames(db, listOf(1, 2)).used)
    }

    @Test fun `collectGames 中身が戻る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        OthelloDbKeep.saveGame(db, finished("g", 4, p4, "W"), "たたかい")
        val got = OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).games[0]
        assertEquals("human", got.black)
        assertEquals("machine", got.white)
        assertEquals(4, got.whiteLevel)
        assertEquals("W", got.result!!.winner)
        assertEquals(4, got.whiteParams!!.depth)
    }

    // ---- ★通し: DB の記録から段 5 が選べる（CR-11）
    @Test fun `段5 DB の記録から選べる`() {
        val db = OthelloDb.openDb(tmp.root.path)
        OthelloDbKeep.saveGame(db, finished("g1", 3, p3, "B"), "")
        OthelloDbKeep.saveGame(db, finished("g2", 4, p4, "W"), "")
        val got = OthelloDbView.collectGames(db, listOf(1, 2, 3, 4))
        assertEquals(2, got.used)
        // ★白（計算機）が勝った p4 のほうが、勝率が高い
        val won = got.games.filter { it.result!!.winner == "W" }
        assertEquals(1, won.size)
        assertEquals(4, won[0].whiteParams!!.depth)
    }

    // ---- ★通し: 対局を閉じると DB に入る（CR-9）／段 5 が DB から選ぶ（CR-11）
    @Test fun `窓口 終局したら DB に入る`() {
        val root = tmp.root.path
        val setup = Setup("machine", "machine", 3, p3, 3, p3)
        var now = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), root)
        var guard = 0
        while (!OthelloRules.isOver(now.state.board) && guard < 80) {
            now = OthelloBridge.handle(now.state, setup, Command("machine", ""), root)
            guard += 1
        }
        assertTrue(OthelloRules.isOver(now.state.board))
        // ★閉じたら記録の手を離す。そのとき DB へ入る
        assertTrue(now.state.log == null)
        assertEquals(1, OthelloDbView.collectGames(OthelloDb.openDb(root), listOf(1, 2, 3, 4)).used)
    }

    @Test fun `段5 DB に在れば DB から選ぶ`() {
        val root = tmp.root.path
        val db = OthelloDb.openDb(root)
        OthelloDbKeep.saveGame(db, finished("g1", 4, p4, "W"), "")
        OthelloDbKeep.saveGame(db, finished("g2", 3, p3, "B"), "")
        val got = OthelloParam.levelParams(5, root)!!
        assertTrue(got.chosen && !got.fallback)
        // ★★p4 と p3 は当たっていない ∴ 2 つとも最強（DD-L3-othello-ai §3.4b・裁定2026-08-19）。
        //   ★ここで見るのは「DB から選べたこと」であり、どちらが強いかではない
        assertTrue(got.depth == p3.depth || got.depth == p4.depth)
        assertEquals(2, got.games)
    }

    // ---- ★新しい形（対局の頭・1 手ごと・終わり）
    private val setupMm = Setup("machine", "machine", 3,
        Params(1, 0, 0, 1, 0, false, false, 0), 3, Params(1, 0, 0, 1, 0, false, false, 0))
    private val setupHm = Setup("human", "machine", null, null, 3, p3)

    @Test fun `startGame DB が開いていなければ 0`() =
        assertEquals(0, OthelloDb.startGame(DbHandle("", false, ""), setupHm, "runs/g1.jsonl", ""))

    @Test fun `startGame 番号が付く`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val id = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "ためし")
        assertTrue(id > 0)
    }

    // ★同じ在り処は 2 度入らない（二重に数えないため）
    @Test fun `startGame 同じ在り処は 2 度入らない`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val one = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "")
        val two = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "")
        assertTrue(one > 0 && two == 0)
    }

    @Test fun `addMove 対局の番号が無ければ 足さない`() =
        assertFalse(OthelloDb.addMove(OthelloDb.openDb(tmp.root.path), 0, 1,
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1")).ok)

    @Test fun `addMove 1 手ごとに足せる`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val id = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "")
        assertTrue(OthelloDb.addMove(db, id, 1,
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1")).ok)
        assertEquals(listOf("d3"), OthelloDb.readMoves(db, id))
    }

    // ★seq の順に返る（並べ直しを忘れても気づけるように）
    @Test fun `readMoves 手数の順に返る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val id = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g2.jsonl", "")
        OthelloDb.addMove(db, id, 2, mapOf("turn" to "W", "by" to "machine", "square" to "c4", "flips" to "1"))
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        assertEquals(listOf("d3", "c4"), OthelloDb.readMoves(db, id))
    }

    @Test fun `readMoves 無い対局は 空`() =
        assertTrue(OthelloDb.readMoves(OthelloDb.openDb(tmp.root.path), 999).isEmpty())

    @Test fun `finishGame 対局の番号が無ければ 終われない`() =
        assertFalse(OthelloDb.finishGame(OthelloDb.openDb(tmp.root.path), 0, Result("B", 34, 30)).ok)

    // ★終わるまでは、段 5 の材料に出てこない（勝敗が空だから）
    @Test fun `finishGame 終わって初めて材料になる`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val id = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g3.jsonl", "")
        assertEquals(0, OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).used)
        assertTrue(OthelloDb.finishGame(db, id, Result("W", 30, 34)).ok)
        assertEquals(1, OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).used)
    }

    // ---- listGames
    @Test fun `listGames 1 本も無ければ 空`() =
        assertTrue(OthelloDbView.listGames(OthelloDb.openDb(tmp.root.path), 20).isEmpty())

    @Test fun `listGames 新しい順に返り 番号が入る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val one = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "ふるい")
        OthelloDb.finishGame(db, one, Result("B", 34, 30))
        val two = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g2.jsonl", "あたらしい")
        OthelloDb.finishGame(db, two, Result("W", 30, 34))
        val got = OthelloDbView.listGames(db, 20)
        assertEquals(2, got.size)
        assertEquals("あたらしい", got[0].name)
        assertEquals(two, got[0].id)
    }

    // ---- ★控え（3 代前まで）
    @Test fun `backupDb 置き場が空なら 控えない`() =
        assertEquals(0, OthelloDbKeep.backupDb(OthelloDb.openDb(""), "", 3))

    @Test fun `backupDb 3 代前まで残り 古いのは消える`() {
        val db = OthelloDb.openDb(tmp.root.path)
        OthelloDb.startGame(db, setupHm, tmp.root.path + "/g1.jsonl", "")
        for (i in 1..5) OthelloDbKeep.backupDb(db, tmp.root.path, 3)
        assertEquals(3, (1..3).count { File(tmp.root, "othello.db.$it").exists() })
        assertFalse(File(tmp.root, "othello.db.4").exists())
    }

    // ---- 取り込み
    @Test fun `importFolder 置き場が空なら 0`() =
        assertEquals(0, OthelloDbKeep.importFolder(OthelloDb.openDb(""), ""))

    // ★何度押しても、増えるのは新しい分だけ
    @Test fun `importFolder 2 度目は増えない`() {
        val db = OthelloDb.openDb(tmp.root.path)
        finished("g1", 3, p3, "B")
        finished("g2", 4, p4, "W")
        assertEquals(2, OthelloDbKeep.importFolder(db, tmp.root.path))
        assertEquals(0, OthelloDbKeep.importFolder(db, tmp.root.path))
        assertEquals(2, OthelloDbView.collectGames(db, listOf(1, 2, 3, 4)).used)
    }

    // ---- ★通し: 対局を通すと、手が 1 つずつ DB に入る
    @Test fun `窓口 1 手ごとに DB へ入る`() {
        val root = tmp.root.path
        val setup = Setup("machine", "machine", 3, p3, 3, p3)
        val begun = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), root)
        assertTrue(begun.state.gameId > 0)
        // ★対局を始めた時点で、計算機が 1 手打っている（DD-L1-othello §6.5b）
        assertEquals(begun.state.moves, OthelloDb.readMoves(OthelloDb.openDb(root), begun.state.gameId).size)
        val one = OthelloBridge.handle(begun.state, setup, Command("machine", ""), root)
        assertEquals(one.state.moves, OthelloDb.readMoves(OthelloDb.openDb(root), begun.state.gameId).size)
        assertTrue(one.state.moves > begun.state.moves)
    }

    // ---- ★中身を出す道具（DD-L4-othello-db §3.3f）
    @Test fun `dumpAll 1 本も無ければ 空`() =
        assertTrue(OthelloDbView.dumpAll(OthelloDb.openDb(tmp.root.path)).isEmpty())

    @Test fun `dumpAll 対局と手が 1 行ずつ出る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val id = OthelloDb.startGame(db, setupHm, tmp.root.path + "/g9.jsonl", "みほん")
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val got = OthelloDbView.dumpAll(db)
        assertEquals(2, got.size)
        assertTrue(got[0].startsWith("games |") && got[0].contains("みほん"))
        assertTrue(got[1].startsWith("moves |") && got[1].contains("d3"))
    }

    // ★古い順に出る（一覧は新しい順・中身は起きた順）
    @Test fun `dumpAll 古い順に出る`() {
        val db = OthelloDb.openDb(tmp.root.path)
        val one = OthelloDb.startGame(db, setupHm, tmp.root.path + "/ga.jsonl", "さき")
        val two = OthelloDb.startGame(db, setupHm, tmp.root.path + "/gb.jsonl", "あと")
        OthelloDb.finishGame(db, one, Result("B", 34, 30))
        OthelloDb.finishGame(db, two, Result("W", 30, 34))
        val got = OthelloDbView.dumpAll(db)
        assertTrue(got[0].contains("さき") && got[1].contains("あと"))
    }

    // ---- ★窓口が受ける 2 つ（一覧・取り込み。DD-L4-othello-bridge §3.2 の 5f・5g）
    @Test fun `窓口 一覧は一式に載る`() {
        val root = tmp.root.path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupHm, root + "/gz.jsonl", "いちらん")
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm, Command("games", ""), root)
        assertTrue(out.view.games.any { it.name == "いちらん" })
    }

    // ★1 本も無ければ、選ぶものが無いと言う（DD-L1-othello §5.5b）
    @Test fun `窓口 記録が無ければ そう言う`() {
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm,
            Command("games", ""), tmp.newFolder("からっぽ").path)
        assertTrue(out.view.games.isEmpty())
        assertTrue(out.view.message.contains("まだ記録がありません"))
    }

    // ★一覧も取り込みも、盤を変えない
    @Test fun `窓口 一覧は盤を変えない`() {
        val now = OthelloState.newState()
        val out = OthelloBridge.handle(now, setupHm, Command("games", ""), tmp.root.path)
        assertEquals(now.board, out.state.board)
    }

    @Test fun `窓口 取り込みは本数を出す`() {
        val root = tmp.newFolder("とりこみ").path
        // ★終わった記録を 1 本置く（記録の口から作る）
        val log = OthelloLogWrite.openLog(setupHm, root)
        OthelloLogWrite.appendEvent(log, "move",
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloLogWrite.closeLog(log, Result("B", 34, 30))
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm, Command("import", ""), root)
        // ★画面に出るのは一式の文言。理由は画面に出ていない（BUG-48）
        assertTrue(out.view.message.contains("1 本"))
        // ★2 度目は 0 本（同じ在り処は 2 度入らない）
        val again = OthelloBridge.handle(OthelloState.newState(), setupHm, Command("import", ""), root)
        assertTrue(again.view.message.contains("0 本"))
    }

    // ---- ★再生（CR-10）
    @Test fun `窓口 再生は記録を残さない`() {
        val root = tmp.newFolder("さいせい").path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupHm, root + "/gr.jsonl", "さいせい")
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm,
            Command("replay", id.toString()), root)
        assertNull(out.state.log)
        assertEquals(listOf("d3"), out.state.replay)
        assertTrue(out.view.replaying)
    }

    // ★再生中は打てない・戻せない（10-2・10-3）
    @Test fun `窓口 再生中は押せない`() {
        val root = tmp.newFolder("おせない").path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupHm, root + "/gs.jsonl", "おせない")
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm,
            Command("replay", id.toString()), root)
        assertTrue(out.view.pressable.squares.isEmpty())
        assertTrue(!out.view.pressable.canPass && !out.view.pressable.canUndo)
    }

    // ★次の 1 手で並びが減り、終われば続きが無いと言う
    @Test fun `窓口 再生の次で並びが減る`() {
        val root = tmp.newFolder("つぎ").path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupHm, root + "/gt.jsonl", "つぎ")
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val begun = OthelloBridge.handle(OthelloState.newState(), setupHm,
            Command("replay", id.toString()), root)
        val one = OthelloBridge.handle(begun.state, setupHm, Command("next", ""), root)
        assertTrue(one.state.replay.isEmpty())
        assertTrue(!one.view.replaying)
        assertNull(one.state.log)
    }

    // ★★再生は、並びを使い切ったら止まる（BUG-47）。計算機が続けて打たない
    @Test fun `窓口 再生は使い切ったら止まる`() {
        val root = tmp.newFolder("とまる").path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupMm, root + "/gu.jsonl", "とまる")
        // ★2 手だけ入れる。使い切ったあとに伸びないことを見る
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "machine", "square" to "d3", "flips" to "1"))
        OthelloDb.addMove(db, id, 2, mapOf("turn" to "W", "by" to "machine", "square" to "c3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        var now = OthelloBridge.handle(OthelloState.newState(), setupMm,
            Command("replay", id.toString()), root)
        // ★両方が計算機の対局でも、再生中は打ち手を呼ばない
        assertTrue(!now.view.machineToMove)
        now = OthelloBridge.handle(now.state, setupMm, Command("next", ""), root)
        now = OthelloBridge.handle(now.state, setupMm, Command("next", ""), root)
        assertEquals(2, now.state.moves)
        assertTrue(!now.view.replaying)
        // ★もう 1 回送っても伸びない（画面が送り続けても止まる）
        val more = OthelloBridge.handle(now.state, setupMm, Command("next", ""), root)
        assertEquals(2, more.state.moves)
        // ★形勢の並びも伸びない（グラフが止まる）
        assertEquals(now.state.trend.black.size, more.state.trend.black.size)
    }

    // ---- ★書き出す（CR-13 の 13-5）
    @Test fun `writeDump 置き場が空なら 書かない`() =
        assertEquals("", OthelloDbView.writeDump(OthelloDb.openDb(""), ""))

    @Test fun `writeDump 中身と同じ行数を書く`() {
        val root = tmp.newFolder("かきだし").path
        val db = OthelloDb.openDb(root)
        val id = OthelloDb.startGame(db, setupHm, root + "/gw.jsonl", "かきだし")
        OthelloDb.addMove(db, id, 1, mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloDb.finishGame(db, id, Result("B", 34, 30))
        val at = OthelloDbView.writeDump(db, root)
        assertTrue(at.endsWith("othello-dump.txt"))
        val lines = java.io.File(at).readLines().filter { it.isNotBlank() }
        assertEquals(OthelloDbView.dumpAll(db).size, lines.size)
        assertTrue(lines[0].contains("かきだし"))
    }

    // ★上書きする。代を持たない（中身は DB が持っている）
    @Test fun `writeDump 2 度目も 1 本だけ`() {
        val root = tmp.newFolder("うわがき").path
        val db = OthelloDb.openDb(root)
        OthelloDbView.writeDump(db, root)
        OthelloDbView.writeDump(db, root)
        assertEquals(1, java.io.File(root).listFiles()!!.count { it.name.startsWith("othello-dump") })
    }

    // ★窓口が受け、在り処を文言に出す（CR-13 の 13-7）
    @Test fun `窓口 書き出しは在り処を文言に出す`() {
        val root = tmp.newFolder("もんこう").path
        val out = OthelloBridge.handle(OthelloState.newState(), setupHm, Command("dump", ""), root)
        assertTrue(out.view.message.contains("othello-dump.txt"))
        assertTrue(java.io.File(root, "othello-dump.txt").exists())
    }

    // ★★置き場が無くても開ける（BUG-49）。1 度も対局していない機械で起きる
    @Test fun `openDb 置き場が無ければ作って開く`() {
        val root = java.io.File(tmp.root, "まだない/おくば").path
        val db = OthelloDb.openDb(root)
        assertTrue(db.ok)
        assertTrue(java.io.File(root).isDirectory)
        // ★開いた先で、ちゃんと書ける
        val id = OthelloDb.startGame(db, setupHm, root + "/gy.jsonl", "あたらしい")
        assertTrue(id > 0)
    }

    // ★★撃つ前に見る。番号を消費しない（BUG-50）
    @Test fun `saveGame 2 度目は番号を消費しない`() {
        val root = tmp.newFolder("ばんごう").path
        val db = OthelloDb.openDb(root)
        val log = OthelloLogWrite.openLog(setupHm, root)
        OthelloLogWrite.appendEvent(log, "move",
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloLogWrite.closeLog(log, Result("B", 34, 30))
        OthelloDbKeep.importFolder(db, root)
        val first = OthelloDbView.listGames(db, 10).first().id
        // ★同じ置き場をもう 3 回取り込む（起動を 3 回したのと同じ）
        for (i in 1..3) OthelloDbKeep.importFolder(db, root)
        // ★次に入る番号が飛んでいないことを、新しい 1 本で見る
        val next = OthelloDb.startGame(db, setupHm, root + "/gz9.jsonl", "つぎ")
        assertEquals(first + 1, next)
    }

    // ★未完と引き分けを、同じ顔にしない（BUG-51）
    @Test fun `dumpAll 未完はまだと出る`() {
        val root = tmp.newFolder("みかん").path
        val db = OthelloDb.openDb(root)
        val one = OthelloDb.startGame(db, setupHm, root + "/ga9.jsonl", "とちゅう")
        val two = OthelloDb.startGame(db, setupHm, root + "/gb9.jsonl", "ひきわけ")
        OthelloDb.finishGame(db, two, Result("-", 32, 32))
        val got = OthelloDbView.dumpAll(db)
        assertTrue(got.first { it.contains("とちゅう") }.contains("winner=まだ"))
        assertTrue(got.first { it.contains("ひきわけ") }.contains("winner=-"))
        assertTrue(one > 0)
    }

    // ---- ★対局の名前（CR-9 の 9-2）
    @Test fun `newSetup 名前をそのまま載せる`() =
        assertEquals("けさの一局",
            OthelloSetup.newSetup("human", "machine", 3, 3, tmp.root.path, "けさの一局").name)

    @Test fun `newSetup 名前が空でも断らない`() =
        assertEquals("human",
            OthelloSetup.newSetup("human", "machine", 3, 3, tmp.root.path, "").black)

    // ★対局を始めると、その名前で DB に入る
    @Test fun `窓口 名前が DB に入る`() {
        val root = tmp.newFolder("なまえ").path
        val setup = OthelloSetup.newSetup("human", "machine", 3, 3, root, "けさの一局")
        val out = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), root)
        assertTrue(out.state.gameId > 0)
        assertTrue(OthelloDbView.dumpAll(OthelloDb.openDb(root))
            .any { it.contains("name=けさの一局") })
    }

    // ★空なら日時が名前になる（決めの後半）
    @Test fun `窓口 名前が空なら日時が入る`() {
        val root = tmp.newFolder("にちじ").path
        val setup = OthelloSetup.newSetup("human", "machine", 3, 3, root, "")
        OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), root)
        val line = OthelloDbView.dumpAll(OthelloDb.openDb(root)).first { it.startsWith("games") }
        val name = line.substringAfter("name=").substringBefore(" |")
        assertEquals(line.substringAfter("at=").substringBefore(" |"), name)
    }
}
