package othello

import java.io.File
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 打ち手の群の単体試験。
 *
 * ★材料は DD-L4-othello-ai の「試験材料」から起こしている。
 */
class OthelloAiGroupTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val init = listOf(
        "........", "........", "........", "...WB...",
        "...BW...", "........", "........", "........"
    )
    private val fullB = List(8) { "BBBBBBBB" }
    private val oneW = List(7) { "BBBBBBBB" } + "BBBBBBW."
    private val p0 = Params(0, 0, 0, 1, 0, false, false, 0)
    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)
    private val p4 = Params(1, 10, 0, 4, 0, false, false, 0)
    private val low = OthelloSearch.LOW
    private val high = OthelloSearch.HIGH

    // ---- OthelloWeight
    @Test fun `weightOf その升の重み`() = assertEquals(120, OthelloWeight.weightOf(0, 0))
    @Test fun `weightOf 重みなし`() = assertEquals(0, OthelloWeight.weightOf(9, 0))
    @Test fun `weightOf 角の斜めの隣が最も負`() = assertEquals(-40, OthelloWeight.weightOf(1, 1))
    @Test fun `weightOf 盤の四隅で対称`() = assertEquals(
        listOf(120, 120, 120, 120),
        listOf(0, 7).flatMap { r -> listOf(0, 7).map { c -> OthelloWeight.weightOf(r, c) } })

    @Test fun `positionScore 位置の点`() = assertEquals(0, OthelloWeight.positionScore(init, "B"))

    // ---- OthelloEval
    @Test fun `mobility 手の数の差`() = assertEquals(0, OthelloEval.mobility(init, "B"))
    @Test fun `evaluate 点なし`() = assertEquals(0, OthelloEval.evaluate(init, "B", p0))
    @Test fun `evaluate 盤の点`() = assertEquals(0, OthelloEval.evaluate(init, "B", p4))

    // ---- OthelloSearch:search
    @Test fun `search 読まずの点 深さが0`() {
        val got = OthelloSearch.search(init, "B", 0, p3, low, high, 0)
        assertEquals("", got.move)
    }

    @Test fun `search 読まずの点 置ける升が無い`() =
        assertEquals("", OthelloSearch.search(fullB, "W", 1, p3, low, high, 0).move)

    @Test fun `search 読んだ点と升`() =
        assertEquals("c4", OthelloSearch.search(init, "B", 1, p3, low, high, 0).move)

    @Test fun `search 点と升は同じ読みから出る`() {
        val got = OthelloSearch.search(init, "B", 2, p4, low, high, 0)
        val other = OthelloSearch.search(
            OthelloRules.applyMove(init, got.move, "B"), "W", 1, p4, low, high, 0)
        assertEquals(got.score, -other.score)
    }

    @Test fun `search 深さは1手が1`() {
        val one = OthelloSearch.search(init, "B", 1, p4, low, high, 0).score
        val hand = OthelloRules.legalMoves(init, "B").moves.sorted().maxOf {
            -OthelloEval.evaluate(OthelloRules.applyMove(init, it, "B"), "W", p4)
        }
        assertEquals(hand, one)
    }

    // ---- OthelloSearch:bestMove
    @Test fun `bestMove 最も良い升`() =
        assertEquals("c4", OthelloSearch.bestMove(init, "B", 1, p3, low, high, 0))

    @Test fun `bestMove 置けない`() =
        assertEquals("", OthelloSearch.bestMove(fullB, "W", 1, p3, low, high, 0))

    @Test fun `bestMove 同じ材料なら同じ手`() = assertEquals(
        OthelloSearch.bestMove(init, "B", 2, p4, low, high, 0),
        OthelloSearch.bestMove(init, "B", 2, p4, low, high, 0))

    @Test fun `bestMove 枝刈りは返る手を変えない`() = assertEquals(
        OthelloSearch.bestMove(init, "B", 2, p4, low, high, 0),
        OthelloSearch.bestMove(init, "B", 2, p4, -5, 5, 0))

    @Test fun `bestMove 係数が全部0なら升の順で最初`() =
        assertEquals("c4", OthelloSearch.bestMove(init, "B", 1, p0, low, high, 0))

    // ---- OthelloParam
    private fun game(name: String, level: Int, params: Params, winner: String,
                     black: String = "human", white: String = "machine") {
        // ★人の側には段を付けない。計算機の側にだけ段と組を書く（CR-12）
        val body = mutableMapOf("black" to black, "white" to white)
        val text = Json.encodeToString(Params.serializer(), params)
        if (black == "machine") {
            body["params"] = text
            body["level"] = level.toString()
        }
        if (white == "machine") {
            body["white_params"] = text
            body["white_level"] = level.toString()
        }
        val head = Event("", "open", body)
        val lines = listOf(head, Event("", "move", mapOf()),
            Event("", "close", mapOf("winner" to winner, "black" to "34", "white" to "30")))
        File(tmp.root, name).writeText(
            lines.joinToString("\n") { Json.encodeToString(Event.serializer(), it) } + "\n")
    }

    @Test fun `levelParams 段の組`() = assertEquals(4, OthelloParam.levelParams(4, tmp.root.path)!!.depth)
    @Test fun `levelParams 設定なし`() = assertNull(OthelloParam.levelParams(9, tmp.root.path))

    @Test fun `levelParams 段4に落とした組`() {
        val got = OthelloParam.levelParams(5, tmp.root.path)!!
        assertTrue(got.fallback && !got.chosen)
    }

    // ★測って入れ替えた（DD-L3-othello-ai §3.2）。段 1 は枚数だけ、段 2 が全部 0
    @Test fun `levelParams 段1は枚数だけを見る`() {
        val got = OthelloParam.levelParams(1, tmp.root.path)!!
        assertTrue(got.weight == 0 && got.mobility == 0 && got.stones == 1)
    }

    @Test fun `levelParams 段2は係数が全部0`() {
        val got = OthelloParam.levelParams(2, tmp.root.path)!!
        assertTrue(got.weight == 0 && got.mobility == 0 && got.stones == 0)
    }

    @Test fun `levelParams 深さは1以上`() =
        assertTrue((1..4).all { OthelloParam.levelParams(it, tmp.root.path)!!.depth >= 1 })

    @Test fun `bestParams 選べない`() = assertNull(OthelloParam.bestParams(tmp.root.path))

    // ★★当たっていない組どうしは、互いに勝ち越していない（DD-L3-othello-ai §3.4b・裁定2026-08-19）。
    //   ★p3 と p4 は一度も当たっていない ∴ 最強の集合には 2 つとも入る。
    //   ★★旧い試験は「人に勝った p4 が選ばれる」と書いていた——★それは通算の勝率の見方であり、
    //   ★対ごとの勝ち越しでは言えない（★共通の相手を介して比べる決めは、まだ無い）。
    @Test fun `bestParams 当たっていない組は互いに勝ち越していない`() {
        game("g1.jsonl", 3, p3, "B")
        game("g2.jsonl", 4, p4, "W")
        val got = OthelloParam.bestParams(tmp.root.path)!!
        // ★最強の集合から取る。どちらも最強なので、取られるのはそのどちらか（同§）
        assertTrue(got.depth == p3.depth || got.depth == p4.depth)
        assertEquals(2, got.games)
        assertTrue(got.chosen)
        // ★決まった順で取る＝2 度呼んでも同じ組（DD-L1-othello §4「同じ盤面には同じ手を返す」）
        assertEquals(got, OthelloParam.bestParams(tmp.root.path)!!)
    }

    @Test fun `bestParams 勝ちは計算機の側で数える`() {
        game("g1.jsonl", 3, p3, "B", black = "machine", white = "human")
        game("g2.jsonl", 4, p4, "B")
        // 黒＝計算機で黒が勝った g1 が、計算機の勝ち。黒の勝ちで数えると両方 1 勝になって見分けが付かない
        val got = OthelloParam.bestParams(tmp.root.path)!!
        assertTrue(got.depth == 1 && got.games == 2)
    }

    @Test fun `bestParams 両方とも計算機の対局は使わない`() {
        game("g1.jsonl", 3, p3, "B", black = "machine", white = "machine")
        assertNull(OthelloParam.bestParams(tmp.root.path))
    }

    @Test fun `bestParams 段5の対局は母数に入れない`() {
        game("g1.jsonl", 5, p4, "B")
        assertNull(OthelloParam.bestParams(tmp.root.path))
    }

    // ---- OthelloAi
    @Test fun `chooseMove 次の手`() = assertEquals("c4", OthelloAi.chooseMove(init, "B", p3).move)
    @Test fun `chooseMove 決められない`() = assertTrue(!OthelloAi.chooseMove(init, "B", null).ok)
    @Test fun `chooseMove 手が無い`() = assertEquals("", OthelloAi.chooseMove(fullB, "W", p3).move)
    @Test fun `chooseMove 同じパラメータなら同じ手`() = assertEquals(
        OthelloAi.chooseMove(init, "B", p4).move, OthelloAi.chooseMove(init, "B", p4).move)

    @Test fun `chooseMove 相手が置けない盤でも返る`() =
        assertTrue(OthelloAi.chooseMove(oneW, "B", p3).ok)

    // ---- ★段 6（著者方式・CR-7）
    @Test fun `authorOf 隅は 25`() = assertEquals(25, OthelloWeight.authorOf(0, 0))

    @Test fun `authorOf 隅に接する 3 升は マイナス 16`() {
        assertEquals(-16, OthelloWeight.authorOf(0, 1))
        assertEquals(-16, OthelloWeight.authorOf(1, 0))
        assertEquals(-16, OthelloWeight.authorOf(1, 1))
    }

    // ★大外は 4 辺とも同じ並び（DD-L3-othello-ai §3.1b）
    @Test fun `authorOf 大外は 4 辺とも同じ並び`() {
        val want = listOf(25, -16, 9, -1, -1, 9, -16, 25)
        assertEquals(want, (0..7).map { OthelloWeight.authorOf(0, it) })
        assertEquals(want, (0..7).map { OthelloWeight.authorOf(7, it) })
        assertEquals(want, (0..7).map { OthelloWeight.authorOf(it, 0) })
        assertEquals(want, (0..7).map { OthelloWeight.authorOf(it, 7) })
    }

    // ★斜めも 1 歩と数える（縦横の合計で数えると、ここが崩れる）
    @Test fun `authorOf 斜めは 25 マイナス16 9 9`() =
        assertEquals(listOf(25, -16, 9, 9), (0..3).map { OthelloWeight.authorOf(it, it) })

    // ★左右・上下とも対称（DD-L3-othello-ai §3.1b）
    @Test fun `authorOf 盤は対称`() {
        for (r in 0..7) {
            for (c in 0..7) {
                assertEquals(OthelloWeight.authorOf(r, c), OthelloWeight.authorOf(r, 7 - c))
                assertEquals(OthelloWeight.authorOf(r, c), OthelloWeight.authorOf(7 - r, c))
            }
        }
    }

    @Test fun `authorScore 石が無ければ 0`() =
        assertEquals(0, OthelloWeight.authorScore(List(8) { "........" }, "B"))

    @Test fun `authorScore 相手の石は符号が逆`() {
        val one = listOf("B.......", "........", "........", "........",
            "........", "........", "........", "........")
        assertEquals(25, OthelloWeight.authorScore(one, "B"))
        assertEquals(-25, OthelloWeight.authorScore(one, "W"))
    }

    @Test fun `evaluate 段6は表だけで決める`() {
        val six = OthelloParam.levelParams(6, "")!!
        val one = listOf("B.......", "........", "........", "........",
            "........", "........", "........", "........")
        assertEquals(OthelloWeight.authorScore(one, "B"), OthelloEval.evaluate(one, "B", six))
    }

    @Test fun `levelParams 段6は著者方式で 10 手先`() {
        val six = OthelloParam.levelParams(6, "")!!
        assertTrue(six.author && six.depth == 10)
    }

    @Test fun `levelParams 段7は受け付けない`() = assertNull(OthelloParam.levelParams(7, tmp.root.path))

    // ---- ★打ち切り（DD-L1-othello-ai §4.4・利用者の裁定 2026-08-13）
    @Test fun `search 打ち切りの時刻を過ぎていたら読まない`() {
        // ★過去の時刻を渡す＝もう過ぎている。読まずにその盤を点にする
        val got = OthelloSearch.search(init, "B", 4, p4, low, high, 1L)
        assertEquals("", got.move)
        assertEquals(OthelloEval.evaluate(init, "B", p4), got.score)
    }

    @Test fun `search 打ち切らないなら 0 を渡す`() =
        assertEquals("c4", OthelloSearch.search(init, "B", 1, p3, low, high, 0).move)

    // ★時計そのものは測らない（待つ試験にしない）。上限が決めどおりかだけ見る
    @Test fun `chooseMove 上限は 5 秒`() = assertEquals(5000L, OthelloAi.LIMIT)
}
