package othello

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 形勢の線グラフ（CR-8 ／ DD-L4-othello-graph）。
 * ★材料は設計書の試験材料から起こす。期待値は表と決めから導く。
 */
class OthelloGraphTest {

    private val empty = List(8) { "........" }
    private val init = listOf("........", "........", "........", "...WB...",
        "...BW...", "........", "........", "........")
    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)
    private val six = OthelloParam.levelParams(6, "")!!

    // ---- weightSum
    @Test fun `weightSum 石が無ければ 0`() = assertEquals(0, OthelloGraph.weightSum(empty, "B"))

    @Test fun `weightSum 隅の 1 つは表の値`() {
        val one = listOf("B.......", "........", "........", "........",
            "........", "........", "........", "........")
        assertEquals(OthelloWeight.weightOf(0, 0), OthelloGraph.weightSum(one, "B"))
    }

    // ★★物差しは段で切り替えない。段 6 でも同じ表（CR-12 の決め 12-1）
    @Test fun `weightSum 段6でも物差しは同じ表`() {
        val one = listOf("B.......", "........", "........", "........",
            "........", "........", "........", "........")
        assertEquals(OthelloWeight.weightOf(0, 0), OthelloGraph.weightSum(one, "B"))
        assertTrue(OthelloWeight.authorOf(0, 0) != OthelloWeight.weightOf(0, 0))
    }

    // ★相手の石は引かない。2 本のまま
    @Test fun `weightSum 相手の石は数えない`() {
        val one = listOf("BW......", "........", "........", "........",
            "........", "........", "........", "........")
        assertEquals(OthelloWeight.weightOf(0, 0), OthelloGraph.weightSum(one, "B"))
        assertEquals(OthelloWeight.weightOf(0, 1), OthelloGraph.weightSum(one, "W"))
    }

    // ---- appended
    @Test fun `appended 計算機が居なければ そのまま`() =
        assertEquals(Trend(listOf(), listOf()),
            OthelloGraph.appended(Trend(listOf(), listOf()), init, false))

    @Test fun `appended 1 つ伸びる`() {
        val got = OthelloGraph.appended(Trend(listOf(), listOf()), init, true)
        assertEquals(1, got.black.size)
        assertEquals(1, got.white.size)
    }

    // ★2 本は同じ長さを保つ（DD-L4-othello-graph §3.3）
    @Test fun `appended 2 本は同じ長さ`() {
        var got = Trend(listOf(), listOf())
        for (i in 1..5) got = OthelloGraph.appended(got, init, true)
        assertEquals(5, got.black.size)
        assertEquals(got.black.size, got.white.size)
    }

    // ---- trimmed
    @Test fun `trimmed 手数のほうが長ければ そのまま`() =
        assertEquals(Trend(listOf(10, 20), listOf(5, 8)),
            OthelloGraph.trimmed(Trend(listOf(10, 20), listOf(5, 8)), 5))

    // ★0 手目を含むので、残すのは 手数 + 1（忘れると 1 つずつ短くなる）
    @Test fun `trimmed 0 手なら 1 つ残る`() =
        assertEquals(Trend(listOf(10), listOf(5)),
            OthelloGraph.trimmed(Trend(listOf(10, 20), listOf(5, 8)), 0))

    @Test fun `trimmed 2 手なら 3 つ残る`() {
        val got = OthelloGraph.trimmed(Trend(listOf(1, 2, 3, 4, 5), listOf(1, 2, 3, 4, 5)), 2)
        assertEquals(3, got.black.size)
        assertEquals(3, got.white.size)
    }

    // ---- ★通し: 窓口が足し、待ったで戻る（CR-8 の 4・6）
    @Test fun `窓口 1 手ごとに 1 つ伸びる`() {
        val setup = Setup("human", "machine", null, null, 3, p3)
        val begun = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), "")
        assertEquals(1, begun.state.trend.black.size)
        val one = OthelloBridge.handle(begun.state, setup, Command("square", "d3"), "")
        // ★人の 1 手と、計算機の応手で 1 回の出来事。並びは 1 つ伸びる（描くのは局面ごと）
        assertTrue(one.state.trend.black.size > begun.state.trend.black.size)
    }

    @Test fun `窓口 人どうしなら 空のまま`() {
        val setup = Setup("human", "human", null, null, null, null)
        val begun = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), "")
        val one = OthelloBridge.handle(begun.state, setup, Command("square", "d3"), "")
        assertTrue(one.state.trend.black.isEmpty())
    }

    @Test fun `窓口 待ったで線も戻る`() {
        val setup = Setup("human", "machine", null, null, 3, p3)
        val begun = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), "")
        val one = OthelloBridge.handle(begun.state, setup, Command("square", "d3"), "")
        val back = OthelloBridge.handle(one.state, setup, Command("undo", ""), "")
        assertEquals(back.state.moves + 1, back.state.trend.black.size)
    }

    @Test fun `一式に形勢が載る`() {
        val setup = Setup("human", "machine", null, null, 3, p3)
        val begun = OthelloBridge.handle(OthelloState.newState(), setup, Command("start", ""), "")
        assertEquals(begun.state.trend, begun.view.trend)
    }
}
