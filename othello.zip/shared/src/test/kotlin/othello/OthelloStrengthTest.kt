package othello

import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 段の順を確かめる（DD-L1-othello-ai §4.3 の「確かめ方」）。
 *
 * ★打ち手は決定的なので、同じ組み合わせは毎回まったく同じ棋譜になる。
 * だから**開幕の数手を変えた盤**をいくつか用意し、そこから戦わせて勝ち数を数える。
 * ★これは「選ばれた」ことではなく、**選ばれた組が本当に強いか**を測るものである。
 */
class OthelloStrengthTest {

    private val levels = listOf(1, 2, 3, 4)

    /** 開幕を変えた盤を作る。1 手目・2 手目の選び方を変えるだけ。 */
    private fun openings(): List<State> {
        val out = mutableListOf(OthelloState.newState())
        for (first in OthelloRules.legalMoves(OthelloBoard.initialBoard(), "B").moves) {
            val one = OthelloGame.play(OthelloState.newState(), first)
            val next = one.state!!
            for (second in OthelloRules.legalMoves(next.board, next.turn).moves) {
                out.add(OthelloGame.play(next, second).state!!)
            }
        }
        return out
    }

    /** 黒がこの組、白があの組で最後まで打つ。返すのは勝った側。 */
    private fun playOut(from: State, black: Params, white: Params): String {
        var state = from
        while (!OthelloRules.isOver(state.board)) {
            val params = if (state.turn == "B") black else white
            // ★置ける升が無ければパス。打ち手に聞く前に、規則が答える
            if (OthelloRules.legalMoves(state.board, state.turn).moves.isEmpty()) {
                state = OthelloGame.passTurn(state).state!!
                continue
            }
            val got = OthelloAi.chooseMove(state.board, state.turn, params)
            state = OthelloGame.play(state, got.move).state!!
        }
        val stones = OthelloState.countStones(state.board)
        return if (stones.b > stones.w) "B" else if (stones.w > stones.b) "W" else "-"
    }

    @Test fun `段の順 上の段が下の段に勝ち越す`() {
        val boards = openings().take(12)
        val params = levels.associateWith { OthelloParam.levelParams(it, "")!! }
        val lines = mutableListOf<String>()
        var wrong = 0
        for (high in levels) {
            for (low in levels) {
                if (high <= low) continue
                var win = 0
                var lose = 0
                for (board in boards) {
                    // ★色を入れ替えて 2 回打つ。片方の色だけで測ると、先手の有利が混ざる
                    if (playOut(board, params.getValue(high), params.getValue(low)) == "B") win++
                    if (playOut(board, params.getValue(low), params.getValue(high)) == "W") win++
                    if (playOut(board, params.getValue(high), params.getValue(low)) == "W") lose++
                    if (playOut(board, params.getValue(low), params.getValue(high)) == "B") lose++
                }
                lines.add("段 %d 対 段 %d : %d 勝 %d 敗".format(high, low, win, lose))
                if (win <= lose) wrong++
            }
        }
        println(lines.joinToString("\n"))
        // ★入れ替えた表で、順が保たれていること。崩れたら落ちる（DD-L1-othello-ai §4.3）
        assertTrue(lines.joinToString(" / "), wrong == 0)
    }
}
