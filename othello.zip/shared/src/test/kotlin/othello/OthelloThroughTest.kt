package othello

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 通しの試験（単体でない）。設計: DD-L2-othello §7z.6
 *
 * ★画面を出さずに、共通の側だけで通す。出来事を送って一式を受け取る形にしてあるので、通せる。
 */
class OthelloThroughTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)

    // ---- ① 1 局が終局まで進む（計算機どうし）
    @Test fun `通し1 計算機どうしは、送り続ければ終局まで進む`() {
        // ★CR-6: 窓口は 1 手ずつ返す。画面（ここでは試験）が「計算機の 1 手」を送って進める
        val both = Setup("machine", "machine", 3, p3, 3, p3)
        var held = OthelloBridge.handle(OthelloState.newState(), both, Command("start", ""), "")
        var guard = 0
        while (held.view.machineToMove && guard < 200) {
            held = OthelloBridge.handle(held.state, both, Command("machine", ""), "")
            guard = guard + 1
        }
        assertTrue(OthelloRules.isOver(held.state.board) && held.view.message == "終局しました")
    }

    // ---- ② 人が 1 手打つと、計算機が応じ、人の番に戻る
    @Test fun `通し2 人の1手に計算機が応じ、人の番に戻る`() {
        val hm = Setup("human", "machine", null, null, 3, p3)
        val start = OthelloBridge.handle(OthelloState.newState(), hm, Command("start", ""), "")
        val got = OthelloBridge.handle(start.state, hm, Command("square", "d3"), "")
        assertTrue(got.state.moves == 2 && got.state.turn == "B")
    }

    // ---- ③ 待ったで、人が打つ番まで戻る
    @Test fun `通し3 待ったで人が打つ番まで戻る`() {
        val hm = Setup("human", "machine", null, null, 3, p3)
        val start = OthelloBridge.handle(OthelloState.newState(), hm, Command("start", ""), "")
        val played = OthelloBridge.handle(start.state, hm, Command("square", "d3"), "")
        val undone = OthelloBridge.handle(played.state, hm, Command("undo", ""), "")
        assertTrue(undone.state.turn == "B" && undone.state.moves == 0)
    }

    // ---- ④ 記録が 1 本残り、読み直せる
    @Test fun `通し4 記録が1本残り、読み直せる`() {
        val root = OthelloPlace.logRoot("othello", "", tmp.root.path)
        val setup = OthelloSetup.newSetup("human", "machine", 3, 3, root, "")
        val log = OthelloLogWrite.openLog(setup, root)
        assertTrue(log.ok)
        OthelloLogWrite.appendEvent(log, "move",
            mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1"))
        OthelloLogWrite.closeLog(log, Result("B", 34, 30))
        val back = OthelloLogRead.readOne(log.path)
        // ★黒は人なので段が無い。白（計算機）の段が入る（CR-12）
        assertTrue(back.finished && !back.broken)
        assertTrue(back.level == null && back.whiteLevel == 3)
        assertEquals(1, OthelloLogRead.collect(listOf(1, 2, 3, 4), root).used)
    }

    // ---- ⑤ 同じ入力から同じ結果（共通が 1 つであることの裏取り）
    @Test fun `通し5 同じ入力なら同じ棋譜になる`() {
        val p4 = OthelloParam.levelParams(4, tmp.root.path)!!
        val both = Setup("machine", "machine", 4, p4, 4, p4)
        val a = OthelloBridge.handle(OthelloState.newState(), both, Command("start", ""), "")
        val b = OthelloBridge.handle(OthelloState.newState(), both, Command("start", ""), "")
        assertEquals(a.state.history.map { it.move }, b.state.history.map { it.move })
    }

    // ---- ⑥ 置き場が無くても対局は続く（記録だけが残らない）
    @Test fun `通し6 置き場が無くても対局は続く`() {
        val hm = Setup("human", "machine", null, null, 3, p3)
        val log = OthelloLogWrite.openLog(hm, "")
        val start = OthelloBridge.handle(OthelloState.newState(), hm, Command("start", ""), "")
        val got = OthelloBridge.handle(start.state, hm, Command("square", "d3"), "")
        assertTrue(!log.ok && got.ok && got.state.moves == 2)
    }
}
