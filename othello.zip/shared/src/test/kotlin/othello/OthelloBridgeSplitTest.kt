package othello

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 割って外へ出した 7 関数の試験（DD-L4-othello-bridge §3c・§3d）。
 *
 * ★関数単位で撃つ——★試験の名に関数名を入れる。入れないと `--tests *関数名*` が当たらない。
 * ★割って増えた関数に試験が無いと、コードが登録できない（テスト先行）。
 */
class OthelloBridgeSplitTest {

    private val setup = OthelloSetup.newSetup("human", "human", 0, 0, "", "")
    private val fresh = OthelloState.newState()

    // --- OthelloBridgeEvent ---

    @Test
    fun `apply 盤を変えない出来事は受理して状態を返す`() {
        val got = OthelloBridgeEvent.apply(fresh, setup, Command("games", ""), "")
        assertTrue(got.ok)
        assertEquals(fresh.moves, got.state?.moves)
    }

    @Test
    fun `apply 升なら進行へ渡す`() {
        val got = OthelloBridgeEvent.apply(fresh, setup, Command("square", "d3"), "")
        assertTrue(got.ok)
        assertEquals(1, got.state?.moves)
    }

    @Test
    fun `replayOf 対局の頭から始める`() {
        val got = OthelloBridgeEvent.replayOf(Command("replay", "0"), "")
        assertTrue(got.ok)
        assertEquals("B", got.state?.turn)
        assertEquals(0, got.state?.moves)
    }

    @Test
    fun `nextOf 並びが空なら断る`() {
        val got = OthelloBridgeEvent.nextOf(fresh)
        assertFalse(got.ok)
        assertNull(got.state)
    }

    @Test
    fun `nextOf 先頭を 1 つ置いて並びから外す`() {
        val got = OthelloBridgeEvent.nextOf(fresh.copy(replay = listOf("d3", "c4")))
        assertTrue(got.ok)
        assertEquals(listOf("c4"), got.state?.replay)
    }

    @Test
    fun `helpOf 印を立てる`() {
        assertEquals(true, OthelloBridgeEvent.helpOf(fresh, Command("help", "")).state?.help)
    }

    @Test
    fun `helpOf 印を下ろしても盤は変わらない`() {
        val opened = fresh.copy(help = true)
        val got = OthelloBridgeEvent.helpOf(opened, Command("closeHelp", "")).state
        assertEquals(false, got?.help)
        assertEquals(opened.board, got?.board)
    }

    // --- OthelloBridgeAfter ---

    @Test
    fun `drawn 受理していなければ伸ばさない`() {
        val got = OthelloBridgeAfter.drawn(fresh, setup, Command("square", "d3"), false)
        assertEquals(0, got.trend.black.size)
    }

    @Test
    fun `drawn 待ったなら手数に合わせて切り詰める`() {
        // ★期待値は DD-L4-othello-graph の `trimmed` の材料から起こす——
        //   手数 0 のとき `['black']:[10]` ＝ 1 件残る（横軸は 0 手から始まるため）。
        val long = fresh.copy(trend = Trend(listOf(1, 2, 3), listOf(1, 2, 3)))
        val got = OthelloBridgeAfter.drawn(long, setup, Command("undo", ""), true)
        assertEquals(1, got.trend.black.size)
    }

    @Test
    fun `closed 閉じていなければ何もしない`() {
        // ★記録の手が無ければ、何も起きない（例外も出ない）
        OthelloBridgeAfter.closed(fresh, null, "", 3)
        assertEquals(0, fresh.gameId)
    }

    @Test
    fun `told 当てはまらない出来事なら一式をそのまま返す`() {
        val view = OthelloView.buildView(fresh, setup)
        assertEquals(view, OthelloBridgeAfter.told(view, Command("square", "d3"), "", 50))
    }

    @Test
    fun `told 一覧なら記録が無いことを文言に出す`() {
        val view = OthelloView.buildView(fresh, setup)
        val got = OthelloBridgeAfter.told(view, Command("games", ""), "", 50)
        assertEquals("まだ記録がありません", got.message)
    }
}
