package othello

import java.io.File
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * 記録の群の単体試験。
 *
 * ★材料は DD-L4-othello-log の「試験材料」から起こしている。
 * 記録はファイルを触るので、置き場は試験の中で実際に作ってから当てる。
 */
class OthelloLogGroupTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private val p3 = Params(1, 0, 0, 1, 0, false, false, 0)
    private val setup = Setup("human", "machine", null, null, 3, p3)
    private val body: Body = mapOf("turn" to "B", "by" to "human", "square" to "d3", "flips" to "1")
    private val result = Result("B", 34, 30)

    private fun write(path: File, events: List<Event>) {
        path.writeText(events.joinToString("\n") {
            Json.encodeToString(Event.serializer(), it)
        } + "\n")
    }

    // ★黒は人なので段を持たない。白（計算機）の段を書く（CR-12）
    private fun openLine(level: Int) = Event(
        "2026-08-12T10-00-00-000", "open",
        mapOf("black" to "human", "white" to "machine",
            "white_params" to Json.encodeToString(Params.serializer(), p3),
            "white_level" to level.toString())
    )

    // ---- OthelloLogOrder.kt:OthelloLogOrder:checkOrder
    @Test fun `checkOrder 順は正しい`() = assertTrue(
        OthelloLogOrder.checkOrder(listOf(ev("open"), ev("move"), ev("close"))).ok)

    @Test fun `checkOrder 順が崩れている`() = assertFalse(
        OthelloLogOrder.checkOrder(listOf(ev("move"), ev("close"))).ok)

    @Test fun `checkOrder 終わりの後に何か来ている`() = assertFalse(
        OthelloLogOrder.checkOrder(listOf(ev("open"), ev("close"), ev("move"))).ok)

    private fun ev(kind: String) = Event("", kind, mapOf())

    // ---- OthelloLogWrite.kt:OthelloLogWrite:openLog
    @Test fun `openLog 記録を始めた`() =
        assertTrue(OthelloLogWrite.openLog(setup, tmp.root.path).ok)

    @Test fun `openLog 書けなかった`() =
        assertFalse(OthelloLogWrite.openLog(setup, "").ok)

    @Test fun `openLog 置き場が無ければ作る`() {
        val root = File(tmp.root, "made/by/app").path
        assertTrue(OthelloLogWrite.openLog(setup, root).ok && File(root).isDirectory)
    }

    @Test fun `openLog 段を始まりの行に書く`() {
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        val head = Json.decodeFromString(Event.serializer(), File(log.path).readLines()[0])
        // ★黒は人なので段が無い。白の段が書かれる（CR-12）
        assertEquals("3", head.body.getValue("white_level"))
    }

    // ---- OthelloLogWrite.kt:OthelloLogWrite:appendEvent
    @Test fun `appendEvent 書いた`() {
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        assertTrue(OthelloLogWrite.appendEvent(log, "move", body).ok)
    }

    @Test fun `appendEvent 書かない`() {
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        val got = OthelloLogWrite.appendEvent(log, "dance", body)
        assertTrue(!got.ok && got.reason.contains("種類"))
    }

    @Test fun `appendEvent 書けなかった`() {
        val got = OthelloLogWrite.appendEvent(LogHandle("x.jsonl", false, ""), "move", body)
        assertTrue(!got.ok && got.reason.contains("書けない"))
    }

    // ---- OthelloLogWrite.kt:OthelloLogWrite:closeLog
    @Test fun `closeLog 閉じた`() {
        val log = OthelloLogWrite.openLog(setup, tmp.root.path)
        assertTrue(OthelloLogWrite.closeLog(log, result).ok)
    }

    @Test fun `closeLog 書けなかった`() =
        assertFalse(OthelloLogWrite.closeLog(LogHandle("x.jsonl", false, ""), result).ok)

    // ---- OthelloLogRead.kt:OthelloLogRead:readOne
    @Test fun `readOne 終わった対局`() {
        val f = tmp.newFile("g1.jsonl")
        write(f, listOf(openLine(3), Event("", "move", body), Event("", "close",
            mapOf("winner" to "B", "black" to "34", "white" to "30"))))
        assertTrue(OthelloLogRead.readOne(f.path).finished)
    }

    @Test fun `readOne 途中で終わった対局`() {
        val f = tmp.newFile("g2.jsonl")
        write(f, listOf(openLine(3), Event("", "move", body)))
        val got = OthelloLogRead.readOne(f.path)
        assertTrue(!got.finished && !got.broken)
    }

    @Test fun `readOne 壊れた記録`() {
        val f = tmp.newFile("g3.jsonl")
        write(f, listOf(Event("", "move", body)))
        assertTrue(OthelloLogRead.readOne(f.path).broken)
    }

    // ---- OthelloLogRead.kt:OthelloLogRead:collect
    private fun threeGames() {
        listOf(1, 3, 4).forEachIndexed { i, level ->
            write(tmp.newFile("g$i.jsonl"), listOf(openLine(level), Event("", "move", body),
                Event("", "close", mapOf("winner" to "B", "black" to "34", "white" to "30"))))
        }
    }

    @Test fun `collect 集めた記録`() {
        threeGames()
        assertEquals(3, OthelloLogRead.collect(listOf(1, 2, 3, 4), tmp.root.path).used)
    }

    @Test fun `collect 材料なし`() {
        threeGames()
        assertEquals(0, OthelloLogRead.collect(listOf(5), tmp.root.path).used)
    }

    @Test fun `collect 壊れた記録は使わず数える`() {
        threeGames()
        write(tmp.newFile("g9.jsonl"), listOf(Event("", "move", body)))
        val got = OthelloLogRead.collect(listOf(1, 2, 3, 4), tmp.root.path)
        assertTrue(got.used == 3 && got.broken == 1)
    }

    @Test fun `collect 途中で終わった対局は分母に入れない`() {
        threeGames()
        write(tmp.newFile("g8.jsonl"), listOf(openLine(3), Event("", "move", body)))
        val got = OthelloLogRead.collect(listOf(1, 2, 3, 4), tmp.root.path)
        assertTrue(got.used == 3 && got.dropped == 1)
    }
}
