plugins {
    kotlin("jvm")
    kotlin("plugin.serialization") version "1.9.22"
}

kotlin {
    jvmToolchain(17)
}

// ★レビューが起こす結合試験の棚を見る（DD-L2-othello §7z.5c）。
//   ★置いただけでは組み立ては知らない——この一行で初めて試験になる。
sourceSets["test"].kotlin.srcDir(rootProject.file("tests/integration/kt"))

dependencies {
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    // ★対戦記録を SQL で読める形に（CR-9）。★復旧はライブラリの機能に任せる
    implementation("org.xerial:sqlite-jdbc:3.46.0.0")
    // ★この環境の在庫にある試験の道具だけを使う（実測 2026-08-12: JUnit 4.13.2 と hamcrest のみ）
    testImplementation("junit:junit:4.13.2")
}

// ★素振り（DD-L4-othello-log §7）。段どうしを戦わせて、段 5 の材料になる記録を作る。
//   例: gradlew :shared:drill -Proot=... -Pboards=5 -Ppairs=1-4,2-4,3-4
tasks.register<JavaExec>("drill") {
    group = "othello"
    description = "段どうしを戦わせ、記録を残す"
    mainClass.set("othello.OthelloDrill")
    classpath = sourceSets["main"].runtimeClasspath
    val root = (project.findProperty("root") ?: "").toString()
    val boards = (project.findProperty("boards") ?: "3").toString()
    val pairs = (project.findProperty("pairs") ?: "1-4").toString().split(",")
    args = listOf(root, boards) + pairs
}

// ★DB の中身を見る道具（DD-L4-othello-db §3.3f）。例: gradlew :shared:dump -Proot=...
tasks.register<JavaExec>("dump") {
    group = "othello"
    description = "DB の中身を 1 行ずつ出す"
    mainClass.set("othello.OthelloDumpKt")
    classpath = sourceSets["main"].runtimeClasspath
    args = listOf((project.findProperty("root") ?: "").toString())
}
