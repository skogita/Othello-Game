# othello — 配布用の写し

『LLM で 100 万行のソフトウェア開発 II』で作ったオセロの、**設計書・要求・コード**の写しです。

## 入っているもの

| 何 | 中身 |
|:---|:---|
| `docs/` | 設計書（DD）**25 本**。L1 から L4 まで。Kotlin 版と Flutter 版の両方 |
| `requirements/requirements.md` | 要求 **26 件** |
| `requirements/rf.md` | 仕様の細目（RF）**17 件** |
| `requirements/cr.md` | 変更要求（CR）**14 件** |
| `shared/` `ui/` `desktop/` `android/` | Kotlin **49 本**。共通・画面・Windows の口・Android の口 |
| `flutter/` | Dart **32 本**。同じ設計書から起こした Flutter 版 |

要求・RF・CR は、**開発環境の記録（DB）から書き出したもの**です。設計書とコードは、実物をそのまま写しました。

## 入っていないもの

| 何 | なぜ |
|:---|:---|
| **利用者向けのマニュアル** | ★**ありません。**このオセロには、遊ぶ人向けの手引きを作っていません。画面のヘルプはアプリの中にあります |
| **試験のファイル**（試験仕様・試験コード・実行結果） | 大きくなりすぎるため |
| **DB の登記** | 記録そのものは入れていません。上の一覧が、その書き出しです |
| **組み立てたもの**（build・成果物・ログ） | 作り直せるため |

## どれが入口か

| どのアプリ | 入口 |
|:---|:---|
| **Windows（Kotlin）** | `OthelloHost.kt`（`desktop`）。Gradle の `mainClass` は `othello.desktop.OthelloHostKt` |
| **Android（Kotlin）** | `OthelloHost.kt`（`android`）。`AndroidManifest.xml` が LAUNCHER に指す。アプリの札は `othello.app` |
| **Flutter** | `main.dart` |

盤の規則や打ち手は、どのアプリでも `shared/` に入っています。画面は `ui/`。Windows と Android の口は、**起こし方と置き場の伝え方だけ**を持ちます。

## 使い方

**このままでは組み立てられません。**Gradle の設定と、Android の SDK が要ります。本の第一部と第三部を見てください。

**読むためのものです。**設計書に何が書かれ、そこからどんなコードが出たのかを、突き合わせて読めます。
