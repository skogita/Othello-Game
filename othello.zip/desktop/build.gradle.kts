/*
 * :desktop — Windows の口（DD-L2-othello §7z.5）
 * ★起こし方と、置き場の伝え方だけを持つ。判断も組み立ても置かない。
 */
plugins {
    kotlin("jvm")
    id("org.jetbrains.compose")
}

kotlin { jvmToolchain(17) }

dependencies {
    implementation(project(":shared"))
    implementation(project(":ui"))
    // ★環境ごとの実体（描画の native）を引き込む口。名前を直接書くと、
    //   この環境用の実体（skiko-awt-runtime-windows-x64）が包みに入らない（実測 2026-08-12）。
    implementation(compose.desktop.currentOs)
    implementation(compose.material)
}

compose.desktop {
    application {
        mainClass = "othello.desktop.OthelloHostKt"
        nativeDistributions {
            packageName = "othello"
            packageVersion = "1.0.0"
            // ★DB を使うので、実行の形に java.sql を入れる（DD-L2-othello §7z.5b）
            //   ★開発の場では JDK が丸ごと在るため、忘れても気づけない
            modules("java.sql")
        }
    }
}

// ★★配った実行の形に、要るモジュールが入っているかを、作った直後に検査する。
//   ★`modules(...)` を書くだけでは再発する——★書き忘れても、開発の場では動いてしまうから。
//   出どころ: android_kb §9.5（同じ穴を 2 度踏んだ。othello では BUG-46）
val 要るモジュール = listOf("java.sql")

tasks.register("verifyRuntimeModules") {
    group = "othello"
    description = "配った実行の形に、要るモジュールが入っているかを見る"
    doLast {
        val at = layout.buildDirectory.file(
            "compose/binaries/main/app/othello/runtime/release").get().asFile
        if (!at.exists()) throw GradleException("実行の形が見つからない: " + at.path)
        val line = at.readLines().firstOrNull { it.startsWith("MODULES=") }
            ?: throw GradleException("MODULES= の行が無い: " + at.path)
        val 入っている = line.removePrefix("MODULES=").trim('"').split(" ")
        val 落ちている = 要るモジュール.filterNot { 入っている.contains(it) }
        if (落ちている.isNotEmpty()) {
            throw GradleException("★実行の形に入っていない: " + 落ちている.joinToString(" ") +
                "（起動した瞬間に落ちる。nativeDistributions の modules(...) に足す）")
        }
        println("実行の形のモジュール: " + 要るモジュール.joinToString(" ") + " → 入っている")
    }
}

// ★包む task は compose の差し込みで後から現れるので、名指しでなく「現れたら繋ぐ」形にする
tasks.matching { it.name == "createDistributable" || it.name == "packageDistributionForCurrentOS" }
    .configureEach { finalizedBy("verifyRuntimeModules") }
