package othello.desktop

import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import othello.OthelloDb
import othello.OthelloDbKeep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowState
import androidx.compose.ui.window.application
import java.io.File
import othello.Command
import othello.OthelloBridge
import othello.OthelloPlace
import othello.OthelloSetup
import othello.OthelloState
import othello.Setup
import othello.Handled
import othello.ui.OthelloScreen
import othello.ui.OthelloTouch

/**
 * Windows の口。★起こし方と、置き場の伝え方だけを持つ（DD-L2-othello §7z.5）。
 *
 * 判断も組み立ても置かない。状態を持ち、出来事を共通の窓口へ送り、返った一式を画面へ渡すだけ。
 */
object OthelloHost {

    /** ★環境の値を読むのは、この口だけ。共通は引数で受け取る（DD-L2-othello §7z.2d）。 */
    fun providedPlace(): String {
        val local = System.getenv("LOCALAPPDATA")
        if (local == null || local == "") return ""
        return File(local).path
    }

    fun given(): String {
        val env = System.getenv("OTHELLO_LOG_ROOT")
        return if (env == null) "" else env
    }
}

@Composable
private fun OthelloApp() {
    var setup by remember { mutableStateOf<Setup?>(null) }
    // ★窓口が返した器を、そのまま 1 つ持つ（DD-L2-othello §7z.2b2）。
    //   状態と一式を別々に持つと、片方だけ入れ替えられてしまう。
    var held by remember { mutableStateOf<Handled?>(null) }
    // ★選び直しの窓を出しているか。対局の有無とは別に持つ（DD-L3-othello の口）
    var choosing by remember { mutableStateOf(true) }
    val root = OthelloPlace.logRoot("othello", OthelloHost.given(), OthelloHost.providedPlace())
    // ★起動のたびに 1 回、置き場の記録を DB へ戻す（DD-L3-othello-db §4.2 の 4）
    //   ★本数は利用者に見せない。★別の筋でやる——画面の筋でやると「応答しません」が出る
    LaunchedEffect(Unit) {
        withContext(Dispatchers.Default) { OthelloDbKeep.importFolder(OthelloDb.openDb(root), root) }
    }

    fun send(event: Command) {
        val now = setup
        val last = held
        if (now == null || last == null) return
        held = OthelloBridge.handle(last.state, now, event, root)
    }

    // ★★**器で渡す**（★抽象でなく合成・DD-L4-othello-ui §2b）
    val touch = OthelloTouch(
        onSquare = { square -> send(Command("square", square)) },
        onPass = { send(Command("pass", "")) },
        onUndo = { send(Command("undo", "")) },

        onStart = { black, white, blackLevel, whiteLevel, name ->
            val made = OthelloSetup.newSetup(black, white, blackLevel, whiteLevel, root, "")
            // ★★器の中では早い戻りが書けない——★**作れたときだけ進む**（DD-L4-othello-ui §2b）
            if (made.black != "") {
                setup = made
                held = OthelloBridge.handle(OthelloState.newState(), made, Command("start", ""), root)
                choosing = false
            }
                },

        // ★計算機の 1 手（CR-6）。間を置くのは画面で、口はそのまま窓口へ送る
        onMachineStep = { send(Command("machine", "")) },

        // ★再生・取り込みも窓口へ送る（DD-L4-othello-bridge §3.1）。口は DB を直に呼ばない
        onReplayList = { send(Command("games", "")) },
        onReplayPick = { gameId -> send(Command("replay", gameId.toString())) },
        onReplayNext = { send(Command("next", "")) },
        onImport = { send(Command("import", "")) },
        onDump = { send(Command("dump", "")) },

        // ★ヘルプも窓口へ送る（F-12・RF-64）。★口は印を持たない——持つと共通側と食い違う
        onHelp = { send(Command("help", "")) },
        onCloseHelp = { send(Command("closeHelp", "")) },

        // ★持っている器を捨て、選び直しの窓を出す（DD-L2-othello §7z.2b1）
        // ★選び直しの窓へ戻るだけ。★対局は捨てない——やめたときの戻る先になる
        onNewGame = {
            choosing = true
                },

        // ★やめたのは選び直しであって、対局ではない。対局が無ければ戻る先が無い
        onCancelSetup = {
            if (held != null) choosing = false
                },)
    OthelloScreen(held?.view, choosing, touch)
}

fun main() = application {
    // ★盤・わきの補助情報・盤の下のグラフが、全部入る大きさで開く（DD-L3-othello の口）
    Window(onCloseRequest = ::exitApplication, title = "オセロ",
        state = WindowState(size = DpSize(1180.dp, 980.dp))) {
        OthelloApp()
    }
}
